# Project 1, Option 3: Mamba-2 vs Mamba-1 on a laptop CPU (+ Mamba-3 decode-step bonus)

**Team:** Apoorva Chaudhary (MT25016), Harsh Sharma (MT25023), Vedika Jain (MT25051), IIIT Delhi
**Engine:** llama.cpp `ace20f679e30` (same commit as Project 0), CPU only, plus one small profiling patch
**Key question (Option 3):** how does Mamba-2's scan compare with Mamba-1's on CPU, in prefill and in decode?
**Bonus:** one Mamba-3 decode step on CPU, SISO and MIMO (rank 4), checked against the official reference over
1,000 steps. Does MIMO's extra compute come at little cost on our CPU? Also measured on our laptop GPU for contrast.

Everything is scripted. Each script writes raw CSVs to `results/<machine>/` and plots to `plots/<machine>/`.
`scripts/12_check.py` checks every requirement of the brief and writes `results/<machine>/REQUIREMENTS.md`.

---

## 1. Quick start (main laptop, about 4 to 6 hours of machine time, mostly unattended)

```bash
git clone <this repo> p1 && cd p1                     # llama.cpp gets cloned next to it (../llama.cpp)
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt                        # pyyaml numpy pandas matplotlib huggingface_hub tabulate
make build                                             # llama.cpp @ pinned commit + opprof patch, CPU only; kernels/
pip install -r ../llama.cpp/requirements/requirements-convert_hf_to_gguf.txt   # converter (CPU torch is fine)
# set machine: and theoretical_peak_bw_gbs: in config/option3.yaml; on WSL2 + Intel hybrid set threads.perf_cores
make hw stream models          # hardware record, STREAM (1..P threads, 3 reps), convert + quantize models (~30 min)
make predict && git add results && git commit -m "predictions before measuring"   # course step 4, timestamped
make correctness               # perplexity on fixed text + 3 different prompts + batch vs token-by-token
make sweep                     # prefill 512/4k/32k, decode 1k/8k/32k, thread scaling, 3 reps each (longest step)
make profile scan              # per-operator breakdown (opprof) + SSM_SCAN operator alone (Mamba-1 vs Mamba-2)
make perf                      # Linux/WSL2: perf cross-check (macOS: Instruments, Windows: VTune; docs/PLATFORMS.md)
make experiment                # own experiment: prefill vs micro-batch size, prediction written first
make reference                 # the shared reference test, same script as on PARAM Rudra (section 2)
make plots summary check       # plots, SUMMARY.md (all numbers + slide list), REQUIREMENTS.md
make bonus                     # Mamba-3 bonus on CPU, end to end (needs torch + einops, CPU build)
```
Before every sweep: charger in, performance power mode, browser/IDE closed, GPU idle. `06_sweep.py` checks this and
records it (`results/<machine>/preflight/`). Interrupted? Rerun the same command: finished runs are skipped.
`make smoke` runs the entire pipeline on tiny random-weight models in about 5 minutes, without downloads. Use it to test a setup.

## 2. Two laptops, an unpredictable PARAM Rudra, and the GPUs

| what | where | how long | why |
|---|---|---|---|
| everything in section 1 | laptop A | 4–6 h | the main results |
| `make second` (required points, 4 models, reference test) | laptop B | ~1.5–2 h | cross-machine roofline check |
| `make compare` | either, after both result folders are committed | 1 min | `results/COMPARE.md`, `plots/compare/` |
| `make gpu-setup gpu` (bonus, GPU half) | the laptop with the NVIDIA GPU, **never during CPU sweeps** | ~30 min | MIMO's cost on the GPU vs the CPU |
| `make rudra-prepare`, then `sbatch scripts/09_rudra_reference.sbatch` | Rudra login node, **now**, not at the end | 5 min job | the shared number |

**Second laptop.** Use a different machine name in `config/option3.yaml`.
- If the bandwidth ÷ bytes model explains decode, measured ÷ predicted ("efficiency") comes out similar on both laptops even when raw speeds differ. On the predicted-vs-measured plot, both machines then fall on one line.
- If one machine falls off the line, that points at something machine-specific: thermals, hybrid cores, WSL2, single-channel RAM.
- If the two laptops are identical, the comparison becomes a reproducibility check instead.

Commit both `results/<machine>/` folders.

**PARAM Rudra.** The brief wants one number per team on the same node. Neither a laptop nor a GPU can replace that, so the scripts make an attempt cheap and leave evidence either way:
- `scripts/09_rudra_prepare.sh` runs on the login node. It builds once (portable build: every x86 CPU variant, picked at run time on the compute node), then downloads the model and the STREAM source.
- The job only runs `scripts/09_reference.sh`, the same script laptops run. It takes about 5 minutes with a 20-minute limit, and short jobs get backfilled into gaps in the queue.
- Submit as soon as the pipeline works, and resubmit if a job fails. `sbatch --test-only scripts/09_rudra_reference.sbatch` shows the expected start time.
- After every attempt, run `scripts/09_rudra_log.sh`. It appends sacct/squeue output to `results/rudra-attempts.md`.
- If the node never runs, report the laptop reference runs (same fixed test) plus that log, and tell the TA early.

**GPUs.** Graded measurements are CPU-only ("llama.cpp, built for CPU only"). But the bonus question rests on a GPU premise: "On GPUs this extra compute comes at little cost because decode is limited by memory reads. Whether the same holds on a laptop CPU is the open question."
`bonus/mamba3/gpu/run_gpu.sh` runs the official kernels on your GPU, then:
1. checks them against the same 1,000-step references as our CPU kernel;
2. times SISO, MIMO and Mamba-2 at the same state size;
3. feeds the result to `analyze.py`, so `ANSWER.md` reports MIMO's cost on the GPU next to the CPU.

The GPU must stay idle during CPU sweeps: CPU and GPU share the laptop's power limit.

## 3. How each requirement of the brief is met

| brief | how | output |
|---|---|---|
| CPU-only build, pinned | `scripts/00_build_llamacpp.sh`: Metal/BLAS/CUDA off, `-march=native` (`PORTABLE=1` for Rudra), opprof patch | `build_info.txt` |
| Hardware record | `01_hwinfo.py`: CPU, P/E cores, caches, SIMD, RAM, power state | `hardware.{json,md}` |
| Bandwidth with STREAM | `02_stream.py`: STREAM (validated, array >= 4x LLC) + read-only kernel, threads 1..P, 3 reps | `stream.csv`, `bw_read.csv` |
| Models, quantization rules | `03_get_models.sh`: official checkpoints -> pinned converter -> Q4_K_M (Q8_0 only <= 1.5B), SHA-256 | `checksums.sha256` |
| Correctness | `04_correctness.py`: PPL on fixed WikiText-2 sample (Q4_K_M <= 1.05 x Q8_0), 3 different prompts, batch == token-by-token | `correctness/` |
| Predict before measuring | `05_predict.py`: exact bytes/token from the GGUF + recurrent-state traffic, / STREAM | `predictions.csv`, `bytes_per_token.md` |
| Sweeps, 3x, peak RSS every run | `06_sweep.py`: every repetition is a fresh process, peak RSS via `wait4`, swap/page-fault flag + rerun | `raw/sweep.csv` |
| Per-operator breakdown | `07_profile.py` + `patches/0001-ggml-cpu-opprof.patch` (+ `--perf`) | `profile/summary.{csv,md}` |
| Key question, at operator level | `07b_scan_bench.sh` -> `kernels/ssm_scan_bench`: ggml SSM_SCAN alone, real shapes | `ssm_scan_bench.csv` |
| Roofline gap | `10_plots.py` predicted_vs_measured, `13_compare_machines.py` across machines, `docs/THEORY.md` checklist | `plots/` |
| Own experiment | `08_experiment.py`: micro-batch size, prediction written first | `experiment.md` |
| Shared reference run | `09_reference.sh` (any machine), `09_rudra_prepare.sh` + `09_rudra_reference.sbatch`, `09_rudra_log.sh` | `results/<machine>/reference/` |
| Required plots | decode vs context, prefill vs prompt, thread scaling, op breakdown, predicted vs measured (+ memory, experiment, scan) | `plots/<machine>/` |
| Report + talk | `report/REPORT_TEMPLATE.md`, `report/SLIDES.md`; numbers from `SUMMARY.md` | `report/` |

## 4. Bonus: Mamba-3 decode step (`bonus/mamba3/`, `kernels/`)

* **Official code on CPU (bonus step 2).** The official decode path (`Mamba3.step`, state-spaces/mamba @ `e9594ce`) calls GPU kernels.
  * Each kernel has an official pure-PyTorch reference. `ref/extract_official_refs.py` copies those **verbatim**.
  * `ref/layer_ref.py` rebuilds the step from them. It agrees with the authors' independent SISO reference to **4.4e-16**.
  * `gpu/official_step.py validate --emulate` runs the **unmodified official module code** on CPU, with its kernel calls routed to those references.
    Over 1,000 steps it matches our float64 traces to **6.4e-7 (SISO) and 6.5e-7 (MIMO R=4)**. That is float32 level, as expected: the official module keeps its state in float32.
* **Kernels.** `kernels/src/ssm.h` holds the C++ step: Mamba-3 SISO, MIMO-R and Mamba-2, from one templated source with plain, AVX-512, AVX2+FMA and NEON paths.
  * Correctness over 1,000 steps vs the float64 traces, tolerance 1e-4:

    | | SISO | MIMO R=4 | Mamba-2 |
    |---|---|---|---|
    | worst per-step relative error | ≤ 1.2e-6 | ≤ 1.1e-6 | ≤ 1.0e-6 |

    Final states match within 1.7e-5.
  * Stretch goal done: the step runs as ggml custom operators inside a ggml graph (4.7e-7).
* **The answer.** `run_bonus.sh` measures time per step and FLOP/byte, then writes `ANSWER.md`. Sandbox reading (2-core server VM, **not your laptop**): MIMO-4 does 3.6x SISO's FLOPs.

  | MIMO-4 vs SISO | 2 threads |
  |---|---|
  | state update, DRAM-resident | ×2.15 |
  | whole layer | ×1.20 |

  Verdict: "slows decode". On 1 core it was ×1.80 / ×1.08, so your machine decides.
* **GPU half** (`gpu/setup_gpu.sh`, `gpu/run_gpu.sh`): the real official kernels, validated and timed on your GPU.
  * Written and checked as far as possible here, but **not run on a GPU** (my sandbox has none). That covers argument capture and fallback shapes; the official module code itself ran on CPU, as above.
  * If the CuTe-DSL step kernel doesn't support your GPU, the benchmark falls back to `torch.compile` of the official reference for every configuration and says so.

## 5. What has already been run (sandbox; NOT our laptop numbers)

* `results/smoke/`, `plots/smoke/`: the whole pipeline on synthetic models.
* `bonus/mamba3/results/sandbox-xeon/`: the full CPU bonus run, including `ANSWER.md`.
* Also tested on two synthetic "machines": the reference test, the attempt logger, and the cross-machine comparison. Those test results were removed before packaging.

## 6. Known issues (found while testing, documented in the report)

* **Mamba-1 perplexity:** at the pinned commit, `llama-perplexity` with several sequences per batch silently gives no estimate
  for Mamba-1. `04_correctness.py` therefore uses one sequence per batch (`-b ctx`), which leaves PPL unchanged.
* **WSL2 and Intel hybrid CPUs:** WSL2 hides P/E core types. Set `threads.perf_cores` by hand and say so in the report (docs/PLATFORMS.md).
* **Rebuild:** the sandbox needed an `-O0` hack for libllama to fit its time limit. It is NOT part of this repo, so build with `make build`.

## 7. Suggested split for three people (commit under your own name: contributions are graded)

| person | owns |
|---|---|
| A | laptop A pipeline (build, hardware, STREAM, models, correctness, sweeps), report |
| B | laptop B (`make second`), cross-machine comparison, PARAM Rudra attempts + log, experiment |
| C | profiling, scan study, roofline/gap analysis, bonus (CPU + GPU), talk |

## 8. Repository layout
```
config/        option3.yaml (real run), smoke.yaml (synthetic test)
scripts/       00..13 numbered steps, lib/ (runner, preflight), bw/ (read-only bandwidth kernel)
patches/       0001-ggml-cpu-opprof.patch  (per-operator wall-time profiler, off unless GGML_OPPROF is set)
kernels/       C++: Mamba-3/Mamba-2 decode steps, tests, benchmark, ggml custom op, SSM_SCAN benchmark
bonus/mamba3/  ref/ (official references, verbatim), gpu/ (official module: CPU emulation + GPU), run_bonus.sh, analyze.py
tools/         make_synthetic_gguf.py (random-weight GGUFs), smoke_test.sh, stream/ (STREAM source is downloaded)
docs/          THEORY.md (why the numbers are what they are), PLATFORMS.md (WSL2, macOS, Linux, Windows, gaming laptops)
report/        REPORT_TEMPLATE.md, SLIDES.md
results/ plots/  generated (results/COMPARE.md and plots/compare/ across machines)
```

*Tooling note:* parts of this repository were developed with an AI assistant (Claude). If the course has an AI-use policy, keep this line.
