# Platform notes

## Windows + WSL2 (what we used in Project 0)
* **Memory:** WSL2 gets 50% of host RAM by default (4 GB on an 8 GB laptop) plus swap. Our largest run (Mamba-2 2.7B
  Q4_K_M, about 1.7 GB + 164 MiB state) fits. The sweep flags any run that swaps, or that re-reads weight pages from disk
  (`memory_pressure` = many major page faults), and reruns it.
  * Check: `cat /proc/meminfo | head -3`.
  * Raise the limit in `%USERPROFILE%\.wslconfig`: `[wsl2]` then `memory=6GB`; afterwards `wsl --shutdown`.
* **Power:** Settings > System > Power > Power mode = **Best performance**, charger in. `06_sweep.py` reads both from
  Windows (`reg.exe`, `powershell.exe`) and records them in `results/<machine>/preflight/`.
* **Background apps:** close browsers and IDEs on the *Windows* side too. The preflight lists Windows processes via `tasklist.exe`.
* **Intel hybrid CPUs (12th gen and later, Core Ultra):** WSL2 cannot see which vCPUs are P-cores.
  * Set `threads.perf_cores` in `config/option3.yaml` to the number of P-cores (Task Manager or the Intel spec page).
  * Say in the report that thread placement is left to Windows.
  * If you want strict P-core runs, use the native Windows llama.cpp build with `start /affinity <mask>`. P-cores are
    usually the first logical CPUs.
* **perf:** Ubuntu's `linux-tools` package does not match the WSL kernel. Build perf from source:
  `git clone --depth 1 https://github.com/microsoft/WSL2-Linux-Kernel && cd WSL2-Linux-Kernel/tools/perf && make && sudo cp perf /usr/local/bin`
  (install the build packages it asks for). Hardware counters are usually unavailable, so `07_profile.py --perf` uses `cpu-clock` sampling.
  Alternative: Intel VTune or AMD uProf on Windows.

## Gaming laptops with an NVIDIA GPU
* **Power mode:** use the vendor's performance mode as well as Windows "Best performance": Armoury Crate *Turbo*,
  Lenovo Vantage/Legion *Performance*, Dell/Alienware *G-mode*, MSI Center *Extreme Performance*. It raises the CPU's
  sustained power limit, which changes prefill and thread-scaling numbers. Record which mode you used.
* **Keep the GPU idle during CPU sweeps.** CPU and GPU share one power and thermal budget (NVIDIA Dynamic Boost moves
  watts between them). The preflight checks `nvidia-smi` for running GPU processes. Run the GPU part of the bonus at
  a different time.
* **MUX / Optimus (hybrid graphics)** doesn't matter for CPU runs. But a browser left open on the dGPU still counts as a background app.

## Native Linux
* **Pinning:** P-cores are detected from `/sys/devices/cpu_core` and runs are pinned with `taskset`.
* **Performance mode:** `powerprofilesctl set performance`, or `sudo cpupower frequency-set -g performance`.
* **perf:** `sudo apt install linux-tools-$(uname -r)`, then `sudo sysctl kernel.perf_event_paranoid=1`.

## macOS (Apple Silicon)
* **Build:** Metal is turned off by the build script, as the brief requires. BLAS (Accelerate, which uses the AMX unit) is also off, so prefill runs on ggml's own CPU kernels.
* **OpenMP:** STREAM and `kernels/` need it: `brew install libomp` (or `brew install gcc` for STREAM).
* **P-cores:** `perf_cores` = `sysctl hw.perflevel0.physicalcpu`. macOS has no thread pinning: the scheduler keeps busy threads on P-cores.
* **Profiler:** Instruments. `xcrun xctrace record --template 'Time Profiler' --output decode.trace --launch -- ../llama.cpp/build/bin/llama-bench -m models/mamba2-1.3b-Q4_K_M.gguf -p 0 -n 256 -t 4`,
  then open `decode.trace` and export the heaviest stack frames. The opprof numbers come from `07_profile.py` on every platform.
* **NEON path:** `kernels/` compiles a NEON path. It was written and compiled for x86 only in our sandbox, so run
  `make bonus` on the Mac to test it (the test prints `impl=neon`).

## Windows native profilers (optional)
VTune: Hotspots analysis of `llama-bench.exe -p 0 -n 256`. AMD uProf: CPU profile, then group by function. Map
symbols to operators: `ggml_vec_dot_q4_K_q8_K` / `gemv_*` = matmul, `ggml_compute_forward_ssm_scan_f32` = scan,
`ggml_barrier` = thread sync.

## PARAM Rudra
See the header of `scripts/09_rudra_reference.sbatch`. Download models on the login node; the job builds llama.cpp on the
compute node (`build-rudra/`) so `-march=native` matches the node.
