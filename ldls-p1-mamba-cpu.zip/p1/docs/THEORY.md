# Why the numbers are what they are (Option 3 + bonus)

The brief grades a clear explanation, not the fastest number. Use this file to write the report's roofline and
gap sections and to prepare the talk. Every claim below has a script that measures it.

## 1. Decode is a memory-streaming problem

Each decoded token must read every weight matrix once, so

    decode tokens/s  <=  bandwidth / bytes per token
    bytes per token   =  W (weights)  +  recurrent-state traffic (Mamba)   or   + KV cache (transformer)

`05_predict.py` reads W **exactly** from the GGUF tensor table: the quantized size of every tensor. It applies two rules:
- **Tied embeddings:** the state-spaces Mamba models tie input embedding and output head. With no `output.weight`, the
  output matmul reads the whole 50,280 x d_model matrix every token.
- **Unquantizable tensors:** some small tensors can't use K-quants because their rows aren't multiples of 256, so llama-quantize
  falls back to another type. One example is Mamba-1's `ssm_dt`, the dt projection with 128-wide rows. The GGUF tells you which type it got.

### Recurrent state: constant in context, but not small

Per layer, in float32 (formulas in `05_predict.py`):

| model | layers | SSM state / layer | conv state / layer | state per sequence |
|---|---:|---:|---:|---:|
| Mamba-1 1.4B (d_inner 4096, d_state 16) | 48 | 256 KiB | 48 KiB | 14.3 MiB |
| Mamba-1 2.8B (d_inner 5120, d_state 16) | 64 | 320 KiB | 60 KiB | 23.8 MiB |
| Mamba-2 1.3B (d_inner 4096, d_state 128) | 48 | 2 MiB | 51 KiB | 98.4 MiB |
| Mamba-2 2.7B (d_inner 5120, d_state 128) | 64 | 2.5 MiB | 63 KiB | 164 MiB |

Every decoded token must read the state and write it back, which is at least 2 x state of traffic.

**llama.cpp moves about 4 x state.** In `src/models/mamba-base.cpp` the graph:
- feeds the cached state to `SSM_SCAN`;
- which writes the new state into its own output tensor;
- then a `CPY` node copies that back into the cache (read + write again).

For Mamba-2 1.3B that is about 0.41 GB per token on top of roughly 0.8 GB of Q4_K_M weights (exact W: `bytes_per_token.md`). So the state is about a third of all decode traffic. For Mamba-1 1.4B it is about 60 MB, around 6%.
`predicted_vs_measured.png` shows both the ideal (2x) and the llama.cpp (4x) prediction. Which one your measurement
sits closer to is a finding.

### Flat vs growing (the contrast the brief asks for)

The Mamba state does not depend on context, so decode speed and memory should be flat from 1k to 32k
(`decode_vs_context.png`, `memory_vs_context.png`). A transformer re-reads its KV cache every step. For Llama-3.2-1B that is
16 layers x 8 KV heads x 64 dims x (K+V) x 2 bytes = 32 KiB per context token, so bytes per token grow linearly. At 16k
that is +0.5 GB per token. The smoke test already shows the shape: tiny Mamba-2 decodes at the same speed at 8k as at
1k, while tiny Llama loses 60% between 1k and 4k.

## 2. The key question: the two scans in llama.cpp are different kinds of code

Both families run ggml's `SSM_SCAN` (`ggml/src/ggml-cpu/ops.cpp`), but on different paths.

| | Mamba-1 path | Mamba-2 path |
|---|---|---|
| decay | per state element: `expf(dt*A[s])` inside the loop | one `exp(dt*A)` per head |
| vectorised (x86) | **no**: comment in the source, d_state=16 and expf in the loop | yes: GGML_F32 SIMD over d_state |
| state per layer | small (256 KiB) | 8x larger (2 MiB) |
| decode (1 token) | compute-bound: 65k `expf` per layer per token | memory-bound: stream 2 MiB in and out per layer |
| prefill (512-token ubatch) | **same cost per token** (still one expf per element per token) | much cheaper per token: the state stays in cache across tokens |
| threading | over channels (n_head = d_inner, head_dim = 1) | over heads (64) |

The operator benchmark (`make scan`) measures exactly this with the real shapes. Sandbox numbers, 1 thread, µs per
token per layer:

| | decode | prefill |
|---|---:|---:|
| Mamba-1 1.4B | ≈ 570 | ≈ 600 |
| Mamba-2 1.3B | ≈ 450–530 | ≈ 100 |

So, on that machine, Mamba-2's scan was about 6x cheaper per token in prefill and about equal in decode. Verify on your laptop with 1..P threads.
Also explain why the GPU picture differs. Mamba-2's main idea, the chunked SSD matmul formulation, is what makes it fast in
prefill on tensor cores. llama.cpp's CPU path does not use it: it runs a plain sequential scan.

At model level, `profile/summary.md` gives the SSM_SCAN share of each phase. Combine it with the operator numbers.

## 3. Prefill and thread scaling

Prefill processes a micro-batch of b tokens per weight pass (default b = 512): the matmuls become matrix-matrix
products and the run turns compute-bound. Hence prefill speed scales with cores, decode saturates with bandwidth.
`thread_scaling.png` shows both next to STREAM bandwidth vs threads. Decode stops improving where STREAM stops improving.

The own experiment (`08_experiment.py`) changes b and predicts

    t(b) = (W + 4S) / (b * BW) + t_compute,   crossover b* = (W + 4S) / (BW * t_compute)

before measuring. That is the roofline transition from memory-bound to compute-bound, measured.

## 4. Explaining the gap between predicted and measured decode (checklist)

| possible cause | how to show it with this repo |
|---|---|
| STREAM Triad under-counts the bandwidth a read-only stream gets (writes, write-allocate) | compare predictions with Triad vs read-only BW (`bw_read.csv`) |
| extra state traffic in llama.cpp (copy-back) | 2x vs 4x prediction; `CPY` and `CONCAT` time in the op breakdown |
| non-matmul operators (scan, conv, norms, elementwise) are not bandwidth-efficient | op breakdown: share of time outside MUL_MAT vs their share of bytes |
| Mamba-1 scan is compute-bound (scalar expf) | scan benchmark: decode ≈ prefill cost per token |
| threading overhead (barrier after every op, small decode ops) | thread scaling; opprof includes barrier wait; `perf` shows `ggml_barrier` time |
| too few threads to saturate DRAM | STREAM vs threads: how many threads reach the plateau |
| cache effects | small models or states that fit in L3 beat the DRAM prediction (seen in the smoke test) |
| thermal throttling / power mode | `freq_mhz_*`, `temp_c_*` columns in `raw/sweep.csv`; spread across the 3 repetitions |
| WSL2 / VM effects | compare with a native run if possible; note the memory cap |

## 5. Bonus: Mamba-3 decode step

The official update (`selective_state_update_fused_ref_v2`), per head, with λ = sigmoid(trap) and Δ = softplus(·):

    α = exp(AΔ),   β = (1−λ) Δ α,   γ = λ Δ
    S ← α S + γ Σ_r (x ⊙ xproj_r) B̃_rᵀ + β Σ_r (x_prev ⊙ xproj_r) B̃_prev,rᵀ        (exponential-trapezoidal)
    y = Σ_r outproj_r ⊙ silu(z ⊙ zproj_r) ⊙ (S C̃_r + D x ⊙ xproj_r)

B̃ and C̃ are RMS-normalised, biased, and rotated by a data-dependent angle θ += tanh(·)·Δ·π. This is the complex-valued
state written as a real rotation. SISO is R = 1 with all projections equal to 1.

Per state element and step:

| | FLOPs | bytes (fp32 read + write) | arithmetic intensity |
|---|---:|---:|---:|
| Mamba-2 | ≈ 5 | 8 | 0.6 FLOP/byte |
| Mamba-3 SISO | ≈ 7 | 8 | 0.9 FLOP/byte |
| Mamba-3 MIMO rank R | 1 + 6R (25 at R = 4) | 8 | 3.1 FLOP/byte at R = 4 |

On a GPU, 3.1 FLOP/byte is still far below the ridge point (hundreds), so MIMO is free there. On a laptop CPU the ridge
is roughly 5–15 FLOP/byte with all cores, but only 2–5 with one core. MIMO can therefore become compute-bound, especially at
low thread counts. The answer depends on your core count; `bench_step` measures it.

**The same question on a GPU** (`bonus/mamba3/gpu/run_gpu.sh`). A laptop RTX-class GPU has roughly 10–20 TFLOP/s FP32
and 250–450 GB/s, a ridge of roughly 40–60 FLOP/byte. MIMO's 3.1 FLOP/byte stays far below it, so the state update
should stay memory-bound and MIMO should cost little, as the paper reports for H100. Two cautions:
- At batch 1 a single layer's 2 MiB state is too small: launch latency dominates. Read the batch-64 rows (128 MiB of state) for the bandwidth-bound comparison.
- The full layer step at batch 1 is dominated by reading the projection weights, on GPU and CPU alike.

The CPU/GPU contrast with your own numbers is the strongest form of the bonus answer.

Where the time goes in our MIMO kernel: each (head, row, rank) output needs a horizontal sum and an `exp` in the SiLU
gate. That is 4x more scalar epilogue work at R = 4. It is one reason the cache-resident MIMO step costs more than its
FLOP ratio. The next optimisation would be a transposed state layout that vectorises those sums across rows.
