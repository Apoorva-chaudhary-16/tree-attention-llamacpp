#!/usr/bin/env bash
# Bonus: one Mamba-3 decode step on CPU (SISO and MIMO), end to end, on THIS machine.
# Needs: python3 with torch + einops (CPU build is fine: pip install torch einops numpy matplotlib pandas),
#        llama.cpp built by scripts/00_build_llamacpp.sh (only for the ggml stretch test).
#   bonus/mamba3/run_bonus.sh                     # uses the shipped verbatim official references
#   MAMBA_REPO=~/mamba bonus/mamba3/run_bonus.sh  # re-extract them from a clone of state-spaces/mamba
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; REPO="$(cd "$HERE/../.." && pwd)"; cd "$HERE"
PY="${PYTHON:-python3}"
MACHINE="${P1_MACHINE:-$(cd "$REPO" && python3 -c 'import sys; sys.path.insert(0,"scripts/lib"); import common as C; print(C.load_config()["_machine"])')}"
P="$(cd "$REPO" && python3 -c 'import sys; sys.path.insert(0,"scripts/lib"); import common as C; print(C.cpu_topology(C.load_config()).perf_cores)')"
OUT="$HERE/results/$MACHINE"; TR="${TRACES:-$HERE/traces}"; K="$REPO/kernels/build"
mkdir -p "$OUT"
echo "== machine $MACHINE, $P performance cores -> $OUT"
[ -n "${MAMBA_REPO:-}" ] && $PY ref/extract_official_refs.py --repo "$MAMBA_REPO"
echo "== 1. our Mamba3.step port vs the authors' independent SISO step reference (float64)"
$PY ref/layer_ref.py crosscheck | tee "$OUT/crosscheck.log"
OFF="${MAMBA_REPO:-$HERE/official}"
if [ ! -d "$OFF/mamba_ssm" ] && command -v git >/dev/null; then
  git clone -q --filter=blob:none https://github.com/state-spaces/mamba.git "$OFF" && git -C "$OFF" checkout -q e9594ce1c732d97440f0332fdc43170a2294dbfa || true
fi
echo "== 2. 1000-step float64 reference traces (official refs)"
[ -f "$TR/mamba3_siso/y_ref.npy" ] || $PY ref/layer_ref.py traces --out "$TR" --steps 1000 --d-model 512
echo "== 2b. the official Mamba3.step MODULE code itself on CPU (its kernels -> official refs) vs the traces"
if [ -d "$OFF/mamba_ssm" ]; then
  $PY gpu/official_step.py validate --emulate --repo "$OFF" --traces "$TR" | tee "$OUT/official_module_cpu.log"
else
  echo "   (skipped: no clone of state-spaces/mamba; set MAMBA_REPO)" | tee "$OUT/official_module_cpu.log"
fi
echo "== 3. build + correctness, scalar and SIMD kernels, 1000 steps, tolerance 1e-4"
"$REPO/kernels/build.sh" > "$OUT/build.log" 2>&1 || { cat "$OUT/build.log"; exit 1; }
: > "$OUT/test_step.log"
for t in mamba3_siso mamba3_mimo4 mamba2; do
  OMP_NUM_THREADS="$P" "$K/test_step" "$TR/$t" --csv "$OUT/errors_$t.csv" | tee -a "$OUT/test_step.log"
  [ -x "$K/test_step_avx2" ] && OMP_NUM_THREADS="$P" "$K/test_step_avx2" "$TR/$t" | grep -v "impl=scalar" | tee -a "$OUT/test_step.log"
done
echo "== 4. stretch: the step as ggml operators in a ggml graph"
: > "$OUT/ggml_op_test.log"
if [ -x "$K/ggml_op_test" ]; then
  for t in mamba3_siso mamba3_mimo4; do OMP_NUM_THREADS="$P" "$K/ggml_op_test" "$TR/$t" "$P" | tee -a "$OUT/ggml_op_test.log"; done
fi
echo "== 5. time per step + arithmetic intensity at equal state size, threads 1..$P, 3 repetitions"
OMP_NUM_THREADS="$P" "$K/bench_step" --threads "$(seq -s, 1 "$P")" --reps 3 --csv "$OUT/bench_step.csv" | tee "$OUT/bench_step.log"
echo "== 6. analysis + answer"
$PY analyze.py "$OUT"
