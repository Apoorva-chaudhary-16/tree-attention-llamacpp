#!/usr/bin/env bash
# GPU part of the bonus: validate the official GPU kernels against our float64 traces, then time SISO / MIMO /
# Mamba-2 decode steps at the same state size on this GPU. Run setup_gpu.sh first, and run_bonus.sh (CPU) first
# so the traces exist. Do NOT run this while CPU sweeps are running on the same laptop (shared power budget).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; REPO="$(cd "$HERE/../../.." && pwd)"
# shellcheck disable=SC1091
source "$HERE/.venv-gpu/bin/activate"
MACHINE="${P1_MACHINE:-$(hostname -s)}"; OUT="$HERE/../results/$MACHINE/gpu"; TR="${TRACES:-$HERE/../traces}"
mkdir -p "$OUT"
[ -f "$TR/mamba3_siso/y_ref.npy" ] || { echo "!! traces missing: run bonus/mamba3/run_bonus.sh first (CPU)"; exit 1; }
nvidia-smi --query-gpu=name,memory.total,driver_version,clocks.max.sm,power.limit --format=csv > "$OUT/nvidia-smi.csv" || true
echo "== 1. official GPU kernels vs float64 reference traces (1000 steps, tol 1e-4)"
python "$HERE/official_step.py" validate --repo "$HERE/../official" --traces "$TR" | tee "$OUT/gpu_validation.log" || true
echo "== 2. time per decode step, same state size (64 x 64 x 128), batch 1/16/64, bf16, CUDA graphs, 3 reps"
python "$HERE/official_step.py" bench --repo "$HERE/../official" --out "$OUT" | tee "$OUT/gpu_bench.log"
echo "== done -> $OUT. Copy this folder into the repo of the CPU laptop (same path) and rerun bonus/mamba3/analyze.py there."
