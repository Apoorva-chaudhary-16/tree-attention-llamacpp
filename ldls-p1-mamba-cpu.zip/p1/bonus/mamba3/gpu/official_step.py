#!/usr/bin/env python3
"""Run the OFFICIAL Mamba-3 decode step: Mamba3.step from state-spaces/mamba, module code unmodified.

validate : 1,000 decode steps of one layer (SISO and MIMO R=4) against the float64 reference traces that our
           C++ kernel is tested against (ref/layer_ref.py traces), with the SAME weights.
             --emulate  CPU, any machine: the module's GPU kernels are replaced by the authors' own pure-PyTorch
                        reference functions for those kernels (ref/official_refs.py, verbatim). This runs the
                        official Mamba3.step code itself on CPU and checks our port of it.
             default    CUDA GPU: the real official kernels (Triton RMSNorm + rotary, CuTe-DSL step kernel).
bench    : (GPU) time per decode step for Mamba-2, Mamba-3 SISO, MIMO R=2, R=4 at the SAME state size
           (64 heads x 64 x 128), batch 1/16/64: the full layer step (module.step) and the state-update kernel
           alone, with CUDA graphs. The brief's premise "on GPUs MIMO's extra compute comes at little cost",
           measured on our own GPU, next to the CPU answer.

  python3 official_step.py validate --repo ../official --traces ../traces [--emulate]
  python3 official_step.py bench    --repo ../official --out ../results/<machine>/gpu
The package's __init__.py (which imports compiled CUDA extensions we do not need) is bypassed; nothing is built.
"""
import argparse
import csv
import importlib
import json
import math
import platform
import statistics as st
import sys
import time
import types
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "ref"))
import official_refs as R  # noqa: E402  (verbatim official reference functions)


# ------------------------------------------------------------------------------------------ official module import
def _unavailable(*a, **k):
    raise RuntimeError("prefill kernel not available in this mode (only the decode step is used)")


class RefRMSNorm(torch.nn.Module):
    """Same interface as mamba_ssm.ops.triton.layernorm_gated.RMSNorm; forward = official rms_norm_ref."""
    def __init__(self, hidden_size, eps=1e-5, group_size=None, norm_before_gate=True, device=None, dtype=None):
        super().__init__()
        self.eps, self.group_size, self.norm_before_gate = eps, group_size, norm_before_gate
        self.weight = torch.nn.Parameter(torch.ones(hidden_size, device=device, dtype=dtype))
        self.register_parameter("bias", None)

    def forward(self, x, z=None):
        return R.rms_norm_ref(x, self.weight, self.bias, z=z, eps=self.eps, group_size=self.group_size,
                              norm_before_gate=self.norm_before_gate)


def ref_rotary_fwd(q, k, angle_state, angle_proj, dt, bias_q=None, bias_k=None, inplace=False, conjugate=False,
                   rotate_pairwise=True):
    """Contract of apply_rotary_qk_inference_fwd (Triton) via apply_rotary_qk_inference_reference."""
    return R.apply_rotary_qk_inference_reference(q, k, angle_state, angle_proj, dt, bias_q, bias_k,
                                                 conjugate=conjugate, rotate_pairwise=rotate_pairwise)


def ref_step_fn(state, Bstate, Xstate, A, B, C, D, x, dt, trap, xproj, outproj=None, state_out=None, out=None, z=None,
                zproj=None, tile_D=64, num_warps=2):
    """Contract of mamba3_step_fn (CuTe-DSL kernel) via selective_state_update_fused_ref_v2 (fp32 compute, like the kernel)."""
    y, new_state = R.selective_state_update_fused_ref_v2(state, A, B, C, xproj, x, zproj, z, dt, Bstate, Xstate, trap, D,
                                                         outproj)
    (state if state_out is None else state_out).copy_(new_state)
    out.copy_(y)


def import_official(repo: Path, emulate: bool):
    repo = Path(repo).resolve()
    if not (repo / "mamba_ssm" / "modules" / "mamba3.py").exists():
        sys.exit(f"official repo not found at {repo}: run setup_gpu.sh (or git clone state-spaces/mamba there)")
    pkg = types.ModuleType("mamba_ssm")
    pkg.__path__ = [str(repo / "mamba_ssm")]   # skip mamba_ssm/__init__.py (imports compiled CUDA extensions)
    sys.modules["mamba_ssm"] = pkg
    notes = []

    def stub(name, **attrs):
        m = types.ModuleType(name)
        m.__dict__.update(attrs)
        sys.modules[name] = m

    if emulate:
        stub("mamba_ssm.ops.triton.layernorm_gated", RMSNorm=RefRMSNorm)
        stub("mamba_ssm.ops.triton.mamba3.mamba3_siso_combined", mamba3_siso_combined=_unavailable)
        stub("mamba_ssm.ops.triton.mamba3.mamba3_mimo_rotary_step", apply_rotary_qk_inference_fwd=ref_rotary_fwd)
        stub("mamba_ssm.ops.cute.mamba3.mamba3_step_fn", mamba3_step_fn=ref_step_fn)
        stub("mamba_ssm.ops.tilelang.mamba3.mamba3_mimo", mamba3_mimo=_unavailable)
        notes.append("emulated: GPU kernels -> official PyTorch references (rms_norm_ref, "
                     "apply_rotary_qk_inference_reference, selective_state_update_fused_ref_v2)")
    else:
        try:
            import tilelang  # noqa: F401
        except Exception:
            stub("mamba_ssm.ops.tilelang.mamba3.mamba3_mimo", mamba3_mimo=_unavailable)
            notes.append("TileLang not installed: MIMO *prefill* kernel stubbed (the decode step does not use it)")
    m3 = importlib.import_module("mamba_ssm.modules.mamba3")
    if not emulate and m3.mamba3_step_fn is None:
        notes.append("CuTe-DSL step kernel NOT importable (pip install nvidia-cutlass-dsl quack-kernels cuda-python)")
    return m3, notes


# ------------------------------------------------------------------------------------------ validate
def load_trace_weights(mod, tdir: Path):
    L = lambda n: torch.from_numpy(np.load(tdir / f"w_{n}.npy"))
    with torch.no_grad():
        mod.in_proj.weight.copy_(L("in_proj"))
        mod.out_proj.weight.copy_(L("out_proj"))
        for name in ("dt_bias", "B_bias", "C_bias", "D"):
            getattr(mod, name).copy_(L(name))
        mod.B_norm.weight.copy_(L("B_norm_w"))
        mod.C_norm.weight.copy_(L("C_norm_w"))
        if mod.is_mimo:
            for name in ("mimo_x", "mimo_z", "mimo_o"):
                getattr(mod, name).copy_(L(name))


def validate(a):
    m3, notes = import_official(a.repo, a.emulate)
    dev = "cpu" if a.emulate else "cuda"
    if dev == "cuda":
        if not torch.cuda.is_available():
            sys.exit("no CUDA device (use --emulate on CPU)")
        torch.backends.cuda.matmul.allow_tf32 = False   # full fp32 matmuls for the comparison
        torch.backends.cudnn.allow_tf32 = False
    dtype = torch.float64 if a.emulate else torch.float32
    impl = "emulated on CPU (official refs)" if a.emulate else f"GPU kernels on {torch.cuda.get_device_name(0)}"
    for n in notes:
        print("note:", n)
    ok_all = True
    for name in a.which.split(","):
        tdir = Path(a.traces) / name
        cfg = json.loads((tdir / "config.json").read_text())
        mod = m3.Mamba3(d_model=cfg["d_model"], d_state=cfg["d_state"], headdim=cfg["headdim"], is_mimo=cfg["mimo"],
                        mimo_rank=cfg["R"] if cfg["mimo"] else 4, layer_idx=0, device=dev, dtype=dtype)
        load_trace_weights(mod, tdir)
        mod.eval()
        states = mod.allocate_inference_cache(1, 1, device=dev, dtype=dtype)
        U, Y = np.load(tdir / "u.npy"), np.load(tdir / "y_ref.npy")
        T = min(a.steps, U.shape[0])
        errs = []
        t0 = time.time()
        with torch.no_grad():
            for t in range(T):
                out = mod.step(torch.from_numpy(U[t:t + 1]).to(dev, dtype), *states)[0]
                y = out.double().cpu().numpy()[0]
                errs.append(float(np.abs(y - Y[t]).max() / np.abs(Y[t]).max()))
        es = float("nan")
        if T == U.shape[0]:
            ref = np.load(tdir / "state_ssm.npy")
            es = float(np.abs(states[1].double().cpu().numpy()[0] - ref).max() / np.abs(ref).max())
        ok = max(errs) <= a.tol and (math.isnan(es) or es <= a.tol)
        ok_all &= ok
        label = f"mamba3-mimo R={cfg['R']}" if cfg["mimo"] else "mamba3-siso"
        print(f"RESULT official Mamba3.step [{impl}] {label} steps={T}: worst step rel.err {max(errs):.2e} "
              f"(t={int(np.argmax(errs))}), mean {np.mean(errs):.2e}, final ssm state {es:.2e}, tol {a.tol:.0e}  "
              f"{'PASS' if ok else 'FAIL'}  ({(time.time() - t0) / T * 1e3:.2f} ms/step)")
    return 0 if ok_all else 1


# ------------------------------------------------------------------------------------------ bench (GPU)
def time_fn(fn, reps=3, iters=300):
    """us per call: CUDA-graph replay of 10 calls, timed with CUDA events; eager fallback."""
    with torch.no_grad():
        for _ in range(3):
            fn()
        torch.cuda.synchronize()
        try:
            s = torch.cuda.Stream()
            s.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(s):
                for _ in range(2):
                    fn()
            torch.cuda.current_stream().wait_stream(s)
            g = torch.cuda.CUDAGraph()
            with torch.cuda.graph(g):
                for _ in range(10):
                    fn()
            run, per, how = g.replay, 10, "cudagraph"
        except Exception as e:  # noqa: BLE001
            torch.cuda.synchronize()
            run, per, how = fn, 1, f"eager({type(e).__name__})"
        out = []
        for _ in range(reps):
            n = max(1, iters // per)
            e0, e1 = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            e0.record()
            for _ in range(n):
                run()
            e1.record()
            torch.cuda.synchronize()
            out.append(e0.elapsed_time(e1) * 1e3 / (n * per))
    return out, how


def counts(cfg, H, P, N, R):
    e = H * P * N
    fl = 5 * e + 2 * H * P if cfg == "m2" else (1 + 6 * R) * e + 10 * H * P * R
    return fl, 8.0 * e   # fp32 state read + write dominates the bytes


def capture_call(module_ns, attr, run):
    """Run `run()` once with module_ns.attr wrapped, return the real function and the exact args it got."""
    real = getattr(module_ns, attr)
    box = {}

    def wrap(*args, **kw):
        box["a"], box["k"] = args, kw
        return real(*args, **kw)
    setattr(module_ns, attr, wrap)
    try:
        with torch.no_grad():
            run()
    finally:
        setattr(module_ns, attr, real)
    return real, box.get("a"), box.get("k")


def bench(a):
    if not torch.cuda.is_available():
        sys.exit("bench needs a CUDA GPU")
    m3, notes = import_official(a.repo, emulate=False)
    try:
        m2 = importlib.import_module("mamba_ssm.modules.mamba2")
    except Exception as e:  # noqa: BLE001
        m2 = None
        notes.append(f"Mamba2 module not importable ({type(e).__name__}: {e}); Mamba-2 row uses the compiled reference")
    dev, dt = "cuda", {"bf16": torch.bfloat16, "fp16": torch.float16, "fp32": torch.float32}[a.dtype]
    gpu = torch.cuda.get_device_name(0)
    D, N, P = a.d_model, 128, 64
    H = 2 * D // P
    rows = []
    for n in notes:
        print("note:", n)
    for cfg, Rk in (("m2", 1), ("siso", 1), ("mimo2", 2), ("mimo4", 4)):
        for B in [int(x) for x in a.batch.split(",")]:
            fl, by = counts(cfg, H, P, N, Rk)
            rec = dict(gpu=gpu, dtype=a.dtype, config=cfg, R=Rk, batch=B, heads=H, headdim=P, d_state=N)
            try:
                torch.manual_seed(0)
                if cfg == "m2":
                    if m2 is None:
                        raise RuntimeError("no Mamba2 module")
                    mod = m2.Mamba2(d_model=D, d_state=N, headdim=P, expand=2, ngroups=1, layer_idx=0, device=dev, dtype=dt).eval()
                    conv, ssm = mod.allocate_inference_cache(B, 1, dtype=torch.float32)  # fp32 state, as Mamba-3
                    u = torch.randn(B, 1, D, device=dev, dtype=dt)
                    step = lambda: mod.step(u, conv, ssm)
                    real, args, kw = capture_call(m2, "selective_state_update", step)
                else:
                    mod = m3.Mamba3(d_model=D, d_state=N, headdim=P, is_mimo=Rk > 1, mimo_rank=max(Rk, 1), layer_idx=0,
                                    device=dev, dtype=dt).eval()
                    states = mod.allocate_inference_cache(B, 1, device=dev, dtype=dt)
                    u = torch.randn(B, D, device=dev, dtype=dt)
                    step = lambda: mod.step(u, *states)
                    real, args, kw = capture_call(m3, "mamba3_step_fn", step)
                for mode, fn in (("layer", step), ("core", (lambda: real(*args, **kw)) if args is not None else None)):
                    if fn is None:
                        continue
                    us, how = time_fn(fn, reps=a.reps)
                    rows.append({**rec, "impl": "official", "mode": mode, "timing": how, "us_median": st.median(us),
                                 "us_sd": st.stdev(us) if len(us) > 1 else 0.0, "n": len(us), "flops": fl * B, "bytes": by * B,
                                 "gflops": fl * B / (st.median(us) * 1e3), "gbps": by * B / (st.median(us) * 1e3)})
                    print(f"{cfg:6s} B={B:3d} {mode:5s} official  {st.median(us):9.2f} us  ({how})", flush=True)
            except Exception as e:  # noqa: BLE001  -> compiled official reference, same for all configs
                print(f"{cfg:6s} B={B:3d} official kernel path failed ({type(e).__name__}: {str(e)[:120]})", flush=True)
            us = bench_compiled_ref(cfg, Rk, B, H, P, N, dev, a)
            if us:
                rows.append({**rec, "impl": "compiled-ref", "mode": "core", "timing": "torch.compile+events",
                             "us_median": st.median(us), "us_sd": st.stdev(us) if len(us) > 1 else 0.0, "n": len(us),
                             "flops": fl * B, "bytes": by * B, "gflops": fl * B / (st.median(us) * 1e3),
                             "gbps": by * B / (st.median(us) * 1e3)})
                print(f"{cfg:6s} B={B:3d} core  compiled  {st.median(us):9.2f} us", flush=True)
            torch.cuda.empty_cache()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "gpu_step.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    meta = {"gpu": gpu, "capability": torch.cuda.get_device_capability(0), "torch": torch.__version__,
            "platform": platform.platform(), "notes": notes,
            "official_repo_commit": (Path(a.repo) / ".git").exists() and __import__("subprocess").run(
                ["git", "-C", str(a.repo), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()}
    (out / "gpu_meta.json").write_text(json.dumps(meta, indent=1))
    print(f"wrote {out / 'gpu_step.csv'}")


def bench_compiled_ref(cfg, R_, B, H, P, N, dev, a):
    """Same-compiler fallback: torch.compile of the official reference update (fp32 state), for every config."""
    g = torch.Generator(device=dev).manual_seed(0)
    rn = lambda *s: torch.randn(*s, device=dev, generator=g)
    try:
        if cfg == "m2":
            fn = R.selective_state_update_ref
            args = (rn(B, H, P, N), rn(B, H, P), rn(B, H, P), -torch.rand(H, P, N, device=dev) - 0.1, rn(B, 1, N), rn(B, 1, N),
                    torch.ones(H, P, device=dev), None, torch.zeros(H, P, device=dev), True)
        else:
            fn = R.selective_state_update_fused_ref_v2
            ones = torch.ones(R_, H, P, device=dev)
            args = (rn(B, H, P, N), -torch.rand(B, H, device=dev) - 0.1, rn(B, R_, H, N), rn(B, R_, H, N), ones / R_, rn(B, H, P),
                    ones, rn(B, H, P), torch.rand(B, H, device=dev) * 0.1, rn(B, R_, H, N), rn(B, H, P), torch.rand(B, H, device=dev),
                    torch.ones(H, device=dev), ones / R_)
        f = fn if a.no_compile else torch.compile(fn)
        us, _ = time_fn(lambda: f(*args), reps=a.reps, iters=100)
        return us
    except Exception as e:  # noqa: BLE001
        print(f"   compiled reference failed for {cfg}: {type(e).__name__}: {str(e)[:120]}")
        return None


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("validate")
    v.add_argument("--repo", default=str(HERE.parent / "official"))
    v.add_argument("--traces", default=str(HERE.parent / "traces"))
    v.add_argument("--which", default="mamba3_siso,mamba3_mimo4")
    v.add_argument("--steps", type=int, default=1000)
    v.add_argument("--tol", type=float, default=1e-4)
    v.add_argument("--emulate", action="store_true")
    b = sub.add_parser("bench")
    b.add_argument("--repo", default=str(HERE.parent / "official"))
    b.add_argument("--out", required=True)
    b.add_argument("--batch", default="1,16,64")
    b.add_argument("--dtype", default="bf16", choices=["bf16", "fp16", "fp32"])
    b.add_argument("--d-model", type=int, default=2048)
    b.add_argument("--reps", type=int, default=3)
    b.add_argument("--no-compile", action="store_true")
    a = ap.parse_args()
    sys.exit(validate(a) if a.cmd == "validate" else bench(a))


if __name__ == "__main__":
    main()
