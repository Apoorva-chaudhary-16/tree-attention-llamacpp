#!/usr/bin/env bash
# One-time setup for the GPU part of the bonus (optional; NVIDIA GPU; native Linux or WSL2).
# WSL2: install ONLY the Windows NVIDIA driver (no Linux driver inside WSL); `nvidia-smi` must work in WSL.
# Creates bonus/mamba3/gpu/.venv-gpu (separate from the CPU environment) and clones the official repo, pinned.
# Nothing is compiled: Triton and CuTe-DSL kernels are compiled just in time on first use.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; OFF="$HERE/../official"
COMMIT=e9594ce1c732d97440f0332fdc43170a2294dbfa
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv || { echo "!! no NVIDIA GPU visible"; exit 1; }
if [ ! -d "$OFF/.git" ]; then
  git clone --filter=blob:none https://github.com/state-spaces/mamba.git "$OFF"
fi
git -C "$OFF" checkout -q "$COMMIT" && echo "== official repo at $COMMIT"
python3 -m venv "$HERE/.venv-gpu"
# shellcheck disable=SC1091
source "$HERE/.venv-gpu/bin/activate"
pip install -q --upgrade pip
# CUDA 12.8 wheels need a driver that reports "CUDA Version: 12.8" or newer in nvidia-smi; otherwise use cu126.
pip install torch --index-url "https://download.pytorch.org/whl/${CUDA_WHL:-cu128}"   # includes Triton
pip install einops numpy pandas matplotlib huggingface_hub
# CuTe-DSL step kernel (the official Mamba3.step path). If this fails, `bench` still times every config with the
# compiled official reference (same compiler for all), and `validate` reports the kernel as unavailable.
pip install nvidia-cutlass-dsl quack-kernels cuda-python || echo "!! CuTe-DSL stack did not install (see above)"
python - <<'PY'
import torch; print("torch", torch.__version__, "| GPU:", torch.cuda.get_device_name(0), torch.cuda.get_device_capability(0))
for m in ("triton", "cutlass", "quack"):
    try: __import__(m); print(f"{m}: ok")
    except Exception as e: print(f"{m}: NOT available ({type(e).__name__})")
PY
