#!/usr/bin/env python3
"""Bonus analysis: tables + plots from bench_step.csv and the test logs, and ANSWER.md with the one-paragraph
answer to the bonus question (does MIMO's extra compute come at little cost on this CPU?), with numbers.

  python3 analyze.py results/<machine>
"""
import re
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

NAMES = {"m2": "Mamba-2", "siso": "Mamba-3 SISO", "mimo2": "Mamba-3 MIMO R=2", "mimo4": "Mamba-3 MIMO R=4"}
MODES = {"core-dram": "state update, states in DRAM (real decode)", "core-cache": "state update, state cache-resident",
         "layer": "full layer step (bf16 projections)"}


def main():
    out = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
    df = pd.read_csv(out / "bench_step.csv")
    g = df.groupby(["config", "mode", "threads"]).agg(ns=("ns_per_step", "median"), ns_sd=("ns_per_step", "std"),
                                                     gflops=("gflops", "median"), gbps=("gbps", "median"),
                                                     ai=("flop_per_byte", "first"), flops=("flops_per_step", "first"),
                                                     layers=("layers", "first")).reset_index()
    g["us"] = g["ns"] / 1e3
    Tmax, simd = int(g["threads"].max()), df["simd"].iloc[0]
    rows = ["| step | mode | threads | µs per step (median of 3) | FLOP/byte | GFLOP/s | GB/s | vs SISO |",
            "|---|---|---:|---:|---:|---:|---:|---:|"]
    for (mode, T), sub in g.groupby(["mode", "threads"]):
        if T not in (1, Tmax):
            continue
        base = sub[sub["config"] == "siso"]["us"]
        for r in sub.sort_values("config").itertuples():
            rel = f"x{r.us / base.iloc[0]:.2f}" if len(base) else ""
            rows.append(f"| {NAMES[r.config]} | {mode} | {T} | {r.us:.1f} | {r.ai:.2f} | {r.gflops:.1f} | {r.gbps:.1f} | {rel} |")
    # ---------------------------------------------------------------- plots
    fig, axs = plt.subplots(1, 3, figsize=(13, 3.8))
    for ax, mode in zip(axs, ["core-dram", "core-cache", "layer"]):
        for cfg, s in g[g["mode"] == mode].groupby("config"):
            ax.plot(s["threads"], s["us"], marker="o", label=NAMES[cfg])
        ax.set_title(MODES[mode], fontsize=9); ax.set_xlabel("threads"); ax.set_ylabel("µs per decode step (one layer)")
        ax.set_yscale("log"); ax.grid(alpha=0.3); ax.legend(fontsize=7)
    fig.suptitle(f"Decode step at equal state size (64 heads x 64 x 128 = 2 MiB fp32 / layer), {simd}")
    fig.tight_layout(); fig.savefig(out / "bonus_time_per_step.png", dpi=130); plt.close(fig)
    fig, ax = plt.subplots(figsize=(6, 4))
    for cfg, s in g[(g["mode"] != "layer")].groupby("config"):
        ax.scatter(s["ai"], s["gflops"], label=NAMES[cfg], s=18 + 6 * s["threads"])
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("arithmetic intensity (FLOP/byte)"); ax.set_ylabel("achieved GFLOP/s")
    ax.set_title("Roofline view of the state update (marker size = threads)"); ax.grid(alpha=0.3, which="both"); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(out / "bonus_roofline.png", dpi=130); plt.close(fig)
    # ---------------------------------------------------------------- correctness summary
    tests = []
    for log in ("crosscheck.log", "official_module_cpu.log", "test_step.log", "ggml_op_test.log", "gpu/gpu_validation.log"):
        p = out / log
        if p.exists():
            tests += [l.strip() for l in p.read_text().splitlines() if l.startswith(("RESULT", "crosscheck"))]
    worst = [float(x) for l in tests for x in re.findall(r"worst step rel\.err=([\d.e+-]+)", l)]
    # ---------------------------------------------------------------- the answer
    def us(cfg, mode, T):
        s = g[(g["config"] == cfg) & (g["mode"] == mode) & (g["threads"] == T)]
        return float(s["us"].iloc[0]) if len(s) else float("nan")
    d1, dT = us("mimo4", "core-dram", 1) / us("siso", "core-dram", 1), us("mimo4", "core-dram", Tmax) / us("siso", "core-dram", Tmax)
    c1 = us("mimo4", "core-cache", 1) / us("siso", "core-cache", 1)
    lT = us("mimo4", "layer", Tmax) / us("siso", "layer", Tmax)
    ai = g[g["config"].isin(["siso", "mimo4"]) & (g["mode"] == "core-dram")].groupby("config")["ai"].first()
    fl = g[g["config"].isin(["siso", "mimo4"]) & (g["mode"] == "core-dram")].groupby("config")["flops"].first()
    if dT <= 1.25:
        verdict = (f"**yes: on this CPU MIMO's extra compute comes at little cost** in the realistic, DRAM-bound decode case "
                   f"({100 * (dT - 1):+.0f}% at {Tmax} threads), because the step is limited by streaming the state, not by arithmetic")
    elif lT <= 1.15:
        verdict = (f"**partly: the MIMO state update itself is x{dT:.2f} slower** (compute-bound on this CPU), but a full layer "
                   f"step is only {100 * (lT - 1):+.0f}% slower, because streaming the projection weights dominates the layer")
    else:
        verdict = f"**no: on this CPU MIMO slows decode** (state update x{dT:.2f}, full layer x{lT:.2f} at {Tmax} threads)"
    para = (f"At a fixed state of 64 heads x 64 x 128 (2 MiB fp32 per layer), one Mamba-3 MIMO (R=4) decode step performs "
            f"{fl.get('mimo4', float('nan')) / fl.get('siso', float('nan')):.1f}x the state-update FLOPs of SISO "
            f"(arithmetic intensity {ai.get('mimo4', float('nan')):.2f} vs {ai.get('siso', float('nan')):.2f} FLOP/byte). "
            f"With every layer's state in DRAM, as in real decoding, MIMO takes {us('mimo4', 'core-dram', 1):.0f} µs vs "
            f"{us('siso', 'core-dram', 1):.0f} µs for SISO at 1 thread (x{d1:.2f})"
            + (f" and {us('mimo4', 'core-dram', Tmax):.0f} µs vs {us('siso', 'core-dram', Tmax):.0f} µs at {Tmax} threads (x{dT:.2f})"
               if Tmax > 1 else " (this machine has one core)") + "; the Mamba-2 step at the same state size takes "
            f"{us('m2', 'core-dram', Tmax):.0f} µs. With the state cache-resident the gap is x{c1:.2f} (1 thread). "
            f"Including the bf16 projections, a whole MIMO layer step costs x{lT:.2f} the SISO one at {Tmax} thread(s). "
            f"Answer: {verdict}.")
    gpu_md = gpu_section(out, dT, Tmax)
    md = [f"# Bonus answer ({out.name}, {simd})\n", para + "\n", *gpu_md,
          "## Correctness (1000 decode steps vs the official float64 references, tolerance 1e-4)\n", "```", *tests, "```",
          f"\nWorst per-step relative error over all kernels: {max(worst) if worst else float('nan'):.1e}\n",
          "## Time per step and arithmetic intensity\n", *rows,
          "\nPlots: `bonus_time_per_step.png`, `bonus_roofline.png`. FLOP/byte uses analytical counts "
          "(kernels/src/bench_step.cpp: flops_core / bytes_core): SISO 7 and MIMO-R (1+6R) FLOP per state element, "
          "8 bytes per element (fp32 state read + write)."]
    (out / "ANSWER.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))


def gpu_section(out: Path, cpu_ratio: float, Tmax: int) -> list:
    """Same question on our own GPU (gpu/run_gpu.sh): does MIMO cost little there, as the paper/brief says?"""
    cands = sorted(out.glob("gpu/gpu_step.csv")) or sorted(out.parent.glob("*/gpu/gpu_step.csv"))
    if not cands:
        return []
    G = pd.read_csv(cands[0])
    gname = G["gpu"].iloc[0]
    lines = [f"## Same question on our GPU ({gname}, `{cands[0].parent.parent.name}`)\n"]
    for impl in ("official", "compiled-ref"):
        c = G[(G["impl"] == impl) & (G["mode"] == "core")]
        if c.empty or not {"siso", "mimo4"} <= set(c["config"]):
            continue
        us = lambda cfg, B, mode="core": G[(G["impl"] == impl) & (G["mode"] == mode) & (G["config"] == cfg) & (G["batch"] == B)]["us_median"]
        Bmax = int(c["batch"].max())
        rb, r1 = float(us("mimo4", Bmax).iloc[0] / us("siso", Bmax).iloc[0]), float(us("mimo4", 1).iloc[0] / us("siso", 1).iloc[0])
        lay = us("mimo4", 1, "layer"), us("siso", 1, "layer")
        rl = float(lay[0].iloc[0] / lay[1].iloc[0]) if len(lay[0]) and len(lay[1]) else float("nan")
        kind = "the official GPU kernels" if impl == "official" else "torch.compile of the official reference (official kernel unavailable)"
        lines.append(f"With {kind}, the MIMO R=4 state update costs x{rb:.2f} the SISO one at batch {Bmax} and x{r1:.2f} at batch 1"
                     + (f"; a full layer step costs x{rl:.2f}" if rl == rl else "") + f" (CPU, {Tmax} thread(s), DRAM-resident: x{cpu_ratio:.2f}). "
                     + ("On this GPU the extra compute is nearly free, as the paper reports, while the CPU pays for it."
                        if rb <= 1.25 and cpu_ratio > 1.25 else
                        "On this GPU the extra compute is nearly free, and on our CPU too." if rb <= 1.25 else
                        "Even on this GPU MIMO costs noticeably more at this size."))
        lines.append("")
        lines.append("| step | batch | mode | µs (median of 3) | GB/s | GFLOP/s |\n|---|---:|---|---:|---:|---:|")
        for r in G[G["impl"] == impl].sort_values(["mode", "batch", "config"]).itertuples():
            lines.append(f"| {NAMES[r.config]} | {r.batch} | {r.mode} | {r.us_median:.2f} | {r.gbps:.0f} | {r.gflops:.0f} |")
        lines.append("")
        break
    return lines


if __name__ == "__main__":
    main()
