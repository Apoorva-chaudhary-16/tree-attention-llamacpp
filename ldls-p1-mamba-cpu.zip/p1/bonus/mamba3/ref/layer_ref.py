#!/usr/bin/env python3
"""One-layer decode steps for Mamba-3 (SISO and MIMO) and Mamba-2, built only from official code.

mamba3_step : line-by-line port of state-spaces/mamba  mamba_ssm/modules/mamba3.py::Mamba3.step
              (default config: is_outproj_norm=False), with each GPU kernel replaced by the official
              pure-PyTorch reference written for it:
                 self.B_norm / self.C_norm        -> rms_norm_ref
                 apply_rotary_qk_inference_fwd    -> apply_rotary_qk_inference_reference
                 mamba3_step_fn (CuTe)            -> selective_state_update_fused_ref_v2
mamba2_step : port of mamba_ssm/modules/mamba2.py::Mamba2.step (pure-PyTorch conv path) with
              selective_state_update_ref and rms_norm_ref (default config: rmsnorm, norm_before_gate=False)

Commands:
  python3 layer_ref.py crosscheck            # our Mamba3.step port vs the independent official
                                             # mamba3_siso_step_ref (tests/ops/triton/test_mamba3_siso.py)
  python3 layer_ref.py traces --out DIR      # 1000-step float64 reference traces for the C++ tests
Random weights: no public Mamba-3 checkpoint was usable (see ../README.md), which the brief allows for
speed and correctness tests.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from einops import rearrange

sys.path.insert(0, str(Path(__file__).resolve().parent))
from official_refs import (apply_rotary_qk_inference_reference, heavy_tail_activation,  # noqa: E402
                           mamba3_siso_step_ref, rms_norm_ref, selective_state_update_fused_ref_v2,
                           selective_state_update_ref)


# ----------------------------------------------------------------------------------------- configs
def m3_dims(d_model, d_state=128, expand=2, headdim=64, ngroups=1, rope_fraction=0.5, mimo=False, rank=4):
    d_inner = expand * d_model
    split = int(d_state * rope_fraction)
    split -= split % 2
    R = rank if mimo else 1
    H = d_inner // headdim
    A = split // 2
    return dict(kind="mamba3", d_model=d_model, d_state=d_state, headdim=headdim, nheads=H, ngroups=ngroups,
                d_inner=d_inner, mimo=bool(mimo), R=R, num_angles=A, A_floor=1e-4,
                d_in_proj=2 * d_inner + 2 * d_state * ngroups * R + 3 * H + A)


def m2_dims(d_model, d_state=128, expand=2, headdim=64, ngroups=1, d_conv=4):
    d_inner = expand * d_model
    H = d_inner // headdim
    return dict(kind="mamba2", d_model=d_model, d_state=d_state, headdim=headdim, nheads=H, ngroups=ngroups,
                d_inner=d_inner, d_conv=d_conv, conv_dim=d_inner + 2 * ngroups * d_state,
                d_in_proj=2 * d_inner + 2 * ngroups * d_state + H)


def inv_softplus_dt(n, g):
    dt = torch.exp(torch.rand(n, generator=g, dtype=torch.float64) * (math.log(0.1) - math.log(1e-3)) + math.log(1e-3))
    dt = dt.clamp(min=1e-4)
    return dt + torch.log(-torch.expm1(-dt))


def init_params(c, seed=0):
    """Random parameters in float32 (what the C++ kernel uses). Init follows the modules' __init__,
    with small perturbations on biases / norm weights so that every term is exercised by the test."""
    g = torch.Generator().manual_seed(seed)
    rn = lambda *s: torch.randn(*s, generator=g, dtype=torch.float64)
    p = {}
    if c["kind"] == "mamba3":
        H, R, N, P = c["nheads"], c["R"], c["d_state"], c["headdim"]
        p["in_proj"] = rn(c["d_in_proj"], c["d_model"]) / math.sqrt(c["d_model"])
        p["dt_bias"] = inv_softplus_dt(H, g)
        p["B_bias"] = 1 + 0.1 * rn(H, R, N)
        p["C_bias"] = 1 + 0.1 * rn(H, R, N)
        p["B_norm_w"] = 1 + 0.1 * rn(N)
        p["C_norm_w"] = 1 + 0.1 * rn(N)
        if c["mimo"]:
            p["mimo_x"] = torch.ones(H, R, P, dtype=torch.float64) / R + 0.05 * rn(H, R, P)
            p["mimo_z"] = torch.ones(H, R, P, dtype=torch.float64) + 0.05 * rn(H, R, P)
            p["mimo_o"] = torch.ones(H, R, P, dtype=torch.float64) / R + 0.05 * rn(H, R, P)
        p["D"] = 1 + 0.1 * rn(H)
        p["out_proj"] = rn(c["d_model"], c["d_inner"]) / math.sqrt(c["d_inner"])
    else:
        H = c["nheads"]
        p["in_proj"] = rn(c["d_in_proj"], c["d_model"]) / math.sqrt(c["d_model"])
        p["conv_w"] = rn(c["conv_dim"], c["d_conv"]) * 0.3
        p["conv_b"] = 0.1 * rn(c["conv_dim"])
        p["dt_bias"] = inv_softplus_dt(H, g)
        p["A_log"] = torch.log(torch.empty(H, dtype=torch.float64).uniform_(1, 16, generator=g))
        p["D"] = 1 + 0.1 * rn(H)
        p["norm_w"] = 1 + 0.1 * rn(c["d_inner"])
        p["out_proj"] = rn(c["d_model"], c["d_inner"]) / math.sqrt(c["d_inner"])
    # round to float32 so that the float64 reference and the float32 kernel use identical values
    return {k: v.to(torch.float32).to(torch.float64) for k, v in p.items()}


def init_states(c, dtype=torch.float64):
    if c["kind"] == "mamba3":
        return dict(angle=torch.zeros(1, c["nheads"], c["num_angles"], dtype=dtype),
                    ssm=torch.zeros(1, c["nheads"], c["headdim"], c["d_state"], dtype=dtype),
                    k=torch.zeros(1, c["R"], c["nheads"], c["d_state"], dtype=dtype),
                    v=torch.zeros(1, c["nheads"], c["headdim"], dtype=dtype))
    return dict(conv=torch.zeros(1, c["conv_dim"], c["d_conv"], dtype=dtype),
                ssm=torch.zeros(1, c["nheads"], c["headdim"], c["d_state"], dtype=dtype))


# ----------------------------------------------------------------------------------------- Mamba-3
def mamba3_preprocess(c, p, u):
    """Mamba3.step up to (and including) the rotary kernel. Returns everything the state update needs."""
    H, R, N, P, G = c["nheads"], c["R"], c["d_state"], c["headdim"], c["ngroups"]
    zxBCdt = u @ p["in_proj"].T                                           # in_proj
    z, x, B, C, dd_dt, dd_A, trap, angles = torch.split(
        zxBCdt, [c["d_inner"], c["d_inner"], N * G * R, N * G * R, H, H, H, c["num_angles"]], dim=-1)
    # --- Mamba3._preprocess
    _A = -heavy_tail_activation(dd_A)
    _A = torch.clamp(_A, max=-c["A_floor"])
    DT = F.softplus(dd_dt + p["dt_bias"])
    trap_s = torch.sigmoid(trap)
    B = rearrange(B, "b (r g s) -> b r g s", g=G, r=R)
    C = rearrange(C, "b (r g s) -> b r g s", g=G, r=R)
    B = rms_norm_ref(B, p["B_norm_w"], None, eps=1e-5)                    # self.B_norm(B)
    C = rms_norm_ref(C, p["C_norm_w"], None, eps=1e-5)                    # self.C_norm(C)
    B = B.expand(-1, -1, H, -1)
    C = C.expand(-1, -1, H, -1)
    x = rearrange(x, "b (h p) -> b h p", p=P)
    z = rearrange(z, "b (h p) -> b h p", p=P)
    ang = angles.unsqueeze(-2).expand(-1, H, -1)
    return dict(z=z, x=x, B=B, C=C, DT=DT, trap=trap_s, trap_raw=trap, A=_A, angles=ang, angles_raw=angles)


def mamba3_step(c, p, u, st):
    """One decode step of one Mamba-3 layer. u: (1, d_model). Returns (out, new_states, extras)."""
    H, R, P = c["nheads"], c["R"], c["headdim"]
    q = mamba3_preprocess(c, p, u)
    bias_q = rearrange(p["C_bias"], "h r n -> r h n")
    bias_k = rearrange(p["B_bias"], "h r n -> r h n")
    C, B, nxt_angle = apply_rotary_qk_inference_reference(                # apply_rotary_qk_inference_fwd
        q=q["C"], k=q["B"], angle_state=st["angle"], angle_proj=q["angles"], dt=q["DT"],
        bias_q=bias_q, bias_k=bias_k, conjugate=False, rotate_pairwise=not c["mimo"])
    if c["mimo"]:
        xpj = rearrange(p["mimo_x"], "h r p -> r h p", p=P).contiguous()
        zpj = rearrange(p["mimo_z"], "h r p -> r h p", p=P).contiguous()
        outpj = rearrange(p["mimo_o"], "h r p -> r h p", p=P).contiguous()
    else:
        xpj = zpj = outpj = torch.ones(R, H, P, dtype=u.dtype)
    y, new_ssm = selective_state_update_fused_ref_v2(                     # mamba3_step_fn (CuTe)
        st["ssm"], q["A"], B, C, xpj, q["x"], zpj, q["z"], q["DT"], st["k"], st["v"], q["trap"], p["D"], outpj,
        compute_dtype=u.dtype)
    yi = rearrange(y, "b h p -> b (h p)")
    out = yi @ p["out_proj"].T                                            # out_proj
    new = dict(angle=nxt_angle, ssm=new_ssm, k=B, v=q["x"])
    return out, new, dict(yi=yi, pre=q, C_rot=C, B_rot=B)


# ----------------------------------------------------------------------------------------- Mamba-2
def mamba2_step(c, p, u, st):
    H, P, N, G = c["nheads"], c["headdim"], c["d_state"], c["ngroups"]
    zxbcdt = u @ p["in_proj"].T
    z, xBC, dt = torch.split(zxbcdt, [c["d_inner"], c["conv_dim"], H], dim=-1)
    conv_state = torch.roll(st["conv"], shifts=-1, dims=-1).clone()      # conv step (pure PyTorch path)
    conv_state[:, :, -1] = xBC
    xBC = torch.sum(conv_state * p["conv_w"], dim=-1) + p["conv_b"]
    xBC = F.silu(xBC)
    x, B, C = torch.split(xBC, [c["d_inner"], G * N, G * N], dim=-1)
    A = -torch.exp(p["A_log"])
    A_r = A[:, None, None].expand(H, P, N)
    dt_r = dt[:, :, None].expand(-1, H, P)
    dtb_r = p["dt_bias"][:, None].expand(H, P)
    D_r = p["D"][:, None].expand(H, P)
    ssm = st["ssm"].clone()
    y = selective_state_update_ref(ssm, rearrange(x, "b (h p) -> b h p", p=P), dt_r, A_r,
                                   rearrange(B, "b (g n) -> b g n", g=G), rearrange(C, "b (g n) -> b g n", g=G),
                                   D_r, z=None, dt_bias=dtb_r, dt_softplus=True)   # updates ssm in place
    y = rearrange(y, "b h p -> b (h p)")
    y = rms_norm_ref(y, p["norm_w"], None, z=z, eps=1e-5, group_size=c["d_inner"] // G, norm_before_gate=False)
    out = y @ p["out_proj"].T
    return out, dict(conv=conv_state, ssm=ssm), dict(yi=y)


# ----------------------------------------------------------------------------------------- commands
def crosscheck(steps=64, d_model=256):
    """Our port of Mamba3.step (rotary ref + fused ref) vs the authors' independent SISO step reference."""
    # NOTE: mamba3_siso_step_ref casts SSM_State to float32 whenever Input_States is passed, so it is
    # called ONCE for the whole sequence (zero initial state; float64 promotion keeps it exact).
    c = m3_dims(d_model, mimo=False)
    p = init_params(c, seed=1)
    st = init_states(c)
    g = torch.Generator().manual_seed(2)
    ys, pres = [], []
    for t in range(steps):
        u = torch.randn(1, d_model, generator=g, dtype=torch.float64)
        out, st, ex = mamba3_step(c, p, u, st)
        ys.append(ex["yi"].reshape(1, c["nheads"], c["headdim"]))
        pres.append(ex["pre"])
    cat = lambda k: torch.stack([q[k] for q in pres], dim=1)               # (1, T, ...)
    y_ref, states_ref = mamba3_siso_step_ref(
        Q=cat("C")[:, :, 0], K=cat("B")[:, :, 0], V=cat("x"),
        ADT=(cat("A") * cat("DT")).transpose(1, 2), DT=cat("DT").transpose(1, 2),
        Trap=cat("trap_raw").transpose(1, 2), Q_bias=p["C_bias"][:, 0], K_bias=p["B_bias"][:, 0],
        Angles=cat("angles_raw")[:, :, None, :].expand(-1, -1, c["nheads"], -1), D=p["D"], Z=cat("z"))
    y_ours = torch.stack(ys, dim=1)
    d_out = ((y_ours - y_ref).abs().amax(dim=(0, 2, 3)) / y_ref.abs().amax(dim=(0, 2, 3))).max().item()
    d_state = ((st["ssm"] - states_ref[1]).abs().max() / states_ref[1].abs().max()).item()
    worst = max(d_out, d_state)
    ok = worst < 1e-10
    print(f"crosscheck SISO: our Mamba3.step port (rotary_ref + fused_ref_v2) vs official mamba3_siso_step_ref, "
          f"{steps} steps, float64: max rel. diff output {d_out:.1e}, final state {d_state:.1e} "
          f"-> {'PASS' if ok else 'FAIL'}")
    return ok


def save_npy(d: Path, name, t):
    a = t.detach().cpu().numpy() if isinstance(t, torch.Tensor) else np.asarray(t)
    np.save(d / f"{name}.npy", np.ascontiguousarray(a))


def make_trace(c, out: Path, steps: int, seed: int):
    out.mkdir(parents=True, exist_ok=True)
    p = init_params(c, seed)
    st = init_states(c)
    g = torch.Generator().manual_seed(seed + 100)
    U = torch.randn(steps, c["d_model"], generator=g, dtype=torch.float64).to(torch.float32).to(torch.float64)
    Y = torch.empty(steps, c["d_model"], dtype=torch.float64)
    step = mamba3_step if c["kind"] == "mamba3" else mamba2_step
    for t in range(steps):
        y, st, _ = step(c, p, U[t:t + 1], st)
        Y[t] = y[0]
    for k, v in p.items():
        save_npy(out, "w_" + k, v.to(torch.float32))
    save_npy(out, "u", U.to(torch.float32))
    save_npy(out, "y_ref", Y)
    for k, v in st.items():
        save_npy(out, "state_" + k, v[0])
    (out / "config.json").write_text(json.dumps({**c, "steps": steps, "seed": seed,
                                                 "reference": "official state-spaces/mamba refs, float64"}, indent=1))
    print(f"trace {out.name}: {c['kind']} R={c.get('R', '-')} d_model={c['d_model']} H={c['nheads']} "
          f"P={c['headdim']} N={c['d_state']} steps={steps}  |y| max {Y.abs().max():.3f}")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("crosscheck")
    t = sub.add_parser("traces")
    t.add_argument("--out", required=True)
    t.add_argument("--steps", type=int, default=1000)
    t.add_argument("--d-model", type=int, default=512)
    t.add_argument("--d-state", type=int, default=128)
    t.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    torch.set_num_threads(max(1, torch.get_num_threads()))
    if a.cmd == "crosscheck":
        sys.exit(0 if crosscheck() else 1)
    out = Path(a.out)
    make_trace(m3_dims(a.d_model, d_state=a.d_state, mimo=False), out / "mamba3_siso", a.steps, a.seed)
    make_trace(m3_dims(a.d_model, d_state=a.d_state, mimo=True, rank=4), out / "mamba3_mimo4", a.steps, a.seed)
    make_trace(m2_dims(a.d_model, d_state=a.d_state), out / "mamba2", a.steps, a.seed)


if __name__ == "__main__":
    main()
