# Bonus answer (sandbox-xeon, avx512)

At a fixed state of 64 heads x 64 x 128 (2 MiB fp32 per layer), one Mamba-3 MIMO (R=4) decode step performs 3.6x the state-update FLOPs of SISO (arithmetic intensity 2.74 vs 0.84 FLOP/byte). With every layer's state in DRAM, as in real decoding, MIMO takes 726 µs vs 315 µs for SISO at 1 thread (x2.30) and 415 µs vs 193 µs at 2 threads (x2.15); the Mamba-2 step at the same state size takes 208 µs. With the state cache-resident the gap is x3.69 (1 thread). Including the bf16 projections, a whole MIMO layer step costs x1.20 the SISO one at 2 thread(s). Answer: **no: on this CPU MIMO slows decode** (state update x2.15, full layer x1.20 at 2 threads).

## Correctness (1000 decode steps vs the official float64 references, tolerance 1e-4)

```
crosscheck SISO: our Mamba3.step port (rotary_ref + fused_ref_v2) vs official mamba3_siso_step_ref, 64 steps, float64: max rel. diff output 4.4e-16, final state 2.3e-15 -> PASS
RESULT official Mamba3.step [emulated on CPU (official refs)] mamba3-siso steps=1000: worst step rel.err 6.43e-07 (t=523), mean 2.37e-07, final ssm state 7.02e-06, tol 1e-04  PASS  (2.00 ms/step)
RESULT official Mamba3.step [emulated on CPU (official refs)] mamba3-mimo R=4 steps=1000: worst step rel.err 6.52e-07 (t=999), mean 2.41e-07, final ssm state 9.87e-06, tol 1e-04  PASS  (2.61 ms/step)
RESULT mamba3-siso        impl=scalar  steps=1000 threads=2  worst step rel.err=1.18e-06 (t=213)  mean=5.47e-07  state[angle (abs, mod 2pi)]=1.60e-05  state[k (prev rotated B)]=7.21e-06  state[ssm]=6.22e-06  state[v (prev x)]=2.34e-07  tol=1e-04  PASS  (0.509 ms/step)
RESULT mamba3-siso        impl=avx512  steps=1000 threads=2  worst step rel.err=4.26e-07 (t=10)  mean=2.32e-07  state[angle (abs, mod 2pi)]=1.65e-05  state[k (prev rotated B)]=4.46e-06  state[ssm]=3.25e-06  state[v (prev x)]=1.42e-07  tol=1e-04  PASS  (0.196 ms/step)
RESULT mamba3-siso        impl=avx2    steps=1000 threads=2  worst step rel.err=4.69e-07 (t=216)  mean=2.51e-07  state[angle (abs, mod 2pi)]=1.60e-05  state[k (prev rotated B)]=5.00e-06  state[ssm]=4.54e-06  state[v (prev x)]=1.55e-07  tol=1e-04  PASS  (0.221 ms/step)
RESULT mamba3-mimo R=4    impl=scalar  steps=1000 threads=2  worst step rel.err=1.05e-06 (t=148)  mean=5.49e-07  state[angle (abs, mod 2pi)]=1.12e-05  state[k (prev rotated B)]=8.62e-06  state[ssm]=8.34e-06  state[v (prev x)]=2.34e-07  tol=1e-04  PASS  (1.103 ms/step)
RESULT mamba3-mimo R=4    impl=avx512  steps=1000 threads=2  worst step rel.err=4.22e-07 (t=139)  mean=2.36e-07  state[angle (abs, mod 2pi)]=1.17e-05  state[k (prev rotated B)]=9.06e-06  state[ssm]=5.31e-06  state[v (prev x)]=1.42e-07  tol=1e-04  PASS  (0.319 ms/step)
RESULT mamba3-mimo R=4    impl=avx2    steps=1000 threads=2  worst step rel.err=4.69e-07 (t=481)  mean=2.59e-07  state[angle (abs, mod 2pi)]=1.21e-05  state[k (prev rotated B)]=9.51e-06  state[ssm]=7.17e-06  state[v (prev x)]=1.55e-07  tol=1e-04  PASS  (0.262 ms/step)
RESULT mamba2             impl=scalar  steps=1000 threads=2  worst step rel.err=1.01e-06 (t=330)  mean=5.00e-07  state[conv]=3.09e-07  state[ssm]=2.86e-07  tol=1e-04  PASS  (0.515 ms/step)
RESULT mamba2             impl=avx512  steps=1000 threads=2  worst step rel.err=4.20e-07 (t=50)  mean=2.13e-07  state[conv]=1.07e-07  state[ssm]=3.50e-07  tol=1e-04  PASS  (0.209 ms/step)
RESULT mamba2             impl=avx2    steps=1000 threads=2  worst step rel.err=4.18e-07 (t=594)  mean=2.34e-07  state[conv]=1.16e-07  state[ssm]=1.69e-07  tol=1e-04  PASS  (0.176 ms/step)
RESULT ggml-graph mamba3-siso R=1 threads=2 steps=1000: max rel.err vs official float64 trace 4.73e-07, vs direct C++ step 4.41e-07  PASS   time/step: ggml graph 0.258 ms, direct 0.202 ms
RESULT ggml-graph mamba3-mimo R=4 threads=2 steps=1000: max rel.err vs official float64 trace 4.51e-07, vs direct C++ step 4.03e-07  PASS   time/step: ggml graph 0.427 ms, direct 0.370 ms
```

Worst per-step relative error over all kernels: 1.2e-06

## Time per step and arithmetic intensity

| step | mode | threads | µs per step (median of 3) | FLOP/byte | GFLOP/s | GB/s | vs SISO |
|---|---|---:|---:|---:|---:|---:|---:|
| Mamba-2 | core-cache | 1 | 108.9 | 0.62 | 24.2 | 38.8 | x0.59 |
| Mamba-3 MIMO R=2 | core-cache | 1 | 302.6 | 1.51 | 22.8 | 15.1 | x1.63 |
| Mamba-3 MIMO R=4 | core-cache | 1 | 684.5 | 2.74 | 19.4 | 7.1 | x3.69 |
| Mamba-3 SISO | core-cache | 1 | 185.4 | 0.84 | 20.0 | 23.8 | x1.00 |
| Mamba-2 | core-cache | 2 | 65.1 | 0.62 | 40.4 | 64.9 | x0.61 |
| Mamba-3 MIMO R=2 | core-cache | 2 | 182.8 | 1.51 | 37.7 | 24.9 | x1.72 |
| Mamba-3 MIMO R=4 | core-cache | 2 | 441.9 | 2.74 | 30.0 | 11.0 | x4.15 |
| Mamba-3 SISO | core-cache | 2 | 106.5 | 0.84 | 34.8 | 41.4 | x1.00 |
| Mamba-2 | core-dram | 1 | 296.3 | 0.62 | 8.9 | 14.3 | x0.94 |
| Mamba-3 MIMO R=2 | core-dram | 1 | 412.9 | 1.51 | 16.7 | 11.0 | x1.31 |
| Mamba-3 MIMO R=4 | core-dram | 1 | 726.2 | 2.74 | 18.3 | 6.7 | x2.30 |
| Mamba-3 SISO | core-dram | 1 | 315.0 | 0.84 | 11.8 | 14.0 | x1.00 |
| Mamba-2 | core-dram | 2 | 207.6 | 0.62 | 12.7 | 20.4 | x1.07 |
| Mamba-3 MIMO R=2 | core-dram | 2 | 245.1 | 1.51 | 28.1 | 18.6 | x1.27 |
| Mamba-3 MIMO R=4 | core-dram | 2 | 415.4 | 2.74 | 31.9 | 11.7 | x2.15 |
| Mamba-3 SISO | core-dram | 2 | 193.4 | 0.84 | 19.2 | 22.8 | x1.00 |
| Mamba-2 | layer | 1 | 5977.6 | 0.97 | 9.1 | 9.3 | x0.93 |
| Mamba-3 MIMO R=2 | layer | 1 | 6292.3 | 1.04 | 9.6 | 9.2 | x0.98 |
| Mamba-3 MIMO R=4 | layer | 1 | 6931.8 | 1.14 | 9.9 | 8.7 | x1.08 |
| Mamba-3 SISO | layer | 1 | 6426.5 | 0.99 | 8.7 | 8.8 | x1.00 |
| Mamba-2 | layer | 2 | 3344.1 | 0.97 | 16.2 | 16.7 | x1.03 |
| Mamba-3 MIMO R=2 | layer | 2 | 3500.1 | 1.04 | 17.2 | 16.5 | x1.08 |
| Mamba-3 MIMO R=4 | layer | 2 | 3888.6 | 1.14 | 17.7 | 15.5 | x1.20 |
| Mamba-3 SISO | layer | 2 | 3241.5 | 0.99 | 17.3 | 17.5 | x1.00 |

Plots: `bonus_time_per_step.png`, `bonus_roofline.png`. FLOP/byte uses analytical counts (kernels/src/bench_step.cpp: flops_core / bytes_core): SISO 7 and MIMO-R (1+6R) FLOP per state element, 8 bytes per element (fp32 state read + write).
