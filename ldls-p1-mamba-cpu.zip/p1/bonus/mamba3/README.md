# Bonus: one Mamba-3 decode step on CPU (SISO and MIMO)

**Run everything:** `bonus/mamba3/run_bonus.sh`. The result is `results/<machine>/ANSWER.md` and its plots.

| bonus step (brief) | where |
|---|---|
| 1. read the recurrence | `docs/THEORY.md` §5. Exponential-trapezoidal update with the previous step's B and x as extra state; data-dependent rotation of B and C |
| 2. official reference on CPU, decode step of one layer, SISO then MIMO | `ref/extract_official_refs.py` copies the authors' pure-PyTorch references verbatim (state-spaces/mamba `e9594ce`); `ref/layer_ref.py` rebuilds `Mamba3.step` from them |
| 3. SISO in C++ then SIMD, 1000 steps within tolerance | `kernels/src/ssm.h` (scalar / AVX2 / AVX-512 / NEON, one source); `kernels/src/test_step.cpp`; tolerance 1e-4 max relative error per step |
| 4. MIMO rank 4, same check | same kernel, R = 4 (templated, also R = 2, 8) |
| 5. time/step + arithmetic intensity: SISO, MIMO, Mamba-2 at the same state size | `kernels/src/bench_step.cpp`: state update with DRAM- or cache-resident state, and full layer step |
| 6. one-paragraph answer with numbers | `analyze.py` writes `ANSWER.md` |
| 2 (again): the official MODULE code itself on CPU | `gpu/official_step.py validate --emulate`: unmodified `Mamba3.step`, its kernel calls routed to the official references; vs our traces over 1,000 steps (SISO 6.4e-7, MIMO 6.5e-7) |
| extra: same question on our GPU | `gpu/setup_gpu.sh`, `gpu/run_gpu.sh`: official GPU kernels validated against the same traces, then SISO / MIMO / Mamba-2 timed at the same state size (batch 1/16/64, CUDA graphs). `analyze.py` adds the GPU paragraph to `ANSWER.md` |
| 7. stretch: ggml operator in a small ggml graph | `kernels/src/ggml_op_test.cpp`: mul_mat -> custom ops -> mul_mat, vs trace and direct step |

**Extra validation.** Our port of `Mamba3.step` matches the authors' independent recurrent SISO reference
(`tests/ops/triton/test_mamba3_siso.py`) to 4.4e-16 in float64. Note that this reference rounds input states to
float32 when they are passed in, so it must be called once for the whole sequence. Our Mamba-2 step matches ggml's `SSM_SCAN` to 4e-7.

**Checkpoints:** the `state-spaces/mamba3-mimo-894m` Hugging Face card asks users to authenticate "while this repository is private".
We therefore use seeded random weights, which the brief allows for speed and correctness tests (not perplexity).
