#!/usr/bin/env bash
# Whole pipeline on tiny random-weight models (config/smoke.yaml): proves every script runs, in minutes,
# without downloads. Output: results/smoke/, plots/smoke/. Usage: tools/smoke_test.sh [step...]
set -euo pipefail
cd "$(dirname "$0")/.."
export P1_CONFIG=config/smoke.yaml
BIN="${LLAMA_BIN_DIR:-${LLAMA_CPP_DIR:-../llama.cpp}/build/bin}"
steps="${*:-models hw stream predict correctness sweep profile scan experiment plots summary check}"
for s in $steps; do
  echo "================ smoke: $s"
  case $s in
    models)
      mkdir -p models data
      python3 - "$BIN" <<'PY'
import subprocess, sys, yaml, pathlib
b = sys.argv[1]; c = yaml.safe_load(open("config/smoke.yaml"))
for m in c["models"]:
    out = pathlib.Path(m["file"]); sy = m["synth"]
    f16 = pathlib.Path(f"models/synth-{sy['arch']}-{sy['preset']}-f16.gguf")
    if not f16.exists():
        subprocess.run([sys.executable, "tools/make_synthetic_gguf.py", "--arch", sy["arch"], "--preset", sy["preset"], "-o", str(f16)], check=True)
    if not out.exists():
        subprocess.run([f"{b}/llama-quantize", str(f16), str(out), m["quant"]], check=True, capture_output=True)
    print("ok", out)
PY
      [ -s data/smoke.txt ] || { cat README.md docs/*.md bonus/mamba3/README.md 2>/dev/null || true; } > data/smoke.txt
      [ "$(wc -c < data/smoke.txt)" -gt 20000 ] || python3 -c "print(' '.join(['the quick brown fox jumps over the lazy dog %d.'%i for i in range(4000)]))" >> data/smoke.txt
      (sha256sum models/synth-*.gguf data/smoke.txt || true) > /dev/null ;;
    hw)          python3 scripts/01_hwinfo.py > /dev/null ;;
    stream)      python3 scripts/02_stream.py --reps 3 --array-size 20000000 --bw-mib 256 ;;
    predict)     python3 scripts/05_predict.py | tail -5 ;;
    correctness) python3 scripts/04_correctness.py | tail -12 ;;
    sweep)       python3 scripts/06_sweep.py --force ;;
    profile)     python3 scripts/07_profile.py | grep -E "^## |Top-3" ;;
    scan)        scripts/07b_scan_bench.sh | grep -E "CHECK|decode .* 1 " ;;
    experiment)  python3 scripts/08_experiment.py | tail -10 ;;
    plots)       python3 scripts/10_plots.py ;;
    summary)     python3 scripts/11_summary.py ;;
    check)       python3 scripts/12_check.py | tail -45 || true ;;
  esac
done
