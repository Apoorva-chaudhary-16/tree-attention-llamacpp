#!/usr/bin/env python3
"""Write random-weight GGUF models with the exact tensor layout llama.cpp expects.

Why: lets every script in this repo be tested end to end without downloading anything (CI-style smoke
test), and lets 05_predict.py be checked against the real tensor sizes/types before the real models are
on disk. Random weights give the SAME speed and memory as trained weights (same shapes, same
quantization types after llama-quantize) but meaningless text and perplexity.

  python3 tools/make_synthetic_gguf.py --arch mamba2 --preset tiny -o models/synth-mamba2-tiny-f16.gguf
  python3 tools/make_synthetic_gguf.py --arch mamba2 --preset 1.3b -o /tmp/mamba2-1.3b-f16.gguf
  llama-quantize /tmp/mamba2-1.3b-f16.gguf /tmp/mamba2-1.3b-Q4_K_M.gguf Q4_K_M

Presets copy the published configs: state-spaces/mamba2-1.3b, mamba2-2.7b, mamba-1.4b, mamba-2.8b,
meta-llama/Llama-3.2-1B. Tensors are written one at a time (streaming), so 1.3B-param files need little RAM.
"""
import argparse
import math
import os
import sys
from pathlib import Path

import numpy as np

PRESETS = {
    # name: dict of hyper-parameters
    ("mamba2", "tiny"):  dict(d_model=256, n_layer=4, d_state=64, headdim=32, expand=2, ngroups=1, d_conv=4),
    ("mamba2", "1.3b"):  dict(d_model=2048, n_layer=48, d_state=128, headdim=64, expand=2, ngroups=1, d_conv=4),
    ("mamba2", "2.7b"):  dict(d_model=2560, n_layer=64, d_state=128, headdim=64, expand=2, ngroups=1, d_conv=4),
    ("mamba", "tiny"):   dict(d_model=256, n_layer=4, d_state=16, expand=2, d_conv=4),
    ("mamba", "1.4b"):   dict(d_model=2048, n_layer=48, d_state=16, expand=2, d_conv=4),
    ("mamba", "2.8b"):   dict(d_model=2560, n_layer=64, d_state=16, expand=2, d_conv=4),
    ("llama", "tiny"):   dict(d_model=256, n_layer=4, n_head=8, n_head_kv=2, n_ff=768),
    ("llama", "1b"):     dict(d_model=2048, n_layer=16, n_head=32, n_head_kv=8, n_ff=8192),
}
VOCAB_FILE = {"mamba": "ggml-vocab-gpt-neox.gguf", "mamba2": "ggml-vocab-gpt-neox.gguf",
              "llama": "ggml-vocab-llama-bpe.gguf"}


def llama_dir() -> Path:
    d = Path(os.environ.get("LLAMA_CPP_DIR", Path(__file__).resolve().parents[1] / ".." / "llama.cpp")).resolve()
    if not (d / "gguf-py").exists():
        sys.exit(f"llama.cpp not found at {d} (set LLAMA_CPP_DIR)")
    return d


REAL_VOCAB = {"mamba": 50280, "mamba2": 50288, "llama": 128256}  # rows in the real checkpoints


def copy_vocab(writer, vocab_path: Path, gguf, n_keep: int):
    """Copy tokenizer.* key/values from a llama.cpp vocab-only GGUF, truncated to n_keep tokens
    (exactly what convert_hf_to_gguf's _set_vocab_builtin does for the state-spaces checkpoints)."""
    r = gguf.GGUFReader(str(vocab_path))
    n_vocab = 0
    for key, field in r.fields.items():
        if not key.startswith("tokenizer."):
            continue
        val = field.contents()
        vt = field.types[0]
        if vt == gguf.GGUFValueType.ARRAY:
            val = list(val)
            if key in ("tokenizer.ggml.tokens", "tokenizer.ggml.token_type", "tokenizer.ggml.scores"):
                val = val[:n_keep]
            writer.add_array(key, val)
            if key == "tokenizer.ggml.tokens":
                n_vocab = len(val)
        elif vt == gguf.GGUFValueType.STRING:
            writer.add_string(key, val)
        elif vt == gguf.GGUFValueType.BOOL:
            writer.add_bool(key, bool(val))
        elif vt in (gguf.GGUFValueType.UINT32, gguf.GGUFValueType.INT32):
            writer.add_uint32(key, int(val))
        else:
            writer.add_key_value(key, val, vt)
    return n_vocab


def tensors_mamba2(h, n_vocab):
    d, L = h["d_model"], h["n_layer"]
    di = h["expand"] * d
    nh = di // h["headdim"]
    ns, ng, dc = h["d_state"], h["ngroups"], h["d_conv"]
    d_in_proj = 2 * di + 2 * ng * ns + nh
    conv_ch = di + 2 * ng * ns
    yield "token_embd.weight", (n_vocab, d), "w"
    yield "output_norm.weight", (d,), "one"
    for i in range(L):
        p = f"blk.{i}."
        yield p + "attn_norm.weight", (d,), "one"
        yield p + "ssm_in.weight", (d_in_proj, d), "w"
        yield p + "ssm_conv1d.weight", (conv_ch, dc), "conv"
        yield p + "ssm_conv1d.bias", (conv_ch,), "zero"
        yield p + "ssm_dt.bias", (nh,), "dtbias"
        yield p + "ssm_a", (nh, 1), "A2"
        yield p + "ssm_d", (nh, 1), "one"
        yield p + "ssm_norm.weight", (ng, di // ng), "one"
        yield p + "ssm_out.weight", (d, di), "w"


def tensors_mamba(h, n_vocab):
    d, L = h["d_model"], h["n_layer"]
    di = h["expand"] * d
    ns, dc = h["d_state"], h["d_conv"]
    dt_rank = math.ceil(d / 16)
    yield "token_embd.weight", (n_vocab, d), "w"
    yield "output_norm.weight", (d,), "one"
    for i in range(L):
        p = f"blk.{i}."
        yield p + "attn_norm.weight", (d,), "one"
        yield p + "ssm_in.weight", (2 * di, d), "w"
        yield p + "ssm_conv1d.weight", (di, dc), "conv"
        yield p + "ssm_conv1d.bias", (di,), "zero"
        yield p + "ssm_x.weight", (dt_rank + 2 * ns, di), "w"
        yield p + "ssm_dt.weight", (di, dt_rank), "w"
        yield p + "ssm_dt.bias", (di,), "dtbias"
        yield p + "ssm_a", (di, ns), "A1"
        yield p + "ssm_d", (di,), "one"
        yield p + "ssm_out.weight", (d, di), "w"


def tensors_llama(h, n_vocab):
    d, L = h["d_model"], h["n_layer"]
    hd = d // h["n_head"]
    kv = h["n_head_kv"] * hd
    yield "token_embd.weight", (n_vocab, d), "w"
    yield "output_norm.weight", (d,), "one"
    for i in range(L):
        p = f"blk.{i}."
        yield p + "attn_norm.weight", (d,), "one"
        yield p + "attn_q.weight", (d, d), "w"
        yield p + "attn_k.weight", (kv, d), "w"
        yield p + "attn_v.weight", (kv, d), "w"
        yield p + "attn_output.weight", (d, d), "w"
        yield p + "ffn_norm.weight", (d,), "one"
        yield p + "ffn_gate.weight", (h["n_ff"], d), "w"
        yield p + "ffn_up.weight", (h["n_ff"], d), "w"
        yield p + "ffn_down.weight", (d, h["n_ff"]), "w"


def make_data(kind, shape, rng):
    if kind == "w":
        fan_in = shape[-1]
        return (rng.standard_normal(shape, dtype=np.float32) / math.sqrt(fan_in)).astype(np.float16)
    if kind == "one":
        return np.ones(shape, dtype=np.float32)
    if kind == "zero":
        return np.zeros(shape, dtype=np.float32)
    if kind == "conv":
        return (rng.standard_normal(shape, dtype=np.float32) * 0.2).astype(np.float32)
    if kind == "dtbias":  # inverse softplus of dt ~ logU(1e-3, 1e-1), as in the official init
        dt = np.exp(rng.uniform(math.log(1e-3), math.log(1e-1), size=shape)).astype(np.float32)
        return (dt + np.log(-np.expm1(-dt))).astype(np.float32)
    if kind == "A2":      # A = -exp(A_log), A_log ~ log U(1, 16)
        return (-rng.uniform(1, 16, size=shape)).astype(np.float32)
    if kind == "A1":      # S4D-real init: A[c, s] = -(s + 1)
        return -np.tile(np.arange(1, shape[1] + 1, dtype=np.float32), (shape[0], 1))
    raise ValueError(kind)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arch", choices=["mamba", "mamba2", "llama"], required=True)
    ap.add_argument("--preset", default="tiny")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--ctx", type=int, default=1 << 20, help="context_length metadata (recurrent: any)")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    ld = llama_dir()
    sys.path.insert(0, str(ld / "gguf-py"))
    import gguf  # noqa: E402

    h = PRESETS[(args.arch, args.preset)]
    w = gguf.GGUFWriter(args.out, args.arch)
    w.add_name(f"synthetic-{args.arch}-{args.preset}")
    w.add_string("general.description", "RANDOM WEIGHTS - for pipeline tests only (speed/memory valid, text invalid)")
    n_vocab = copy_vocab(w, ld / "models" / VOCAB_FILE[args.arch], gguf, REAL_VOCAB[args.arch])
    d = h["d_model"]
    w.add_context_length(args.ctx if args.arch != "llama" else 131072)
    w.add_embedding_length(d)
    w.add_block_count(h["n_layer"])
    if args.arch == "llama":
        w.add_feed_forward_length(h["n_ff"])
        w.add_head_count(h["n_head"])
        w.add_head_count_kv(h["n_head_kv"])
        w.add_rope_dimension_count(d // h["n_head"])
        w.add_rope_freq_base(500000.0)
        w.add_layer_norm_rms_eps(1e-5)
        w.add_vocab_size(n_vocab)
        gen = tensors_llama(h, n_vocab)
    else:
        di = h["expand"] * d
        w.add_feed_forward_length(0)
        w.add_head_count(0)
        w.add_ssm_conv_kernel(h["d_conv"])
        w.add_ssm_inner_size(di)
        w.add_ssm_state_size(h["d_state"])
        w.add_layer_norm_rms_eps(1e-5)
        if args.arch == "mamba2":
            w.add_ssm_time_step_rank(di // h["headdim"])
            w.add_ssm_group_count(h["ngroups"])
            gen = tensors_mamba2(h, n_vocab)
        else:
            w.add_ssm_time_step_rank(math.ceil(d / 16))
            w.add_ssm_dt_b_c_rms(False)
            gen = tensors_mamba(h, n_vocab)
    w.add_file_type(gguf.LlamaFileType.MOSTLY_F16)

    specs = list(gen)
    rng = np.random.default_rng(args.seed)
    for name, shape, kind in specs:  # pass 1: tensor info only
        dt = np.float16 if kind == "w" else np.float32
        w.add_tensor_info(name, shape, np.dtype(dt), int(np.prod(shape)) * np.dtype(dt).itemsize)
    w.write_header_to_file()
    w.write_kv_data_to_file()
    w.write_ti_data_to_file()
    n_params = 0
    for name, shape, kind in specs:  # pass 2: stream the data
        arr = make_data(kind, shape, rng)
        w.write_tensor_data(arr)
        n_params += arr.size
    w.close()
    print(f"wrote {args.out}: arch={args.arch} preset={args.preset} params={n_params / 1e6:.1f}M "
          f"vocab={n_vocab} size={Path(args.out).stat().st_size / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
