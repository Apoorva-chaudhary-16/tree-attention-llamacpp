# Correctness checks (2026-11-03T14:10:36+00:00)

Text sample: `data/smoke.txt` sha256 `2ee3fff75191d091...`, ctx 128, 4 chunks (512 tokens), 1 threads.

## 1. Perplexity

| model | PPL | +/- |
|---|---:|---:|
| synthetic Mamba-2 tiny Q4_K_M | 83965.250 | 5611.757 |
| synthetic Mamba-2 tiny Q8_0 | 88343.774 | 5905.563 |
| synthetic Mamba-1 tiny Q4_K_M | 145677.004 | 7942.342 |

synth-m2: PPL(Q4_K_M) / PPL(Q8_0) - 1 = -4.96% (criterion <= 5%): **n/a (synthetic weights)**

All perplexities finite: PASS

## 2. Sample outputs (greedy, three different prompts) and 3. batch vs token-by-token

| model | prompt | output (start) | batch == token-by-token |
|---|---|---|---|
| synthetic Mamba-2 tiny Q4_K_M | `The three primary colors are` | ninetyokinetic liquor senStud rating Gaussian another belong | yes |
| synthetic Mamba-2 tiny Q4_K_M | `Explain in one sentence why the sky is blue:` | 800 summoned'] Kindle oxidationc contrastsmega Raven paperwo | yes |
| synthetic Mamba-2 tiny Q4_K_M | `def fibonacci(n):` | ade)/(( jurisdictional advocating insistenceTEXT acquittal i | yes |
| synthetic Mamba-1 tiny Q4_K_M | `The three primary colors are` | TyTyTyTyTyTyTyTyTyTyTyTyTyTyTyTy | yes |
| synthetic Mamba-1 tiny Q4_K_M | `Explain in one sentence why the sky is blue:` | : Byron insider insider insider insider insider insider insi | yes |
| synthetic Mamba-1 tiny Q4_K_M | `def fibonacci(n):` | SCinternalinternal GPIO tightevolutionevolution Convert Conv | yes |

Batch-vs-token-by-token consistency: **PASS** (a late divergence can come from a near-tie between two tokens: GEMM and GEMV kernels round differently)

