# Shared reference test on `smoke`

Llama-3.2-1B Q4_K_M, 512-token prompt (pp512) and 128-token decode (tg128), repetitions per point as listed (n). Headline row: llama-bench defaults.

| run | test | threads | flash-attn | tokens/s (mean ± sd) | n |
|---|---|---:|---|---:|---:|
| ref_defaults | pp512 | 2 | -1 | **5781.73 ± 355.17** | 3 |
| ref_defaults | tg128 | 2 | -1 | **266.61 ± 29.84** | 3 |
| ref_threads2_fa | pp512 | 2 | 1 | 6489.50 ± 823.25 | 3 |
| ref_threads2_fa | tg128 | 2 | 1 | 269.42 ± 2.24 | 3 |
