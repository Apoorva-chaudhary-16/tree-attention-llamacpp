# Requirements check: SMOKE TEST (synthetic models) (smoke, 2026-11-03T14:10:53+00:00)

| component | requirement (from the brief) | status | evidence |
|---|---|---|---|
| Setup & correctness (15%) | llama.cpp built CPU-only at the pinned commit | **MISSING** | run scripts/00_build_llamacpp.sh |
| Setup & correctness (15%) | hardware record: CPU, core types/count, caches, SIMD, RAM | **PASS** | hardware.json |
| Setup & correctness (15%) | RAM type/speed and theoretical peak bandwidth filled in | **WARN** | set theoretical_peak_bw_gbs in the config; RAM speed from Task Manager / dmidecode |
| Setup & correctness (15%) | memory bandwidth measured with STREAM (validated, >= 3 runs at 1 threads) | **PASS** | stream.csv |
| Setup & correctness (15%) | model files checksummed | **WARN** | checksums.sha256 |
| Setup & correctness (15%) | perplexity on a fixed text sample for every model | **PASS** | 3/3 models |
| Setup & correctness (15%) | sample outputs on >= 3 DIFFERENT prompts | **PASS** | 3 distinct prompts |
| Setup & correctness (15%) | batch-prefill == token-by-token check (recurrent state) | **PASS** | 6/6 identical |
| Benchmark sweeps (25%) | synthetic Mamba-2 tiny Q4_K_M: prefill at [512, 4096, 8192] x3 | **PASS** | raw/sweep.csv |
| Benchmark sweeps (25%) | synthetic Mamba-2 tiny Q4_K_M: decode at context [1024, 8192] x3 | **PASS** | raw/sweep.csv |
| Benchmark sweeps (25%) | synthetic Mamba-2 tiny Q8_0: prefill at [512, 4096, 8192] x3 | **PASS** | raw/sweep.csv |
| Benchmark sweeps (25%) | synthetic Mamba-2 tiny Q8_0: decode at context [1024, 8192] x3 | **PASS** | raw/sweep.csv |
| Benchmark sweeps (25%) | synthetic Mamba-1 tiny Q4_K_M: prefill at [512, 4096, 8192] x3 | **PASS** | raw/sweep.csv |
| Benchmark sweeps (25%) | synthetic Mamba-1 tiny Q4_K_M: decode at context [1024, 8192] x3 | **PASS** | raw/sweep.csv |
| Benchmark sweeps (25%) | synthetic Llama tiny Q4_K_M (contrast): decode at context [1024, 4096] x3 | **PASS** | raw/sweep.csv |
| Benchmark sweeps (25%) | peak RSS recorded for every run | **PASS** | 63 runs |
| Benchmark sweeps (25%) | every run within the 4.5 GB budget | **PASS** | 0 over budget |
| Benchmark sweeps (25%) | runs that swapped were flagged and rerun | **PASS** | 0 flagged |
| Benchmark sweeps (25%) | thread scaling 1..1 (pp and tg) for s-m2-q4km | **PASS** |  |
| Benchmark sweeps (25%) | thread scaling 1..1 (pp and tg) for s-m1-q4km | **PASS** |  |
| Benchmark sweeps (25%) | quantization rule: Q8_0 only for models <= 1.5B, no F16 | **PASS** | 1 Q8_0 models |
| Benchmark sweeps (25%) | laptop hygiene recorded (preflight before sweeps) | **PASS** | preflight/ |
| Profiling & roofline (25%) | per-operator breakdown, prefill and decode: s-m2-q4km | **PASS** | profile/summary.csv |
| Profiling & roofline (25%) | per-operator breakdown, prefill and decode: s-m1-q4km | **PASS** | profile/summary.csv |
| Profiling & roofline (25%) | top-3 operators per phase listed | **PASS** | profile/summary.md |
| Profiling & roofline (25%) | external profiler cross-check (perf / VTune / Instruments) | **WARN** | 07_profile.py --perf (Linux) or docs/PLATFORMS.md |
| Profiling & roofline (25%) | decode prediction (bandwidth / bytes per token) made BEFORE the sweep | **PASS** | predicted 2026-11-03T14:03:48 vs first run 2026-11-03T14:04:31 |
| Profiling & roofline (25%) | predicted vs measured decode compared | **PASS** | 8 points |
| Profiling & roofline (25%) | SSM_SCAN operator study (Mamba-1 vs Mamba-2, prefill and decode) | **PASS** | make scan |
| Own experiment (15%) | prediction written before the experiment runs | **PASS** | experiment_prediction.csv |
| Own experiment (15%) | every experiment point measured x3 | **PASS** | raw/experiment.csv |
| Report & talk (20%) | required plot: decode_vs_context | **PASS** | plots/smoke/decode_vs_context.png |
| Report & talk (20%) | required plot: prefill_vs_prompt | **PASS** | plots/smoke/prefill_vs_prompt.png |
| Report & talk (20%) | required plot: thread_scaling | **PASS** | plots/smoke/thread_scaling.png |
| Report & talk (20%) | required plot: op_breakdown | **PASS** | plots/smoke/op_breakdown.png |
| Report & talk (20%) | required plot: predicted_vs_measured | **PASS** | plots/smoke/predicted_vs_measured.png |
| Report & talk (20%) | SUMMARY.md with every number (and the slide-number list) | **PASS** | 11_summary.py |
| Report & talk (20%) | 4-page report (report/report.pdf) | **WARN** | not yet |
| Report & talk (20%) | 10-minute talk slides (report/slides.pdf or .pptx) | **WARN** | report/ |
| Report & talk (20%) | README lets another team rerun everything | **PASS** | README.md |
| Shared reference | PARAM Rudra reference run (Llama-3.2-1B Q4_K_M, pp512 + tg128) | **WARN** | scripts/09_rudra_reference.sbatch |
| Bonus (up to 50%) | correct SISO kernel (1000 steps vs official reference, scalar + SIMD) | **WARN** | test_step.log |
| Bonus (up to 50%) | correct MIMO kernel, rank 4 | **WARN** | test_step.log |
| Bonus (up to 50%) | MIMO question answered with measurements | **WARN** | ANSWER.md |
| Bonus (up to 50%) | stretch: kernel as a ggml operator in a ggml graph | **WARN** | ggml_op_test.log |

34 PASS, 10 WARN, 1 MISSING
