# Own experiment: prefill speed vs micro-batch size (2026-11-03T14:06:37+00:00)

smoke

| model | ubatch | predicted t/s | measured t/s (mean +/- sd, n) | measured / predicted |
|---|---:|---:|---:|---:|
| synthetic Mamba-2 tiny Q4_K_M | 1 | 839.2 | 3114.1 +/- 277.3 (3) | 3.71 |
| synthetic Mamba-2 tiny Q4_K_M | 8 | 3997.3 | 7065.6 +/- 1672.6 (3) | 1.77 |
| synthetic Mamba-2 tiny Q4_K_M | 64 | 7548.3 | 9387.6 +/- 2174.8 (3) | 1.24 |
| synthetic Mamba-2 tiny Q4_K_M | 512 | 8491.2 | 9239.7 +/- 1447.5 (3) | 1.09 |
| synthetic Mamba-1 tiny Q4_K_M | 1 | 765.8 | 1787.2 +/- 220.7 (3) | 2.33 |
| synthetic Mamba-1 tiny Q4_K_M | 8 | 2164.5 | 2510.6 +/- 82.2 (3) | 1.16 |
| synthetic Mamba-1 tiny Q4_K_M | 64 | 2804.9 | 3090.1 +/- 633.5 (3) | 1.10 |
| synthetic Mamba-1 tiny Q4_K_M | 512 | 2912.6 | 2815.5 +/- 456.3 (3) | 0.97 |
