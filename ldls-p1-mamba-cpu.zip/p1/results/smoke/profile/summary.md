# Per-operator time breakdown (opprof)

Share of operator wall time; decode profiles exclude the untimed depth prefill.

## synthetic Mamba-2 tiny Q4_K_M - prefill pp512  (1024 tokens, 0.10 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 37.0%; **SSM_SCAN** 29.8%; **SSM_CONV** 14.3%

| category | share | ms / token |
|---|---:|---:|
| SSM projections (in/out/x/dt) | 32.9% | 0.033 |
| SSM scan | 29.8% | 0.030 |
| SSM conv (+concat) | 18.0% | 0.018 |
| elementwise / misc | 8.0% | 0.008 |
| output head (lm_head) | 4.1% | 0.004 |
| norms | 3.8% | 0.004 |
| activations / gating | 2.2% | 0.002 |
| embedding lookup | 1.1% | 0.001 |
| state / KV-cache copies | 0.2% | 0.000 |

MUL_MAT time by src0 type: q4_K 32.9%, q6_K 4.1%

## synthetic Mamba-2 tiny Q4_K_M - decode ctx 1024  (32 tokens, 1.46 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 88.1%; **SSM_SCAN** 2.9%; **CPY** 2.4%

| category | share | ms / token |
|---|---:|---:|
| output head (lm_head) | 81.2% | 1.188 |
| SSM projections (in/out/x/dt) | 7.0% | 0.102 |
| SSM conv (+concat) | 3.5% | 0.051 |
| SSM scan | 2.9% | 0.043 |
| state / KV-cache copies | 2.4% | 0.035 |
| elementwise / misc | 1.9% | 0.028 |
| norms | 0.6% | 0.008 |
| activations / gating | 0.5% | 0.007 |
| embedding lookup | 0.1% | 0.002 |

MUL_MAT time by src0 type: q6_K 81.2%, q4_K 7.0%

## synthetic Mamba-2 tiny Q4_K_M - decode ctx 8192  (32 tokens, 1.33 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 88.9%; **SSM_SCAN** 2.9%; **CPY** 2.2%

| category | share | ms / token |
|---|---:|---:|
| output head (lm_head) | 82.1% | 1.090 |
| SSM projections (in/out/x/dt) | 6.8% | 0.091 |
| SSM scan | 2.9% | 0.039 |
| SSM conv (+concat) | 2.8% | 0.037 |
| state / KV-cache copies | 2.2% | 0.029 |
| elementwise / misc | 1.9% | 0.025 |
| norms | 0.6% | 0.008 |
| activations / gating | 0.6% | 0.007 |
| embedding lookup | 0.1% | 0.001 |

MUL_MAT time by src0 type: q6_K 82.1%, q4_K 6.8%

## synthetic Mamba-1 tiny Q4_K_M - prefill pp512  (1024 tokens, 0.34 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **SSM_SCAN** 77.7%; **MUL_MAT** 11.9%; **SSM_CONV** 4.4%

| category | share | ms / token |
|---|---:|---:|
| SSM scan | 77.7% | 0.261 |
| SSM projections (in/out/x/dt) | 10.7% | 0.036 |
| SSM conv (+concat) | 6.8% | 0.023 |
| elementwise / misc | 1.9% | 0.006 |
| output head (lm_head) | 1.2% | 0.004 |
| activations / gating | 0.7% | 0.002 |
| norms | 0.5% | 0.002 |
| embedding lookup | 0.4% | 0.001 |
| state / KV-cache copies | 0.1% | 0.000 |

MUL_MAT time by src0 type: q4_K 8.6%, f16 2.2%, q6_K 1.2%

## synthetic Mamba-1 tiny Q4_K_M - decode ctx 1024  (32 tokens, 1.69 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 82.7%; **SSM_SCAN** 12.1%; **CPY** 1.2%

| category | share | ms / token |
|---|---:|---:|
| output head (lm_head) | 77.1% | 1.307 |
| SSM scan | 12.1% | 0.206 |
| SSM projections (in/out/x/dt) | 5.6% | 0.095 |
| SSM conv (+concat) | 1.8% | 0.030 |
| elementwise / misc | 1.3% | 0.023 |
| state / KV-cache copies | 1.2% | 0.020 |
| activations / gating | 0.4% | 0.007 |
| norms | 0.3% | 0.005 |
| embedding lookup | 0.1% | 0.001 |

MUL_MAT time by src0 type: q6_K 77.1%, q4_K 4.8%, f16 0.8%

## synthetic Mamba-1 tiny Q4_K_M - decode ctx 8192  (32 tokens, 1.12 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 78.5%; **SSM_SCAN** 15.5%; **CONCAT** 1.7%

| category | share | ms / token |
|---|---:|---:|
| output head (lm_head) | 72.1% | 0.805 |
| SSM scan | 15.5% | 0.173 |
| SSM projections (in/out/x/dt) | 6.4% | 0.072 |
| SSM conv (+concat) | 2.4% | 0.026 |
| elementwise / misc | 1.5% | 0.017 |
| state / KV-cache copies | 1.2% | 0.014 |
| activations / gating | 0.5% | 0.006 |
| norms | 0.3% | 0.003 |
| embedding lookup | 0.1% | 0.001 |

MUL_MAT time by src0 type: q6_K 72.1%, q4_K 5.4%, f16 1.0%


## Instrument check: profiled run vs normal sweep runs (same point)

| model | point | t/s profiled | t/s sweep (median) | overhead |
|---|---|---:|---:|---:|
| s-m2-q4km | pp512 | 9718.06 | 10300.56 | +5.7% |
| s-m2-q4km | ctx 1024 | 574.50 | 641.77 | +10.5% |
| s-m2-q4km | ctx 8192 | 595.10 | 681.22 | +12.6% |
| s-m1-q4km | pp512 | 3482.67 | 2859.79 | -21.8% |
| s-m1-q4km | ctx 1024 | 495.01 | 644.00 | +23.1% |
| s-m1-q4km | ctx 8192 | 750.59 | 523.39 | -43.4% |
