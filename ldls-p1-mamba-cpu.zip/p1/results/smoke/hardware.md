| item | value |
|---|---|
| Machine | smoke |
| CPU | Intel(R) Xeon(R) Processor @ 2.10GHz |
| Architecture | x86_64 |
| OS | Linux-6.18.44-fc-v230-x86_64-with-glibc2.39 |
| Cores | 1 physical / 1 logical; P-cores 1, E-cores 0 (hybrid: no) |
| Max clock | n/a (not exposed) |
| L1d / L1i | 48 KiB / 32 KiB |
| L2 | 2.0 MiB |
| L3 | 260.0 MiB |
| SIMD | sse4_2, avx, avx2, fma, f16c, avx_vnni, avx512f, avx512bw, avx512vl, avx512_vnni, avx512_bf16, avx512_fp16, amx_tile, amx_int8 |
| RAM | 4.19 GB, FILL IN |
| Swap | 0.0 |
| Theoretical peak BW | None |
| Power | on AC: None; profile: n/a; governor: n/a |
