# Bytes per decoded token (predicted 2026-11-03T14:03:48+00:00, repo commit unknown)

Bandwidth at 1 threads, mean of 3 STREAM runs: Triad **12.8 GB/s**, Copy 12.7 GB/s, read-only 11.0 GB/s.


## synthetic Mamba-2 tiny Q4_K_M  (`synth-mamba2-tiny-Q4_K_M.gguf`, arch `mamba2`, 4 layers, tied embeddings: True)

| tensor group | types | params (M) | MB read per token | share of weights |
|---|---|---:|---:|---:|
| token_embd | Q6_K | 12.9 | 10.6 | 91.1% |
| ssm_in | Q4_K | 1.2 | 0.7 | 5.8% |
| ssm_out | Q4_K | 0.5 | 0.3 | 2.5% |
| ssm_conv1d | F32 | 0.0 | 0.0 | 0.4% |
| norms | F32 | 0.0 | 0.0 | 0.1% |
| **all weights** | | | **11.6** | |

Recurrent state per sequence: **0.5 MiB** (ssm 128 KiB + conv 8 KiB per layer), constant in context. Traffic per token: ideal 1.1 MB, llama.cpp graph ~2.2 MB. Scan work per token: 1 MFLOP and 0k exp() calls.

| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |
|---:|---:|---:|---:|---:|---:|
| 1,024 | 1.1 | 12.7 | 1010.6 | 929.4 | 867.9 |
| 8,192 | 1.1 | 12.7 | 1010.6 | 929.4 | 867.9 |

## synthetic Mamba-2 tiny Q8_0  (`synth-mamba2-tiny-Q8_0.gguf`, arch `mamba2`, 4 layers, tied embeddings: True)

| tensor group | types | params (M) | MB read per token | share of weights |
|---|---|---:|---:|---:|
| token_embd | Q8_0 | 12.9 | 13.7 | 87.8% |
| ssm_in | Q8_0 | 1.2 | 1.3 | 8.2% |
| ssm_out | Q8_0 | 0.5 | 0.6 | 3.6% |
| ssm_conv1d | F32 | 0.0 | 0.0 | 0.3% |
| **all weights** | | | **15.6** | |

Recurrent state per sequence: **0.5 MiB** (ssm 128 KiB + conv 8 KiB per layer), constant in context. Traffic per token: ideal 1.1 MB, llama.cpp graph ~2.2 MB. Scan work per token: 1 MFLOP and 0k exp() calls.

| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |
|---:|---:|---:|---:|---:|---:|
| 1,024 | 1.1 | 16.7 | 769.6 | 721.6 | 660.9 |
| 8,192 | 1.1 | 16.7 | 769.6 | 721.6 | 660.9 |

## synthetic Mamba-1 tiny Q4_K_M  (`synth-mamba-tiny-Q4_K_M.gguf`, arch `mamba`, 4 layers, tied embeddings: True)

| tensor group | types | params (M) | MB read per token | share of weights |
|---|---|---:|---:|---:|
| token_embd | Q6_K | 12.9 | 10.6 | 89.8% |
| ssm_in | Q4_K | 1.0 | 0.6 | 5.0% |
| ssm_out | Q4_K | 0.5 | 0.3 | 2.5% |
| ssm_a | F32 | 0.0 | 0.1 | 1.1% |
| ssm_dt | F16 | 0.0 | 0.1 | 0.6% |
| ssm_x | Q4_K | 0.1 | 0.1 | 0.5% |
| ssm_conv1d | F32 | 0.0 | 0.0 | 0.3% |
| **all weights** | | | **11.8** | |

Recurrent state per sequence: **0.1 MiB** (ssm 32 KiB + conv 6 KiB per layer), constant in context. Traffic per token: ideal 0.3 MB, llama.cpp graph ~0.6 MB. Scan work per token: 0 MFLOP and 33k exp() calls.

| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |
|---:|---:|---:|---:|---:|---:|
| 1,024 | 0.3 | 12.1 | 1063.7 | 1036.9 | 913.5 |
| 8,192 | 0.3 | 12.1 | 1063.7 | 1036.9 | 913.5 |

## synthetic Llama tiny Q4_K_M (contrast)  (`synth-llama-tiny-Q4_K_M.gguf`, arch `llama`, 4 layers, tied embeddings: True)

| tensor group | types | params (M) | MB read per token | share of weights |
|---|---|---:|---:|---:|
| token_embd | Q6_K | 32.8 | 26.9 | 93.7% |
| ffn_down | Q4_K,Q6_K | 0.8 | 0.5 | 1.9% |
| ffn_gate | Q4_K | 0.8 | 0.4 | 1.5% |
| ffn_up | Q4_K | 0.8 | 0.4 | 1.5% |
| attn_output | Q4_K | 0.3 | 0.1 | 0.5% |
| attn_q | Q4_K | 0.3 | 0.1 | 0.5% |
| attn_v | Q4_K,Q6_K | 0.1 | 0.0 | 0.2% |
| attn_k | Q4_K | 0.1 | 0.0 | 0.1% |
| **all weights** | | | **28.7** | |

KV cache (f16): 1 KiB per context token; equals the weight bytes at 28,075 tokens.

| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |
|---:|---:|---:|---:|---:|---:|
| 1,024 | 1.0 | 29.8 | 431.1 | 431.1 | 370.2 |
| 4,096 | 4.2 | 32.9 | 389.9 | 389.9 | 334.8 |
