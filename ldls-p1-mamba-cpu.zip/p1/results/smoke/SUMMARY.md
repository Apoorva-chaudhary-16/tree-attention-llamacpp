# Results summary: SMOKE TEST (synthetic models) (smoke)

Generated 2026-11-03T14:10:53+00:00 from the raw CSVs in `results/smoke/`. Threads = 1 performance cores unless stated. Every value: mean ± standard deviation over 3 fresh-process runs.

> **SMOKE TEST on random-weight synthetic models: these numbers are not results.**

## 1. Hardware and setup

| item | value |
|---|---|
| Machine | smoke |
| CPU | Intel(R) Xeon(R) Processor @ 2.10GHz |
| Architecture | x86_64 |
| OS | Linux-6.18.44-fc-v230-x86_64-with-glibc2.39 |
| Cores | 1 physical / 1 logical; P-cores 1, E-cores 0 (hybrid: no) |
| Max clock | n/a (not exposed) |
| L1d / L1i | 48 KiB / 32 KiB |
| L2 | 2.0 MiB |
| L3 | 260.0 MiB |
| SIMD | sse4_2, avx, avx2, fma, f16c, avx_vnni, avx512f, avx512bw, avx512vl, avx512_vnni, avx512_bf16, avx512_fp16, amx_tile, amx_int8 |
| RAM | 4.19 GB, FILL IN |
| Swap | 0.0 |
| Theoretical peak BW | None |
| Power | on AC: None; profile: n/a; governor: n/a |

**Memory bandwidth (STREAM; read-only kernel for comparison), GB/s**

| threads | Triad | Copy | read-only |
|---:|---:|---:|---:|
| 1 | 12.8 ± 0.1 | 12.7 | 11.0 |

## 2. Correctness


Text sample: `data/smoke.txt` sha256 `2ee3fff75191d091...`, ctx 128, 4 chunks (512 tokens), 1 threads.

## 1. Perplexity

| model | PPL | +/- |
|---|---:|---:|
| synthetic Mamba-2 tiny Q4_K_M | 83965.250 | 5611.757 |
| synthetic Mamba-2 tiny Q8_0 | 88343.774 | 5905.563 |
| synthetic Mamba-1 tiny Q4_K_M | 145677.004 | 7942.342 |

synth-m2: PPL(Q4_K_M) / PPL(Q8_0) - 1 = -4.96% (criterion <= 5%): **n/a (synthetic weights)**

All perplexities finite: PASS

## 2. Sample outputs (greedy, three different prompts) and 3. batch vs token-by-token

| model | prompt | output (start) | batch == token-by-token |
|---|---|---|---|
| synthetic Mamba-2 tiny Q4_K_M | `The three primary colors are` | ninetyokinetic liquor senStud rating Gaussian another belong | yes |
| synthetic Mamba-2 tiny Q4_K_M | `Explain in one sentence why the sky is blue:` | 800 summoned'] Kindle oxidationc contrastsmega Raven paperwo | yes |
| synthetic Mamba-2 tiny Q4_K_M | `def fibonacci(n):` | ade)/(( jurisdictional advocating insistenceTEXT acquittal i | yes |
| synthetic Mamba-1 tiny Q4_K_M | `The three primary colors are` | TyTyTyTyTyTyTyTyTyTyTyTyTyTyTyTy | yes |
| synthetic Mamba-1 tiny Q4_K_M | `Explain in one sentence why the sky is blue:` | : Byron insider insider insider insider insider insider insi | yes |
| synthetic Mamba-1 tiny Q4_K_M | `def fibonacci(n):` | SCinternalinternal GPIO tightevolutionevolution Convert Conv | yes |

Batch-vs-token-by-token consistency: **PASS** (a late divergence can come from a near-tie between two tokens: GEMM and GEMV kernels round differently)


## 3. Prefill speed (tokens/s) and peak RSS (GB)

| model | prompt | tokens/s | peak RSS |
|---|---:|---:|---:|
| synthetic Mamba-1 tiny Q4_K_M | 512 | 3258.89 ± 751.47 (n=3) | 0.07 |
| synthetic Mamba-1 tiny Q4_K_M | 4,096 | 3205.79 ± 464.86 (n=3) | 0.07 |
| synthetic Mamba-1 tiny Q4_K_M | 8,192 | 3249.64 ± 582.68 (n=3) | 0.07 |
| synthetic Mamba-2 tiny Q4_K_M | 512 | 9587.83 ± 2031.79 (n=3) | 0.07 |
| synthetic Mamba-2 tiny Q4_K_M | 4,096 | 8590.63 ± 826.24 (n=3) | 0.07 |
| synthetic Mamba-2 tiny Q4_K_M | 8,192 | 10525.05 ± 1193.07 (n=3) | 0.07 |
| synthetic Mamba-2 tiny Q8_0 | 512 | 9167.22 ± 637.52 (n=3) | 0.07 |
| synthetic Mamba-2 tiny Q8_0 | 4,096 | 7012.39 ± 992.46 (n=3) | 0.07 |
| synthetic Mamba-2 tiny Q8_0 | 8,192 | 8711.98 ± 836.91 (n=3) | 0.07 |

## 4. Decode speed (tokens/s), prediction and achieved bandwidth

| model | context | tokens/s | peak RSS | predicted (Triad) | measured / predicted | achieved GB/s |
|---|---:|---:|---:|---:|---:|---:|
| synthetic Llama tiny Q4_K_M (contrast) | 1,024 | 88.72 ± 10.40 (n=3) | 0.16 | 431.1 | 21% | 2.6 |
| synthetic Llama tiny Q4_K_M (contrast) | 4,096 | 37.50 ± 1.20 (n=3) | 0.16 | 389.9 | 10% | 1.2 |
| synthetic Mamba-1 tiny Q4_K_M | 1,024 | 657.42 ± 60.27 (n=3) | 0.07 | 1063.7 | 62% | 7.9 |
| synthetic Mamba-1 tiny Q4_K_M | 8,192 | 578.43 ± 114.92 (n=3) | 0.07 | 1063.7 | 54% | 7.0 |
| synthetic Mamba-2 tiny Q4_K_M | 1,024 | 613.52 ± 73.08 (n=3) | 0.07 | 1010.6 | 61% | 7.8 |
| synthetic Mamba-2 tiny Q4_K_M | 8,192 | 688.19 ± 81.94 (n=3) | 0.07 | 1010.6 | 68% | 8.7 |
| synthetic Mamba-2 tiny Q8_0 | 1,024 | 582.88 ± 100.23 (n=3) | 0.07 | 769.6 | 76% | 9.7 |
| synthetic Mamba-2 tiny Q8_0 | 8,192 | 629.77 ± 19.36 (n=3) | 0.07 | 769.6 | 82% | 10.5 |

## 5. Thread scaling (tokens/s)

| model | test | t=1 |
|---|---|---:|
| synthetic Mamba-1 tiny Q4_K_M | tg | 582.4 |
| synthetic Mamba-1 tiny Q4_K_M | pp512 | 3089.4 |
| synthetic Mamba-2 tiny Q4_K_M | tg | 776.2 |
| synthetic Mamba-2 tiny Q4_K_M | pp512 | 10410.2 |

Runs flagged and rerun or excluded (swap / memory pressure / budget / errors): **0**

## 6. Per-operator breakdown (top-3 per phase)


Share of operator wall time; decode profiles exclude the untimed depth prefill.

## synthetic Mamba-2 tiny Q4_K_M - prefill pp512  (1024 tokens, 0.10 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 37.0%; **SSM_SCAN** 29.8%; **SSM_CONV** 14.3%

| category | share | ms / token |
|---|---:|---:|
| SSM projections (in/out/x/dt) | 32.9% | 0.033 |
| SSM scan | 29.8% | 0.030 |
| SSM conv (+concat) | 18.0% | 0.018 |
| elementwise / misc | 8.0% | 0.008 |
| output head (lm_head) | 4.1% | 0.004 |
| norms | 3.8% | 0.004 |
| activations / gating | 2.2% | 0.002 |
| embedding lookup | 1.1% | 0.001 |
| state / KV-cache copies | 0.2% | 0.000 |

MUL_MAT time by src0 type: q4_K 32.9%, q6_K 4.1%

## synthetic Mamba-2 tiny Q4_K_M - decode ctx 1024  (32 tokens, 1.46 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 88.1%; **SSM_SCAN** 2.9%; **CPY** 2.4%

| category | share | ms / token |
|---|---:|---:|
| output head (lm_head) | 81.2% | 1.188 |
| SSM projections (in/out/x/dt) | 7.0% | 0.102 |
| SSM conv (+concat) | 3.5% | 0.051 |
| SSM scan | 2.9% | 0.043 |
| state / KV-cache copies | 2.4% | 0.035 |
| elementwise / misc | 1.9% | 0.028 |
| norms | 0.6% | 0.008 |
| activations / gating | 0.5% | 0.007 |
| embedding lookup | 0.1% | 0.002 |

MUL_MAT time by src0 type: q6_K 81.2%, q4_K 7.0%

## synthetic Mamba-2 tiny Q4_K_M - decode ctx 8192  (32 tokens, 1.33 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 88.9%; **SSM_SCAN** 2.9%; **CPY** 2.2%

| category | share | ms / token |
|---|---:|---:|
| output head (lm_head) | 82.1% | 1.090 |
| SSM projections (in/out/x/dt) | 6.8% | 0.091 |
| SSM scan | 2.9% | 0.039 |
| SSM conv (+concat) | 2.8% | 0.037 |
| state / KV-cache copies | 2.2% | 0.029 |
| elementwise / misc | 1.9% | 0.025 |
| norms | 0.6% | 0.008 |
| activations / gating | 0.6% | 0.007 |
| embedding lookup | 0.1% | 0.001 |

MUL_MAT time by src0 type: q6_K 82.1%, q4_K 6.8%

## synthetic Mamba-1 tiny Q4_K_M - prefill pp512  (1024 tokens, 0.34 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **SSM_SCAN** 77.7%; **MUL_MAT** 11.9%; **SSM_CONV** 4.4%

| category | share | ms / token |
|---|---:|---:|
| SSM scan | 77.7% | 0.261 |
| SSM projections (in/out/x/dt) | 10.7% | 0.036 |
| SSM conv (+concat) | 6.8% | 0.023 |
| elementwise / misc | 1.9% | 0.006 |
| output head (lm_head) | 1.2% | 0.004 |
| activations / gating | 0.7% | 0.002 |
| norms | 0.5% | 0.002 |
| embedding lookup | 0.4% | 0.001 |
| state / KV-cache copies | 0.1% | 0.000 |

MUL_MAT time by src0 type: q4_K 8.6%, f16 2.2%, q6_K 1.2%

## synthetic Mamba-1 tiny Q4_K_M - decode ctx 1024  (32 tokens, 1.69 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 82.7%; **SSM_SCAN** 12.1%; **CPY** 1.2%

| category | share | ms / token |
|---|---:|---:|
| output head (lm_head) | 77.1% | 1.307 |
| SSM scan | 12.1% | 0.206 |
| SSM projections (in/out/x/dt) | 5.6% | 0.095 |
| SSM conv (+concat) | 1.8% | 0.030 |
| elementwise / misc | 1.3% | 0.023 |
| state / KV-cache copies | 1.2% | 0.020 |
| activations / gating | 0.4% | 0.007 |
| norms | 0.3% | 0.005 |
| embedding lookup | 0.1% | 0.001 |

MUL_MAT time by src0 type: q6_K 77.1%, q4_K 4.8%, f16 0.8%

## synthetic Mamba-1 tiny Q4_K_M - decode ctx 8192  (32 tokens, 1.12 ms/token in ops; ops cover 100.0% of graph time)

Top-3 operators: **MUL_MAT** 78.5%; **SSM_SCAN** 15.5%; **CONCAT** 1.7%

| category | share | ms / token |
|---|---:|---:|
| output head (lm_head) | 72.1% | 0.805 |
| SSM scan | 15.5% | 0.173 |
| SSM projections (in/out/x/dt) | 6.4% | 0.072 |
| SSM conv (+concat) | 2.4% | 0.026 |
| elementwise / misc | 1.5% | 0.017 |
| state / KV-cache copies | 1.2% | 0.014 |
| activations / gating | 0.5% | 0.006 |
| norms | 0.3% | 0.003 |
| embedding lookup | 0.1% | 0.001 |

MUL_MAT time by src0 type: q6_K 72.1%, q4_K 5.4%, f16 1.0%


## Instrument check: profiled run vs normal sweep runs (same point)

| model | point | t/s profiled | t/s sweep (median) | overhead |
|---|---|---:|---:|---:|
| s-m2-q4km | pp512 | 9718.06 | 10300.56 | +5.7% |
| s-m2-q4km | ctx 1024 | 574.50 | 641.77 | +10.5% |
| s-m2-q4km | ctx 8192 | 595.10 | 681.22 | +12.6% |
| s-m1-q4km | pp512 | 3482.67 | 2859.79 | -21.8% |
| s-m1-q4km | ctx 1024 | 495.01 | 644.00 | +23.1% |
| s-m1-q4km | ctx 8192 | 750.59 | 523.39 | -43.4% |

## 7. Bytes per token (prediction, written before the sweep)


Bandwidth at 1 threads, mean of 3 STREAM runs: Triad **12.8 GB/s**, Copy 12.7 GB/s, read-only 11.0 GB/s.


## synthetic Mamba-2 tiny Q4_K_M  (`synth-mamba2-tiny-Q4_K_M.gguf`, arch `mamba2`, 4 layers, tied embeddings: True)

| tensor group | types | params (M) | MB read per token | share of weights |
|---|---|---:|---:|---:|
| token_embd | Q6_K | 12.9 | 10.6 | 91.1% |
| ssm_in | Q4_K | 1.2 | 0.7 | 5.8% |
| ssm_out | Q4_K | 0.5 | 0.3 | 2.5% |
| ssm_conv1d | F32 | 0.0 | 0.0 | 0.4% |
| norms | F32 | 0.0 | 0.0 | 0.1% |
| **all weights** | | | **11.6** | |

Recurrent state per sequence: **0.5 MiB** (ssm 128 KiB + conv 8 KiB per layer), constant in context. Traffic per token: ideal 1.1 MB, llama.cpp graph ~2.2 MB. Scan work per token: 1 MFLOP and 0k exp() calls.

| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |
|---:|---:|---:|---:|---:|---:|
| 1,024 | 1.1 | 12.7 | 1010.6 | 929.4 | 867.9 |
| 8,192 | 1.1 | 12.7 | 1010.6 | 929.4 | 867.9 |

## synthetic Mamba-2 tiny Q8_0  (`synth-mamba2-tiny-Q8_0.gguf`, arch `mamba2`, 4 layers, tied embeddings: True)

| tensor group | types | params (M) | MB read per token | share of weights |
|---|---|---:|---:|---:|
| token_embd | Q8_0 | 12.9 | 13.7 | 87.8% |
| ssm_in | Q8_0 | 1.2 | 1.3 | 8.2% |
| ssm_out | Q8_0 | 0.5 | 0.6 | 3.6% |
| ssm_conv1d | F32 | 0.0 | 0.0 | 0.3% |
| **all weights** | | | **15.6** | |

Recurrent state per sequence: **0.5 MiB** (ssm 128 KiB + conv 8 KiB per layer), constant in context. Traffic per token: ideal 1.1 MB, llama.cpp graph ~2.2 MB. Scan work per token: 1 MFLOP and 0k exp() calls.

| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |
|---:|---:|---:|---:|---:|---:|
| 1,024 | 1.1 | 16.7 | 769.6 | 721.6 | 660.9 |
| 8,192 | 1.1 | 16.7 | 769.6 | 721.6 | 660.9 |

## synthetic Mamba-1 tiny Q4_K_M  (`synth-mamba-tiny-Q4_K_M.gguf`, arch `mamba`, 4 layers, tied embeddings: True)

| tensor group | types | params (M) | MB read per token | share of weights |
|---|---|---:|---:|---:|
| token_embd | Q6_K | 12.9 | 10.6 | 89.8% |
| ssm_in | Q4_K | 1.0 | 0.6 | 5.0% |
| ssm_out | Q4_K | 0.5 | 0.3 | 2.5% |
| ssm_a | F32 | 0.0 | 0.1 | 1.1% |
| ssm_dt | F16 | 0.0 | 0.1 | 0.6% |
| ssm_x | Q4_K | 0.1 | 0.1 | 0.5% |
| ssm_conv1d | F32 | 0.0 | 0.0 | 0.3% |
| **all weights** | | | **11.8** | |

Recurrent state per sequence: **0.1 MiB** (ssm 32 KiB + conv 6 KiB per layer), constant in context. Traffic per token: ideal 0.3 MB, llama.cpp graph ~0.6 MB. Scan work per token: 0 MFLOP and 33k exp() calls.

| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |
|---:|---:|---:|---:|---:|---:|
| 1,024 | 0.3 | 12.1 | 1063.7 | 1036.9 | 913.5 |
| 8,192 | 0.3 | 12.1 | 1063.7 | 1036.9 | 913.5 |

## synthetic Llama tiny Q4_K_M (contrast)  (`synth-llama-tiny-Q4_K_M.gguf`, arch `llama`, 4 layers, tied embeddings: True)

| tensor group | types | params (M) | MB read per token | share of weights |
|---|---|---:|---:|---:|
| token_embd | Q6_K | 32.8 | 26.9 | 93.7% |
| ffn_down | Q4_K,Q6_K | 0.8 | 0.5 | 1.9% |
| ffn_gate | Q4_K | 0.8 | 0.4 | 1.5% |
| ffn_up | Q4_K | 0.8 | 0.4 | 1.5% |
| attn_output | Q4_K | 0.3 | 0.1 | 0.5% |
| attn_q | Q4_K | 0.3 | 0.1 | 0.5% |
| attn_v | Q4_K,Q6_K | 0.1 | 0.0 | 0.2% |
| attn_k | Q4_K | 0.1 | 0.0 | 0.1% |
| **all weights** | | | **28.7** | |

KV cache (f16): 1 KiB per context token; equals the weight bytes at 28,075 tokens.

| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |
|---:|---:|---:|---:|---:|---:|
| 1,024 | 1.0 | 29.8 | 431.1 | 431.1 | 370.2 |
| 4,096 | 4.2 | 32.9 | 389.9 | 389.9 | 334.8 |

## 9. Own experiment


smoke

| model | ubatch | predicted t/s | measured t/s (mean +/- sd, n) | measured / predicted |
|---|---:|---:|---:|---:|
| synthetic Mamba-2 tiny Q4_K_M | 1 | 839.2 | 3114.1 +/- 277.3 (3) | 3.71 |
| synthetic Mamba-2 tiny Q4_K_M | 8 | 3997.3 | 7065.6 +/- 1672.6 (3) | 1.77 |
| synthetic Mamba-2 tiny Q4_K_M | 64 | 7548.3 | 9387.6 +/- 2174.8 (3) | 1.24 |
| synthetic Mamba-2 tiny Q4_K_M | 512 | 8491.2 | 9239.7 +/- 1447.5 (3) | 1.09 |
| synthetic Mamba-1 tiny Q4_K_M | 1 | 765.8 | 1787.2 +/- 220.7 (3) | 2.33 |
| synthetic Mamba-1 tiny Q4_K_M | 8 | 2164.5 | 2510.6 +/- 82.2 (3) | 1.16 |
| synthetic Mamba-1 tiny Q4_K_M | 64 | 2804.9 | 3090.1 +/- 633.5 (3) | 1.10 |
| synthetic Mamba-1 tiny Q4_K_M | 512 | 2912.6 | 2815.5 +/- 456.3 (3) | 0.97 |

## 8. SSM_SCAN operator alone (kernels/ssm_scan_bench), µs per token per layer

| shape | phase | threads | µs |
|---|---|---:|---:|
| mamba1-1.4b | decode | 1 | 412.3 ± 12.3 |
| mamba1-1.4b | prefill | 1 | 392.6 ± 74.6 |
| mamba1-2.8b | decode | 1 | 711.2 ± 103.6 |
| mamba1-2.8b | prefill | 1 | 644.4 ± 76.2 |
| mamba2-1.3b | decode | 1 | 465.7 ± 16.9 |
| mamba2-1.3b | prefill | 1 | 94.8 ± 2.3 |
| mamba2-2.7b | decode | 1 | 574.4 ± 23.9 |
| mamba2-2.7b | prefill | 1 | 129.4 ± 4.2 |

## 10. Bonus: Mamba-3 decode step

_run bonus/mamba3/run_bonus.sh_

## 11. Shared reference run (PARAM Rudra)

_not run yet: scripts/09_rudra_reference.sbatch_

## Numbers for the slides

- STREAM Triad at 1 threads: 12.8 GB/s (read-only 11.0 GB/s)
- PPL synthetic Mamba-2 tiny Q4_K_M: 83965.25 ± 5611.76
- PPL synthetic Mamba-2 tiny Q8_0: 88343.77 ± 5905.56
- PPL synthetic Mamba-1 tiny Q4_K_M: 145677.00 ± 7942.34
- Decode synthetic Llama tiny Q4_K_M (contrast): 88.7 t/s @ 1,024 -> 37.5 t/s @ 4,096 (-58%), measured/predicted 21%
- Decode synthetic Mamba-1 tiny Q4_K_M: 657.4 t/s @ 1,024 -> 578.4 t/s @ 8,192 (-12%), measured/predicted 62%
- Decode synthetic Mamba-2 tiny Q4_K_M: 613.5 t/s @ 1,024 -> 688.2 t/s @ 8,192 (+12%), measured/predicted 61%
- Decode synthetic Mamba-2 tiny Q8_0: 582.9 t/s @ 1,024 -> 629.8 t/s @ 8,192 (+8%), measured/predicted 76%
- Prefill synthetic Mamba-1 tiny Q4_K_M: pp512=3259, pp4096=3206, pp8192=3250 t/s
- Prefill synthetic Mamba-2 tiny Q4_K_M: pp512=9588, pp4096=8591, pp8192=10525 t/s
- Prefill synthetic Mamba-2 tiny Q8_0: pp512=9167, pp4096=7012, pp8192=8712 t/s
- Thread scaling synthetic Mamba-1 tiny Q4_K_M tg: x1.00 from 1 to 1 threads
- Thread scaling synthetic Mamba-1 tiny Q4_K_M pp512: x1.00 from 1 to 1 threads
- Thread scaling synthetic Mamba-2 tiny Q4_K_M tg: x1.00 from 1 to 1 threads
- Thread scaling synthetic Mamba-2 tiny Q4_K_M pp512: x1.00 from 1 to 1 threads
