# 10-minute talk (map onto the course's common slide template). Numbers: "Numbers for the slides" in SUMMARY.md

1. **Option 3 and key question** (30 s).
2. **Machine:** CPU, P/E cores, caches, SIMD, RAM, STREAM GB/s at 1..P threads (1 min).
3. **Setup and correctness:** commit, quantization rule, PPL table, batch == token-by-token (1 min).
4. **Prediction:** bytes/token breakdown, state 98 MiB (Mamba-2) vs 14 MiB (Mamba-1), predicted t/s (1 min).
5. **Decode vs context:** flat Mamba vs falling Llama; memory vs context (1.5 min).
6. **Prefill vs prompt and thread scaling,** with the bandwidth plateau (1 min).
7. **Where the time goes:** op breakdown plus the SSM_SCAN operator study. This is the answer to the key question (1.5 min).
8. **Predicted vs measured:** the gap, with each cause quantified (1 min).
9. **Own experiment:** micro-batch prediction vs measurement (1 min).
10. **Bonus:** correctness table (C++ kernels + official module code), time/step and FLOP/byte, the MIMO verdict on our CPU *and* on our GPU (1 min).
11. **Shared reference + second laptop:** reference pp512/tg128 (Rudra if it ran, else both laptops + attempt log); efficiency on both machines (plots/compare) (30 s).

Every slide states: model, quant, threads, n = 3, mean ± sd. Project 0 lost marks for missing numbers.
