# Report template (4 pages): every number comes from results/<machine>/SUMMARY.md

1. **Setup (~0.4 p).**
   * Hardware table (`hardware.md` + STREAM row, plus theoretical peak bandwidth).
   * llama.cpp commit + patch, build flags (`build_info.txt`).
   * Models: source checkpoints, converter, quantization rule, SHA-256.
   * Laptop hygiene, as recorded by preflight.
2. **Correctness (~0.3 p).**
   * PPL table with the Q4_K_M vs Q8_0 criterion.
   * The 3 prompts: quote one output.
   * Batch == token-by-token result.
   * Known issue: Mamba-1 perplexity needs one sequence per batch.
3. **Prediction (~0.4 p).**
   * Bytes per token (`bytes_per_token.md`): weights by group, state size, 2x vs 4x state traffic.
   * Predicted decode t/s, timestamped before the sweep.
4. **Results (~1.2 p).**
   * Plots: decode vs context (with the Llama contrast), prefill vs prompt, thread scaling, memory vs context.
   * Tables: mean ± sd, n = 3, peak RSS.
5. **Profiling (~0.6 p).**
   * Op breakdown plot, top-3 operators per phase.
   * SSM_SCAN operator study answering the key question, prefill and decode.
   * `perf` cross-check.
6. **Roofline gap (~0.5 p).** Predicted vs measured plot. Quantify each cause using the checklist in docs/THEORY.md.
7. **Own experiment (~0.3 p).** Question, prediction (written first), result plot, verdict.
8. **What we learned (~0.2 p).**
   * Shared reference number: Rudra, or both laptops plus `results/rudra-attempts.md`.
   * Cross-machine efficiency (`results/COMPARE.md`): does the roofline explanation transfer to the second laptop?
9. **Bonus (appendix or 1 extra page if allowed):** `bonus/mamba3/results/<machine>/ANSWER.md`, CPU answer plus the GPU contrast.
