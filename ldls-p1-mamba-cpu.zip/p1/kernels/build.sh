#!/usr/bin/env bash
# Build the C++ kernels and tools. ggml_op_test and ssm_scan_bench link against the ggml libraries built by
# scripts/00_build_llamacpp.sh (same pinned commit). Usage:  kernels/build.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
LLAMA="${LLAMA_CPP_DIR:-$HERE/../../llama.cpp}"
BIN="${LLAMA_BIN_DIR:-$LLAMA/build/bin}"
OS="$(uname -s)"; ARCHN="$(uname -m)"
ARCH="-march=native"; OMP="-fopenmp"; CXX="${CXX:-g++}"
if [ "$ARCHN" = "arm64" ] || [ "$ARCHN" = "aarch64" ]; then ARCH="-mcpu=native"; fi
if [ "$OS" = "Darwin" ]; then
  CXX="${CXX_OVERRIDE:-clang++}"
  if P="$(brew --prefix libomp 2>/dev/null)" && [ -d "$P" ]; then
    OMP="-Xpreprocessor -fopenmp -I$P/include -L$P/lib -lomp"
  else
    echo "!! libomp not found (brew install libomp): building single-threaded"; OMP=""
  fi
fi
FLAGS="-O3 $ARCH -std=c++17 -Wall -Wno-unknown-pragmas"
mkdir -p build
set -x
$CXX $FLAGS $OMP src/test_step.cpp  -o build/test_step
$CXX $FLAGS $OMP src/bench_step.cpp -o build/bench_step
if [ "$OS" = "Linux" ] && [ "$ARCHN" = "x86_64" ]; then   # laptop code path (AVX2+FMA) even on AVX-512 machines
  $CXX -O3 -march=haswell -std=c++17 $OMP src/test_step.cpp  -o build/test_step_avx2
  $CXX -O3 -march=haswell -std=c++17 $OMP src/bench_step.cpp -o build/bench_step_avx2
fi
if [ -d "$LLAMA/ggml/include" ] && ls "$BIN"/libggml* >/dev/null 2>&1; then
  GG="-I$LLAMA/ggml/include -L$BIN -lggml -lggml-base -lggml-cpu -Wl,-rpath,$BIN"
  $CXX $FLAGS $OMP src/ggml_op_test.cpp   $GG -o build/ggml_op_test
  $CXX $FLAGS $OMP src/ssm_scan_bench.cpp $GG -o build/ssm_scan_bench
else
  set +x; echo "!! ggml not found at $LLAMA (run scripts/00_build_llamacpp.sh): skipped ggml_op_test, ssm_scan_bench"
fi
