// One-layer decode steps on CPU for Mamba-3 (SISO and MIMO) and Mamba-2.
//
// Math follows the official references (state-spaces/mamba @ e9594ce):
//   Mamba-3: Mamba3.step with  rms_norm_ref, apply_rotary_qk_inference_reference,
//            selective_state_update_fused_ref_v2   (exponential-trapezoidal update, data-dependent RoPE)
//   Mamba-2: Mamba2.step with  selective_state_update_ref, rms_norm_ref (gated, norm_before_gate=False)
// All arithmetic is float32; weights are float32 or bfloat16 (converted on load inside the GEMV).
// Kernels are templates on the vector type V (ScalarV or NativeV, see simd.h); the hot loop is the
// state update + readout, vectorised along d_state (contiguous), threaded over heads (OpenMP).
#pragma once
#include "simd.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <map>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif

static constexpr float PI_F = 3.14159265358979323846f;
static constexpr float TWO_PI_F = 6.28318530717958647692f;

static inline double now_s() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
static inline float softplus_f(float x) { return x > 20.0f ? x : std::log1p(std::exp(x)); }  // = F.softplus
static inline float sigmoid_f(float x) { return 1.0f / (1.0f + std::exp(-x)); }
static inline float silu_f(float x) { return x * sigmoid_f(x); }
static inline float heavy_tail(float x) { return x >= 0.0f ? 1.0f + x : 1.0f / (1.0f - x); }

// ------------------------------------------------------------------------------------------ configs
struct M3Config {
    int d_model, d_state, headdim, nheads, ngroups = 1, d_inner, R, num_angles, d_in_proj;
    bool mimo;
    float A_floor = 1e-4f;
};
static inline M3Config m3_config(int d_model, int d_state = 128, int headdim = 64, bool mimo = false, int rank = 4,
                                 int expand = 2) {
    M3Config c;
    c.d_model = d_model;
    c.d_state = d_state;
    c.headdim = headdim;
    c.d_inner = expand * d_model;
    c.nheads = c.d_inner / headdim;
    c.mimo = mimo;
    c.R = mimo ? rank : 1;
    int split = d_state / 2;  // rope_fraction = 0.5
    split -= split % 2;
    c.num_angles = split / 2;
    c.d_in_proj = 2 * c.d_inner + 2 * d_state * c.ngroups * c.R + 3 * c.nheads + c.num_angles;
    return c;
}
struct M2Config {
    int d_model, d_state, headdim, nheads, ngroups = 1, d_inner, d_conv = 4, conv_dim, d_in_proj;
};
static inline M2Config m2_config(int d_model, int d_state = 128, int headdim = 64, int expand = 2) {
    M2Config c;
    c.d_model = d_model;
    c.d_state = d_state;
    c.headdim = headdim;
    c.d_inner = expand * d_model;
    c.nheads = c.d_inner / headdim;
    c.conv_dim = c.d_inner + 2 * c.ngroups * d_state;
    c.d_in_proj = 2 * c.d_inner + 2 * c.ngroups * d_state + c.nheads;
    return c;
}

// ------------------------------------------------------------------------------------------ GEMV
// y[i] = sum_j W[i, j] x[j]; W row-major (rows x cols), float32 or bf16. Call inside an omp parallel region.
template <typename V, typename WT>
static void gemv_rows(const WT * W, int rows, int cols, const float * x, float * y) {
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
    for (int i = 0; i < rows; i++) {
        const WT * w = W + (size_t) i * cols;
        V a0 = V::zero(), a1 = V::zero(), a2 = V::zero(), a3 = V::zero();
        int j = 0;
        auto ld = [&](int k) {
            if constexpr (std::is_same<WT, float>::value) return V::load(w + k); else return V::load_bf16(w + k);
        };
        for (; j + 4 * V::W <= cols; j += 4 * V::W) {
            a0 = V::fma(ld(j), V::load(x + j), a0);
            a1 = V::fma(ld(j + V::W), V::load(x + j + V::W), a1);
            a2 = V::fma(ld(j + 2 * V::W), V::load(x + j + 2 * V::W), a2);
            a3 = V::fma(ld(j + 3 * V::W), V::load(x + j + 3 * V::W), a3);
        }
        float s = ((a0 + a1) + (a2 + a3)).hsum();
        for (; j < cols; j++) {
            float wv;
            if constexpr (std::is_same<WT, float>::value) wv = w[j]; else wv = bf16_to_f32(w[j]);
            s += wv * x[j];
        }
        y[i] = s;
    }
}

struct Mat {  // row-major matrix with optional bf16 copy
    int rows = 0, cols = 0;
    std::vector<float> f32;
    std::vector<bf16_t> bf16;
    void make_bf16() {
        bf16.resize(f32.size());
        for (size_t i = 0; i < f32.size(); i++) bf16[i] = f32_to_bf16(f32[i]);
    }
};
template <typename V>
static void gemv(const Mat & m, bool use_bf16, const float * x, float * y) {
    if (use_bf16) gemv_rows<V, bf16_t>(m.bf16.data(), m.rows, m.cols, x, y);
    else gemv_rows<V, float>(m.f32.data(), m.rows, m.cols, x, y);
}

// ------------------------------------------------------------------------------------------ Mamba-3
struct M3Weights {
    Mat in_proj, out_proj;                  // (d_in_proj x d_model), (d_model x d_inner)
    std::vector<float> dt_bias, B_bias, C_bias, B_norm_w, C_norm_w, D;   // B/C bias: (H x R x N)
    std::vector<float> mimo_x, mimo_z, mimo_o;   // (R x H x P) = official rearrange("h r p -> r h p")
};
struct M3State {
    std::vector<float> angle, ssm, k, v;    // (H x A), (H x P x N), (R x H x N), (H x P)
};
struct M3Scratch {
    std::vector<float> zx, Bn, Cn, Brot, Crot, alpha, beta, gamma, y, ones;
};

static inline void m3_alloc(const M3Config & c, M3State & s, M3Scratch & w) {
    const int H = c.nheads, P = c.headdim, N = c.d_state, R = c.R;
    s.angle.assign((size_t) H * c.num_angles, 0.0f);
    s.ssm.assign((size_t) H * P * N, 0.0f);
    s.k.assign((size_t) R * H * N, 0.0f);
    s.v.assign((size_t) H * P, 0.0f);
    w.zx.assign(c.d_in_proj, 0.0f);
    w.Bn.assign((size_t) R * N, 0.0f);
    w.Cn.assign((size_t) R * N, 0.0f);
    w.Brot.assign((size_t) R * H * N, 0.0f);
    w.Crot.assign((size_t) R * H * N, 0.0f);
    w.alpha.assign(H, 0.0f);
    w.beta.assign(H, 0.0f);
    w.gamma.assign(H, 0.0f);
    w.y.assign((size_t) H * P, 0.0f);
    w.ones.assign((size_t) R * H * P, 1.0f);
}

// State update + readout for one head. S: (P x N). B/C rows of rank r start at  base + r*rstride.
// MIMO projections are indexed [r*pstride + p]; for SISO they point to ones.
template <typename V, int R>
static inline void m3_core_head(int P, int N, float alpha, float beta, float gamma, float Dh, float * S,
                                const float * x, const float * xprev, const float * z,
                                const float * Bcur, const float * Bprev, const float * Ccur, size_t rstride,
                                const float * xproj, const float * zproj, const float * oproj, size_t pstride,
                                float * y) {
    const V va = V::set1(alpha);
    for (int p = 0; p < P; p++) {
        float xv[R], xs[R];
        V g[R], b[R], acc[R];
        for (int r = 0; r < R; r++) {
            xv[r] = x[p] * xproj[r * pstride + p];
            xs[r] = xprev[p] * xproj[r * pstride + p];
            g[r] = V::set1(gamma * xv[r]);
            b[r] = V::set1(beta * xs[r]);
            acc[r] = V::zero();
        }
        float * Sp = S + (size_t) p * N;
        int s = 0;
        for (; s + V::W <= N; s += V::W) {
            V st = V::load(Sp + s) * va;
            for (int r = 0; r < R; r++) {
                st = V::fma(g[r], V::load(Bcur + r * rstride + s), st);
                st = V::fma(b[r], V::load(Bprev + r * rstride + s), st);
            }
            st.store(Sp + s);
            for (int r = 0; r < R; r++) acc[r] = V::fma(st, V::load(Ccur + r * rstride + s), acc[r]);
        }
        float tail[R];
        for (int r = 0; r < R; r++) tail[r] = 0.0f;
        for (; s < N; s++) {  // remainder (N not a multiple of the vector width)
            float st = Sp[s] * alpha;
            for (int r = 0; r < R; r++) st += gamma * xv[r] * Bcur[r * rstride + s] + beta * xs[r] * Bprev[r * rstride + s];
            Sp[s] = st;
            for (int r = 0; r < R; r++) tail[r] += st * Ccur[r * rstride + s];
        }
        float yp = 0.0f;
        for (int r = 0; r < R; r++) {
            float o = acc[r].hsum() + tail[r] + Dh * xv[r];
            const float zv = z[p] * zproj[r * pstride + p];
            o *= silu_f(zv);
            yp += o * oproj[r * pstride + p];
        }
        y[p] = yp;
    }
}

template <typename V, int R>
static void m3_core_all(const M3Config & c, const M3Weights & w, M3State & st, M3Scratch & sc, int h0, int h1) {
    const int P = c.headdim, N = c.d_state, H = c.nheads;
    const float * x = sc.zx.data() + c.d_inner;
    const float * z = sc.zx.data();
    const bool mimo = c.mimo;
    for (int h = h0; h < h1; h++) {
        const size_t po = (size_t) h * P;
        m3_core_head<V, R>(P, N, sc.alpha[h], sc.beta[h], sc.gamma[h], w.D[h], st.ssm.data() + po * N,
                           x + po, st.v.data() + po, z + po,
                           sc.Brot.data() + (size_t) h * N, st.k.data() + (size_t) h * N, sc.Crot.data() + (size_t) h * N,
                           (size_t) H * N,
                           mimo ? w.mimo_x.data() + po : sc.ones.data(), mimo ? w.mimo_z.data() + po : sc.ones.data(),
                           mimo ? w.mimo_o.data() + po : sc.ones.data(), mimo ? (size_t) H * P : 0, sc.y.data() + po);
    }
}

// Pre-processing: per-head scalars, RMS-normed B/C, bias + data-dependent rotary (official order).
static inline void m3_preprocess_shared(const M3Config & c, const M3Weights & w, M3Scratch & sc) {
    const int H = c.nheads, N = c.d_state, R = c.R;
    const float * zx = sc.zx.data();
    const float * Braw = zx + 2 * c.d_inner;
    const float * Craw = Braw + (size_t) R * N;
    const float * dd_dt = Craw + (size_t) R * N;
    const float * dd_A = dd_dt + H;
    const float * trap = dd_A + H;
    for (int h = 0; h < H; h++) {
        float A = -heavy_tail(dd_A[h]);
        A = std::min(A, -c.A_floor);
        const float DT = softplus_f(dd_dt[h] + w.dt_bias[h]);
        const float lam = sigmoid_f(trap[h]);
        const float alpha = std::exp(A * DT);
        sc.alpha[h] = alpha;
        sc.beta[h] = (1.0f - lam) * DT * alpha;
        sc.gamma[h] = lam * DT;
    }
    for (int r = 0; r < R; r++) {  // rms_norm_ref over d_state (ngroups = 1), eps = 1e-5
        for (int which = 0; which < 2; which++) {
            const float * in = (which ? Craw : Braw) + (size_t) r * N;
            const float * nw = which ? w.C_norm_w.data() : w.B_norm_w.data();
            float * out = (which ? sc.Cn.data() : sc.Bn.data()) + (size_t) r * N;
            double ss = 0;
            for (int s = 0; s < N; s++) ss += (double) in[s] * in[s];
            const float rstd = 1.0f / std::sqrt((float) (ss / N) + 1e-5f);
            for (int s = 0; s < N; s++) out[s] = in[s] * rstd * nw[s];
        }
    }
}

static inline void m3_rotary_head(const M3Config & c, const M3Weights & w, M3State & st, M3Scratch & sc, int h) {
    const int H = c.nheads, N = c.d_state, R = c.R, A = c.num_angles;
    const float * zx = sc.zx.data();
    const float * dd_dt = zx + 2 * c.d_inner + 2 * (size_t) R * N;
    const float * ang = dd_dt + 3 * H;
    const float DT = softplus_f(dd_dt[h] + w.dt_bias[h]);
    float cs[256], sn[256];
    for (int a = 0; a < A; a++) {
        float th = st.angle[(size_t) h * A + a] + std::tanh(ang[a]) * DT * PI_F;
        th -= TWO_PI_F * std::floor(th / TWO_PI_F);  // keep float32 cos/sin accurate over long sequences
        st.angle[(size_t) h * A + a] = th;
        cs[a] = std::cos(th);
        sn[a] = std::sin(th);
    }
    for (int r = 0; r < R; r++) {
        for (int which = 0; which < 2; which++) {  // 0: B (k), 1: C (q)
            const float * nrm = (which ? sc.Cn.data() : sc.Bn.data()) + (size_t) r * N;
            const float * bias = (which ? w.C_bias.data() : w.B_bias.data()) + ((size_t) h * R + r) * N;
            float * out = (which ? sc.Crot.data() : sc.Brot.data()) + ((size_t) r * H + h) * N;
            for (int s = 0; s < N; s++) out[s] = nrm[s] + bias[s];
            if (!c.mimo) {  // interleaved pairs (2a, 2a+1)
                for (int a = 0; a < A; a++) {
                    const float q0 = out[2 * a], q1 = out[2 * a + 1];
                    out[2 * a] = q0 * cs[a] - q1 * sn[a];
                    out[2 * a + 1] = q0 * sn[a] + q1 * cs[a];
                }
            } else {        // halves (i, i + N/2); identity beyond the rotary angles
                const int half = N / 2;
                for (int a = 0; a < A && a < half; a++) {
                    const float q0 = out[a], q1 = out[a + half];
                    out[a] = q0 * cs[a] - q1 * sn[a];
                    out[a + half] = q0 * sn[a] + q1 * cs[a];
                }
            }
        }
    }
}

template <typename V>
static void m3_core_dispatch(const M3Config & c, const M3Weights & w, M3State & st, M3Scratch & sc, int h0, int h1) {
    switch (c.R) {
        case 1: m3_core_all<V, 1>(c, w, st, sc, h0, h1); break;
        case 2: m3_core_all<V, 2>(c, w, st, sc, h0, h1); break;
        case 4: m3_core_all<V, 4>(c, w, st, sc, h0, h1); break;
        case 8: m3_core_all<V, 8>(c, w, st, sc, h0, h1); break;
        default: throw std::runtime_error("mimo rank must be 1, 2, 4 or 8");
    }
}

// The state update+readout only (inputs already in scratch): what bench "core" mode times.
template <typename V>
static void m3_core_step(const M3Config & c, const M3Weights & w, M3State & st, M3Scratch & sc) {
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int h = 0; h < c.nheads; h++) m3_core_dispatch<V>(c, w, st, sc, h, h + 1);
}

// Full one-layer decode step: out (d_model) = Mamba3(u (d_model)), states updated in place.
template <typename V>
static void m3_layer_step(const M3Config & c, const M3Weights & w, M3State & st, M3Scratch & sc, const float * u,
                          float * out, bool bf16w) {
#ifdef _OPENMP
#pragma omp parallel
#endif
    {
        gemv<V>(w.in_proj, bf16w, u, sc.zx.data());          // in_proj
#ifdef _OPENMP
#pragma omp single
#endif
        m3_preprocess_shared(c, w, sc);                       // A, DT, trap -> alpha/beta/gamma; B/C RMSNorm
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
        for (int h = 0; h < c.nheads; h++) m3_rotary_head(c, w, st, sc, h);   // bias + RoPE
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
        for (int h = 0; h < c.nheads; h++) m3_core_dispatch<V>(c, w, st, sc, h, h + 1);  // trapezoidal update
        gemv<V>(w.out_proj, bf16w, sc.y.data(), out);        // out_proj
    }
    st.k.swap(sc.Brot);                                       // k_state <- rotated B of this step
    std::copy(sc.zx.begin() + c.d_inner, sc.zx.begin() + 2 * c.d_inner, st.v.begin());  // v_state <- x
}

// ------------------------------------------------------------------------------------------ Mamba-2
struct M2Weights {
    Mat in_proj, out_proj;
    std::vector<float> conv_w, conv_b, dt_bias, A, D, norm_w;  // A = -exp(A_log)
};
struct M2State {
    std::vector<float> conv, ssm;  // (conv_dim x d_conv), (H x P x N)
};
struct M2Scratch {
    std::vector<float> zx, xbc, dA, dt, y;
};
static inline void m2_alloc(const M2Config & c, M2State & s, M2Scratch & w) {
    s.conv.assign((size_t) c.conv_dim * c.d_conv, 0.0f);
    s.ssm.assign((size_t) c.nheads * c.headdim * c.d_state, 0.0f);
    w.zx.assign(c.d_in_proj, 0.0f);
    w.xbc.assign(c.conv_dim, 0.0f);
    w.dA.assign(c.nheads, 0.0f);
    w.dt.assign(c.nheads, 0.0f);
    w.y.assign(c.d_inner, 0.0f);
}

template <typename V>
static inline void m2_core_head(const M2Config & c, const M2Weights & w, M2State & st, M2Scratch & sc, int h) {
    const int P = c.headdim, N = c.d_state;
    const float * x = sc.xbc.data() + (size_t) h * P;
    const float * B = sc.xbc.data() + c.d_inner;
    const float * C = B + N;
    float * S = st.ssm.data() + (size_t) h * P * N;
    const V vdA = V::set1(sc.dA[h]);
    for (int p = 0; p < P; p++) {
        const float xdt = x[p] * sc.dt[h];
        const V vx = V::set1(xdt);
        V acc = V::zero();
        float * Sp = S + (size_t) p * N;
        int s = 0;
        for (; s + V::W <= N; s += V::W) {
            V t = V::fma(V::load(B + s), vx, V::load(Sp + s) * vdA);  // state*dA + (dt*x)*B
            t.store(Sp + s);
            acc = V::fma(t, V::load(C + s), acc);
        }
        float sum = acc.hsum();
        for (; s < N; s++) {
            const float t = Sp[s] * sc.dA[h] + B[s] * xdt;
            Sp[s] = t;
            sum += t * C[s];
        }
        sc.y[(size_t) h * P + p] = sum + w.D[h] * x[p];
    }
}

template <typename V>
static void m2_core_step(const M2Config & c, const M2Weights & w, M2State & st, M2Scratch & sc) {
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int h = 0; h < c.nheads; h++) m2_core_head<V>(c, w, st, sc, h);
}

template <typename V>
static void m2_layer_step(const M2Config & c, const M2Weights & w, M2State & st, M2Scratch & sc, const float * u,
                          float * out, bool bf16w) {
    const int K = c.d_conv;
#ifdef _OPENMP
#pragma omp parallel
#endif
    {
        gemv<V>(w.in_proj, bf16w, u, sc.zx.data());
        const float * xBC_in = sc.zx.data() + c.d_inner;
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
        for (int ch = 0; ch < c.conv_dim; ch++) {           // depthwise causal conv step + SiLU
            float * cs = st.conv.data() + (size_t) ch * K;
            for (int k = 0; k < K - 1; k++) cs[k] = cs[k + 1];
            cs[K - 1] = xBC_in[ch];
            float a = w.conv_b[ch];
            for (int k = 0; k < K; k++) a += cs[k] * w.conv_w[(size_t) ch * K + k];
            sc.xbc[ch] = silu_f(a);
        }
#ifdef _OPENMP
#pragma omp single
#endif
        {
            const float * dtr = sc.zx.data() + c.d_inner + c.conv_dim;
            for (int h = 0; h < c.nheads; h++) {
                sc.dt[h] = softplus_f(dtr[h] + w.dt_bias[h]);
                sc.dA[h] = std::exp(sc.dt[h] * w.A[h]);
            }
        }
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
        for (int h = 0; h < c.nheads; h++) m2_core_head<V>(c, w, st, sc, h);
#ifdef _OPENMP
#pragma omp single
#endif
        {  // gated RMSNorm, norm_before_gate=False, one group: y = rmsnorm(y * silu(z)) * w
            const float * z = sc.zx.data();
            double ss = 0;
            for (int i = 0; i < c.d_inner; i++) {
                sc.y[i] *= silu_f(z[i]);
                ss += (double) sc.y[i] * sc.y[i];
            }
            const float rstd = 1.0f / std::sqrt((float) (ss / c.d_inner) + 1e-5f);
            for (int i = 0; i < c.d_inner; i++) sc.y[i] = sc.y[i] * rstd * w.norm_w[i];
        }
        gemv<V>(w.out_proj, bf16w, sc.y.data(), out);
    }
}

// ------------------------------------------------------------------------------------------ npy / traces
struct Npy {
    std::vector<size_t> shape;
    std::vector<double> data;  // converted to double
    size_t size() const { size_t n = 1; for (auto s : shape) n *= s; return n; }
};
static inline Npy load_npy(const std::string & path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open " + path);
    char magic[6];
    f.read(magic, 6);
    if (std::string(magic + 1, 5) != "NUMPY") throw std::runtime_error("not npy: " + path);
    unsigned char ver[2];
    f.read((char *) ver, 2);
    uint32_t hlen = 0;
    if (ver[0] == 1) { uint16_t h; f.read((char *) &h, 2); hlen = h; } else f.read((char *) &hlen, 4);
    std::string hdr(hlen, ' ');
    f.read(&hdr[0], hlen);
    const bool f8 = hdr.find("'<f8'") != std::string::npos, f4 = hdr.find("'<f4'") != std::string::npos;
    if ((!f8 && !f4) || hdr.find("'fortran_order': False") == std::string::npos)
        throw std::runtime_error("unsupported npy (need C-order <f4/<f8): " + path);
    Npy a;
    auto l = hdr.find('('), r = hdr.find(')');
    std::stringstream ss(hdr.substr(l + 1, r - l - 1));
    std::string tok;
    while (std::getline(ss, tok, ','))
        if (tok.find_first_of("0123456789") != std::string::npos) a.shape.push_back(std::stoul(tok));
    const size_t n = a.size();
    a.data.resize(n);
    if (f8) f.read((char *) a.data.data(), n * 8);
    else {
        std::vector<float> t(n);
        f.read((char *) t.data(), n * 4);
        for (size_t i = 0; i < n; i++) a.data[i] = t[i];
    }
    return a;
}
static inline std::vector<float> to_f32(const Npy & a) { return std::vector<float>(a.data.begin(), a.data.end()); }

static inline std::map<std::string, std::string> load_json_flat(const std::string & path) {
    std::ifstream f(path);
    std::stringstream b;
    b << f.rdbuf();
    std::string s = b.str();
    std::map<std::string, std::string> m;
    size_t i = 0;
    while ((i = s.find('"', i)) != std::string::npos) {
        size_t j = s.find('"', i + 1);
        std::string key = s.substr(i + 1, j - i - 1);
        size_t k = s.find(':', j);
        if (k == std::string::npos) break;
        size_t e = s.find_first_of(",}\n", k + 1);
        std::string v = s.substr(k + 1, e - k - 1);
        v.erase(0, v.find_first_not_of(" \""));
        v.erase(v.find_last_not_of(" \"") + 1);
        m[key] = v;
        i = e;
    }
    return m;
}

static inline int num_threads() {
#ifdef _OPENMP
    return omp_get_max_threads();
#else
    return 1;
#endif
}
static inline void set_threads(int t) {
#ifdef _OPENMP
    omp_set_num_threads(t);
#else
    (void) t;
#endif
}
