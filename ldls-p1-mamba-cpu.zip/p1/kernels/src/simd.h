// Minimal SIMD layer: one kernel source, instantiated for the scalar type and the native vector type.
// Native = AVX-512F (16 lanes) > AVX2+FMA (8) > NEON (4) > scalar (1), chosen at compile time.
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>

#if defined(__AVX512F__) || defined(__AVX2__)
#include <immintrin.h>
#endif
#if defined(__ARM_NEON)
#include <arm_neon.h>
#endif

typedef uint16_t bf16_t;

static inline float bf16_to_f32(bf16_t h) {
    uint32_t u = (uint32_t) h << 16;
    float f;
    std::memcpy(&f, &u, 4);
    return f;
}
static inline bf16_t f32_to_bf16(float f) {  // round to nearest even
    uint32_t u;
    std::memcpy(&u, &f, 4);
    u += 0x7fff + ((u >> 16) & 1);
    return (bf16_t) (u >> 16);
}

struct ScalarV {
    static constexpr int W = 1;
    static constexpr const char * name = "scalar";
    float v;
    static ScalarV load(const float * p) { return {*p}; }
    static ScalarV load_bf16(const bf16_t * p) { return {bf16_to_f32(*p)}; }
    static ScalarV set1(float x) { return {x}; }
    static ScalarV zero() { return {0.0f}; }
    void store(float * p) const { *p = v; }
    friend ScalarV operator+(ScalarV a, ScalarV b) { return {a.v + b.v}; }
    friend ScalarV operator*(ScalarV a, ScalarV b) { return {a.v * b.v}; }
    static ScalarV fma(ScalarV a, ScalarV b, ScalarV c) { return {a.v * b.v + c.v}; }  // a*b + c
    float hsum() const { return v; }
};

#if defined(__AVX512F__)
struct NativeV {
    static constexpr int W = 16;
    static constexpr const char * name = "avx512";
    __m512 v;
    static NativeV load(const float * p) { return {_mm512_loadu_ps(p)}; }
    static NativeV load_bf16(const bf16_t * p) {
        __m512i x = _mm512_cvtepu16_epi32(_mm256_loadu_si256((const __m256i *) p));
        return {_mm512_castsi512_ps(_mm512_slli_epi32(x, 16))};
    }
    static NativeV set1(float x) { return {_mm512_set1_ps(x)}; }
    static NativeV zero() { return {_mm512_setzero_ps()}; }
    void store(float * p) const { _mm512_storeu_ps(p, v); }
    friend NativeV operator+(NativeV a, NativeV b) { return {_mm512_add_ps(a.v, b.v)}; }
    friend NativeV operator*(NativeV a, NativeV b) { return {_mm512_mul_ps(a.v, b.v)}; }
    static NativeV fma(NativeV a, NativeV b, NativeV c) { return {_mm512_fmadd_ps(a.v, b.v, c.v)}; }
    float hsum() const { return _mm512_reduce_add_ps(v); }
};
#elif defined(__AVX2__) && defined(__FMA__)
struct NativeV {
    static constexpr int W = 8;
    static constexpr const char * name = "avx2";
    __m256 v;
    static NativeV load(const float * p) { return {_mm256_loadu_ps(p)}; }
    static NativeV load_bf16(const bf16_t * p) {
        __m256i x = _mm256_cvtepu16_epi32(_mm_loadu_si128((const __m128i *) p));
        return {_mm256_castsi256_ps(_mm256_slli_epi32(x, 16))};
    }
    static NativeV set1(float x) { return {_mm256_set1_ps(x)}; }
    static NativeV zero() { return {_mm256_setzero_ps()}; }
    void store(float * p) const { _mm256_storeu_ps(p, v); }
    friend NativeV operator+(NativeV a, NativeV b) { return {_mm256_add_ps(a.v, b.v)}; }
    friend NativeV operator*(NativeV a, NativeV b) { return {_mm256_mul_ps(a.v, b.v)}; }
    static NativeV fma(NativeV a, NativeV b, NativeV c) { return {_mm256_fmadd_ps(a.v, b.v, c.v)}; }
    float hsum() const {
        __m128 lo = _mm256_castps256_ps128(v), hi = _mm256_extractf128_ps(v, 1);
        lo = _mm_add_ps(lo, hi);
        __m128 sh = _mm_movehdup_ps(lo);
        __m128 s = _mm_add_ps(lo, sh);
        sh = _mm_movehl_ps(sh, s);
        s = _mm_add_ss(s, sh);
        return _mm_cvtss_f32(s);
    }
};
#elif defined(__ARM_NEON)
struct NativeV {
    static constexpr int W = 4;
    static constexpr const char * name = "neon";
    float32x4_t v;
    static NativeV load(const float * p) { return {vld1q_f32(p)}; }
    static NativeV load_bf16(const bf16_t * p) {
        return {vreinterpretq_f32_u32(vshll_n_u16(vld1_u16(p), 16))};
    }
    static NativeV set1(float x) { return {vdupq_n_f32(x)}; }
    static NativeV zero() { return {vdupq_n_f32(0.0f)}; }
    void store(float * p) const { vst1q_f32(p, v); }
    friend NativeV operator+(NativeV a, NativeV b) { return {vaddq_f32(a.v, b.v)}; }
    friend NativeV operator*(NativeV a, NativeV b) { return {vmulq_f32(a.v, b.v)}; }
    static NativeV fma(NativeV a, NativeV b, NativeV c) { return {vfmaq_f32(c.v, a.v, b.v)}; }
    float hsum() const { return vaddvq_f32(v); }
};
#else
typedef ScalarV NativeV;   // no SIMD ISA detected at compile time
#endif
