// Decode-step benchmark at a FIXED state size (default H=64 heads, P=64 headdim, N=128 d_state = 2 MiB fp32
// per layer, the Mamba-2 1.3B layer shape) for Mamba-2, Mamba-3 SISO and Mamba-3 MIMO (rank 2, 4).
//
// Modes
//   core-cache : state update + readout only, one layer -> the 2 MiB state stays in L2/L3
//   core-dram  : same kernel, cycling through L layers whose states together exceed the LLC
//                (what real decode does: each layer's state is touched once per token)
//   layer      : full layer step (in_proj GEMV, preprocessing, RoPE, update, gate, out_proj GEMV) cycling
//                through L layers with distinct bf16 (default) weights
// Output: one CSV row per (config, mode, threads, rep) with ns/step, FLOP and byte counts (analytical, see
// bytes_core/flops_core), arithmetic intensity, achieved GFLOP/s and GB/s.
//
//   bench_step [--threads 1,2,4] [--reps 3] [--modes core-cache,core-dram,layer] [--configs m2,siso,mimo2,mimo4]
//              [--d-model 2048] [--d-state 128] [--weights bf16|f32] [--llc-mib X] [--csv out.csv] [--min-time 0.25]
#include "ssm.h"

#include <set>

struct Args {
    std::vector<int> threads;
    int reps = 3, d_model = 2048, d_state = 128, headdim = 64;
    std::set<std::string> modes{"core-cache", "core-dram", "layer"};
    std::vector<std::string> configs{"m2", "siso", "mimo2", "mimo4"};
    bool bf16 = true;
    double llc_mib = 0, min_time = 0.25;
    std::string csv = "bench_step.csv";
};

static std::vector<std::string> split(const std::string & s, char d) {
    std::vector<std::string> o;
    std::stringstream ss(s);
    std::string t;
    while (std::getline(ss, t, d)) if (!t.empty()) o.push_back(t);
    return o;
}

static double detect_llc_mib() {
    double best = 0;
    for (int i = 0; i < 8; i++) {  // Linux sysfs
        std::ifstream f("/sys/devices/system/cpu/cpu0/cache/index" + std::to_string(i) + "/size");
        std::string s;
        if (!(f >> s)) continue;
        double v = std::stod(s);
        if (s.back() == 'K') v /= 1024;
        best = std::max(best, v);
    }
#ifdef __APPLE__
    if (best == 0) best = 48;  // Apple SLC size is not exposed; assume large
#endif
    return best > 0 ? best : 32;
}

static std::mt19937 rng(42);
static void fill(std::vector<float> & v, float lo, float hi) {
    std::uniform_real_distribution<float> d(lo, hi);
    for (auto & x : v) x = d(rng);
}
static void fill_mat(Mat & m, int rows, int cols, bool bf16) {
    m.rows = rows;
    m.cols = cols;
    m.f32.resize((size_t) rows * cols);
    fill(m.f32, -0.02f, 0.02f);
    if (bf16) { m.make_bf16(); m.f32.clear(); m.f32.shrink_to_fit(); }
}

// ---------------------------------------------------------------- analytical counts (per layer, per step)
// core: state update + readout (+ D skip, gate, MIMO projections); bytes = fp32 state read+write + operands
static double flops_core(const std::string & cfg, int H, int P, int N, int R) {
    const double e = (double) H * P * N;
    if (cfg == "m2") return 5.0 * e + 2.0 * H * P;                    // s*dA + (dt x) B ; y += s*C ; + D x
    return (1.0 + 6.0 * R) * e + (double) H * P * R * 10.0;           // decay + 2R FMA update + R FMA readout ; gate
}
static double bytes_core(const std::string & cfg, int H, int P, int N, int R) {
    const double st = 8.0 * H * P * N;                                // fp32 state: read 4 B + write 4 B
    if (cfg == "m2") return st + 4.0 * (2.0 * N + 2.0 * H * P);       // B, C, x in, y out
    return st + 4.0 * (3.0 * R * H * N + 4.0 * H * P + 3.0 * R * H * P);  // B,Bprev,C ; x,xprev,z,y ; MIMO proj
}

struct Row {
    std::string cfg, mode;
    int R, threads, rep, layers;
    double ns, flops, bytes;
};

int main(int argc, char ** argv) {
    Args a;
    for (int i = 1; i + 1 < argc; i += 2) {
        std::string k = argv[i], v = argv[i + 1];
        if (k == "--threads") for (auto & t : split(v, ',')) a.threads.push_back(std::stoi(t));
        else if (k == "--reps") a.reps = std::stoi(v);
        else if (k == "--modes") { a.modes.clear(); for (auto & m : split(v, ',')) a.modes.insert(m); }
        else if (k == "--configs") a.configs = split(v, ',');
        else if (k == "--d-model") a.d_model = std::stoi(v);
        else if (k == "--d-state") a.d_state = std::stoi(v);
        else if (k == "--weights") a.bf16 = v == "bf16";
        else if (k == "--llc-mib") a.llc_mib = std::stod(v);
        else if (k == "--csv") a.csv = v;
        else if (k == "--min-time") a.min_time = std::stod(v);
        else { std::fprintf(stderr, "unknown arg %s\n", k.c_str()); return 2; }
    }
    if (a.threads.empty()) for (int t = 1; t <= num_threads(); t++) a.threads.push_back(t);
    if (a.llc_mib <= 0) a.llc_mib = detect_llc_mib();
    std::vector<Row> rows;
    std::printf("# simd=%s  LLC=%.0f MiB  d_model=%d d_state=%d  weights=%s\n", NativeV::name, a.llc_mib, a.d_model,
                a.d_state, a.bf16 ? "bf16" : "f32");
    std::printf("%-6s %-10s %3s %3s %6s %10s %8s %8s %7s\n", "config", "mode", "thr", "rep", "layers", "us/step",
                "GFLOP/s", "GB/s", "FLOP/B");

    for (const auto & cfg : a.configs) {
        const bool m2 = cfg == "m2";
        const int R = cfg == "mimo4" ? 4 : cfg == "mimo2" ? 2 : 1;
        M3Config c3 = m3_config(a.d_model, a.d_state, a.headdim, R > 1, R);
        M2Config c2 = m2_config(a.d_model, a.d_state, a.headdim);
        const int H = m2 ? c2.nheads : c3.nheads, P = a.headdim, N = a.d_state;
        const double state_mib = 4.0 * H * P * N / (1 << 20);
        for (const std::string mode : {"core-cache", "core-dram", "layer"}) {
            if (!a.modes.count(mode)) continue;
            // ---- build L layers
            double layer_w_mib = 0;
            if (mode == "layer") {
                const double win = (double) (m2 ? c2.d_in_proj : c3.d_in_proj) * a.d_model, wout = (double) a.d_model * (m2 ? c2.d_inner : c3.d_inner);
                layer_w_mib = (win + wout) * (a.bf16 ? 2 : 4) / (1 << 20);
            }
            int L = 1;
            if (mode == "core-dram") L = std::max(16, (int) std::ceil(4.0 * a.llc_mib / state_mib));
            if (mode == "layer") L = std::max(3, (int) std::ceil(2.0 * a.llc_mib / (layer_w_mib + state_mib)));
            std::vector<M3Weights> w3(m2 ? 0 : (mode == "layer" ? L : 1));
            std::vector<M2Weights> w2(m2 ? (mode == "layer" ? L : 1) : 0);
            std::vector<M3State> s3(m2 ? 0 : L);
            std::vector<M2State> s2(m2 ? L : 0);
            M3Scratch k3;
            M2Scratch k2;
            for (int l = 0; l < L; l++) {
                if (m2) m2_alloc(c2, s2[l], k2); else m3_alloc(c3, s3[l], k3);
                if (m2) fill(s2[l].ssm, -1, 1); else fill(s3[l].ssm, -1, 1);
            }
            for (size_t l = 0; l < (m2 ? w2.size() : w3.size()); l++) {
                if (m2) {
                    auto & w = w2[l];
                    if (mode == "layer") { fill_mat(w.in_proj, c2.d_in_proj, a.d_model, a.bf16); fill_mat(w.out_proj, a.d_model, c2.d_inner, a.bf16); }
                    w.conv_w.resize((size_t) c2.conv_dim * c2.d_conv); fill(w.conv_w, -0.3f, 0.3f);
                    w.conv_b.assign(c2.conv_dim, 0.0f);
                    w.dt_bias.assign(H, -4.0f);
                    w.A.resize(H); fill(w.A, -8.0f, -1.0f);
                    w.D.assign(H, 1.0f);
                    w.norm_w.assign(c2.d_inner, 1.0f);
                } else {
                    auto & w = w3[l];
                    if (mode == "layer") { fill_mat(w.in_proj, c3.d_in_proj, a.d_model, a.bf16); fill_mat(w.out_proj, a.d_model, c3.d_inner, a.bf16); }
                    w.dt_bias.assign(H, -4.0f);
                    w.B_bias.assign((size_t) H * R * N, 1.0f);
                    w.C_bias.assign((size_t) H * R * N, 1.0f);
                    w.B_norm_w.assign(N, 1.0f);
                    w.C_norm_w.assign(N, 1.0f);
                    w.D.assign(H, 1.0f);
                    if (R > 1) {
                        w.mimo_x.assign((size_t) R * H * P, 1.0f / R);
                        w.mimo_z.assign((size_t) R * H * P, 1.0f);
                        w.mimo_o.assign((size_t) R * H * P, 1.0f / R);
                    }
                }
            }
            // core modes: realistic pre-processed operands in scratch
            if (m2) {
                fill(k2.xbc, -1, 1); fill(k2.dt, 0.001f, 0.1f); fill(k2.dA, 0.9f, 0.999f);
            } else {
                fill(k3.zx, -1, 1); fill(k3.Brot, -1, 1); fill(k3.Crot, -1, 1);
                fill(k3.alpha, 0.9f, 0.999f); fill(k3.beta, 0.001f, 0.05f); fill(k3.gamma, 0.001f, 0.05f);
                for (auto & s : s3) { fill(s.k, -1, 1); fill(s.v, -1, 1); }
            }
            std::vector<float> u(a.d_model), out(a.d_model);
            fill(u, -1, 1);
            const double fl_core = flops_core(cfg, H, P, N, R), by_core = bytes_core(cfg, H, P, N, R);
            double fl = fl_core, by = by_core;
            if (mode == "layer") {
                const double win = (double) (m2 ? c2.d_in_proj : c3.d_in_proj) * a.d_model, wout = (double) a.d_model * (m2 ? c2.d_inner : c3.d_inner);
                fl += 2.0 * (win + wout);
                by += (win + wout) * (a.bf16 ? 2 : 4);
            }
            for (int T : a.threads) {
                set_threads(T);
                for (int rep = 1; rep <= a.reps; rep++) {
                    auto step = [&](int l) {
                        if (mode == "layer") {
                            if (m2) m2_layer_step<NativeV>(c2, w2[l], s2[l], k2, u.data(), out.data(), a.bf16);
                            else m3_layer_step<NativeV>(c3, w3[l], s3[l], k3, u.data(), out.data(), a.bf16);
                        } else {
                            if (m2) m2_core_step<NativeV>(c2, w2[0], s2[l], k2);
                            else m3_core_step<NativeV>(c3, w3[0], s3[l], k3);
                        }
                    };
                    for (int i = 0; i < 2 * L; i++) step(i % L);  // warm-up: touch everything once
                    long n = 0;
                    double t0 = now_s(), el = 0;
                    while (el < a.min_time || n < 2 * L) {
                        for (int i = 0; i < L; i++) step(i);
                        n += L;
                        el = now_s() - t0;
                    }
                    const double ns = el / n * 1e9;
                    rows.push_back({cfg, mode, R, T, rep, L, ns, fl, by});
                    std::printf("%-6s %-10s %3d %3d %6d %10.2f %8.2f %8.2f %7.2f\n", cfg.c_str(), mode.c_str(), T, rep,
                                L, ns / 1e3, fl / ns, by / ns, fl / by);
                    std::fflush(stdout);
                }
            }
        }
    }
    std::ofstream f(a.csv);
    f << "simd,llc_mib,d_model,d_state,heads,headdim,weights,config,R,mode,threads,rep,layers,ns_per_step,"
         "flops_per_step,bytes_per_step,flop_per_byte,gflops,gbps\n";
    for (auto & r : rows) {
        f << NativeV::name << "," << a.llc_mib << "," << a.d_model << "," << a.d_state << "," << (a.d_model * 2 / a.headdim) << ","
          << a.headdim << "," << (a.bf16 ? "bf16" : "f32") << "," << r.cfg << "," << r.R << "," << r.mode << "," << r.threads
          << "," << r.rep << "," << r.layers << "," << r.ns << "," << r.flops << "," << r.bytes << ","
          << r.flops / r.bytes << "," << r.flops / r.ns << "," << r.bytes / r.ns << "\n";
    }
    std::printf("# wrote %s\n", a.csv.c_str());
    return 0;
}
