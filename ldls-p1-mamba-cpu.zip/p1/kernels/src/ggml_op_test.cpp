// Stretch goal of the bonus: the Mamba-3 decode step as ggml operators inside a small ggml graph.
//
//   graph:  zx  = mul_mat(W_in, u)                         (ggml's own CPU matmul)
//           pre = custom(zx)          n_tasks=1            (A/DT/trap -> alpha,beta,gamma; RMSNorm B,C; RoPE)
//           y   = custom(zx, pre)     n_tasks=all threads  (trapezoidal state update + readout, heads split by ith/nth)
//           yc  = custom(y, zx, pre)  n_tasks=1            (commit k_state <- rotated B, v_state <- x)
//           out = mul_mat(W_out, yc)
// The ggml scheduler's barrier between nodes provides the ordering the step needs. The graph is built once
// and recomputed every step with new input data. Checked against the direct C++ step and the float64 trace.
//
//   ggml_op_test <trace_dir(mamba3_*)> [threads]
#include "ssm.h"

#include "ggml-cpu.h"
#include "ggml.h"

struct Layer {
    M3Config c;
    M3Weights w;
    M3State st;
    M3Scratch sc;
};

static void op_pre(ggml_tensor * dst, int ith, int nth, void * ud) {
    (void) nth;
    if (ith != 0) return;
    Layer & L = *(Layer *) ud;
    const ggml_tensor * zx = dst->src[0];
    std::memcpy(L.sc.zx.data(), zx->data, sizeof(float) * L.c.d_in_proj);
    m3_preprocess_shared(L.c, L.w, L.sc);
    for (int h = 0; h < L.c.nheads; h++) m3_rotary_head(L.c, L.w, L.st, L.sc, h);
    ((float *) dst->data)[0] = 1.0f;
}

static void op_core(ggml_tensor * dst, int ith, int nth, void * ud) {
    Layer & L = *(Layer *) ud;
    const int H = L.c.nheads, P = L.c.headdim;
    const int h0 = (int) ((long) H * ith / nth), h1 = (int) ((long) H * (ith + 1) / nth);
    if (h0 >= h1) return;
    m3_core_dispatch<NativeV>(L.c, L.w, L.st, L.sc, h0, h1);
    std::memcpy((float *) dst->data + (size_t) h0 * P, L.sc.y.data() + (size_t) h0 * P, sizeof(float) * (h1 - h0) * P);
}

static void op_commit(ggml_tensor * dst, int ith, int nth, void * ud) {
    (void) nth;
    if (ith != 0) return;
    Layer & L = *(Layer *) ud;
    std::memcpy(dst->data, dst->src[0]->data, sizeof(float) * L.c.d_inner);
    L.st.k.swap(L.sc.Brot);
    std::copy(L.sc.zx.begin() + L.c.d_inner, L.sc.zx.begin() + 2 * L.c.d_inner, L.st.v.begin());
}

int main(int argc, char ** argv) {
    if (argc < 2) { std::fprintf(stderr, "usage: %s <trace_dir> [threads]\n", argv[0]); return 2; }
    const std::string dir = argv[1];
    const int nthreads = argc > 2 ? std::atoi(argv[2]) : 1;
    auto cfg = load_json_flat(dir + "/config.json");
    if (cfg.at("kind") != "mamba3") { std::fprintf(stderr, "needs a mamba3 trace\n"); return 2; }
    auto L = [&](const std::string & n) { return load_npy(dir + "/" + n + ".npy"); };

    Layer G, D;  // G: inside the ggml graph, D: direct C++ step (same weights)
    G.c = m3_config(std::stoi(cfg.at("d_model")), std::stoi(cfg.at("d_state")), std::stoi(cfg.at("headdim")),
                    cfg.at("mimo") == "true", std::stoi(cfg.at("R")));
    const M3Config & c = G.c;
    auto mat = [&](Mat & m, const Npy & a) { m.rows = (int) a.shape[0]; m.cols = (int) a.shape[1]; m.f32 = to_f32(a); };
    mat(G.w.in_proj, L("w_in_proj"));
    mat(G.w.out_proj, L("w_out_proj"));
    G.w.dt_bias = to_f32(L("w_dt_bias")); G.w.B_bias = to_f32(L("w_B_bias")); G.w.C_bias = to_f32(L("w_C_bias"));
    G.w.B_norm_w = to_f32(L("w_B_norm_w")); G.w.C_norm_w = to_f32(L("w_C_norm_w")); G.w.D = to_f32(L("w_D"));
    if (c.mimo) {
        const int H = c.nheads, P = c.headdim, R = c.R;
        for (auto nm : {"w_mimo_x", "w_mimo_z", "w_mimo_o"}) {
            Npy a = L(nm);
            std::vector<float> t((size_t) R * H * P);
            for (int h = 0; h < H; h++) for (int r = 0; r < R; r++) for (int p = 0; p < P; p++)
                t[((size_t) r * H + h) * P + p] = (float) a.data[((size_t) h * R + r) * P + p];
            (std::string(nm) == "w_mimo_x" ? G.w.mimo_x : std::string(nm) == "w_mimo_z" ? G.w.mimo_z : G.w.mimo_o) = t;
        }
    }
    D.c = G.c;
    D.w = G.w;
    m3_alloc(c, G.st, G.sc);
    m3_alloc(c, D.st, D.sc);

    const size_t mem = sizeof(float) * ((size_t) c.d_in_proj * c.d_model + (size_t) c.d_model * c.d_inner
                                        + 4 * (size_t) c.d_in_proj + 8 * (size_t) c.d_inner) + 64 * ggml_tensor_overhead() + (1 << 20);
    ggml_init_params ip = {mem, nullptr, false};
    ggml_context * ctx = ggml_init(ip);
    ggml_tensor * Win = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, c.d_model, c.d_in_proj);   // ne0 = row length
    ggml_tensor * Wout = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, c.d_inner, c.d_model);
    std::memcpy(Win->data, G.w.in_proj.f32.data(), ggml_nbytes(Win));
    std::memcpy(Wout->data, G.w.out_proj.f32.data(), ggml_nbytes(Wout));
    ggml_tensor * u = ggml_new_tensor_1d(ctx, GGML_TYPE_F32, c.d_model);
    ggml_tensor * zx = ggml_mul_mat(ctx, Win, u);
    ggml_tensor * a1[] = {zx};
    ggml_tensor * pre = ggml_custom_4d(ctx, GGML_TYPE_F32, 1, 1, 1, 1, a1, 1, op_pre, 1, &G);
    ggml_tensor * a2[] = {zx, pre};
    ggml_tensor * y = ggml_custom_4d(ctx, GGML_TYPE_F32, c.d_inner, 1, 1, 1, a2, 2, op_core, GGML_N_TASKS_MAX, &G);
    ggml_tensor * a3[] = {y, zx, pre};
    ggml_tensor * yc = ggml_custom_4d(ctx, GGML_TYPE_F32, c.d_inner, 1, 1, 1, a3, 3, op_commit, 1, &G);
    ggml_tensor * out = ggml_mul_mat(ctx, Wout, yc);
    ggml_cgraph * gf = ggml_new_graph(ctx);
    ggml_build_forward_expand(gf, out);

    Npy U = L("u"), Y = L("y_ref");
    const int T = (int) U.shape[0];
    std::vector<float> uu(c.d_model), yd(c.d_model);
    double worst_ref = 0, worst_direct = 0, t_graph = 0, t_direct = 0;
    set_threads(nthreads);
    for (int t = 0; t < T; t++) {
        for (int i = 0; i < c.d_model; i++) uu[i] = (float) U.data[(size_t) t * c.d_model + i];
        std::memcpy(u->data, uu.data(), sizeof(float) * c.d_model);
        double t0 = now_s();
        ggml_graph_compute_with_ctx(ctx, gf, nthreads);
        t_graph += now_s() - t0;
        t0 = now_s();
        m3_layer_step<NativeV>(D.c, D.w, D.st, D.sc, uu.data(), yd.data(), false);
        t_direct += now_s() - t0;
        const float * yo = (const float *) out->data;
        double num = 0, den = 0, numd = 0, dend = 0;
        for (int i = 0; i < c.d_model; i++) {
            const double r = Y.data[(size_t) t * c.d_model + i];
            num = std::max(num, std::fabs(yo[i] - r));
            den = std::max(den, std::fabs(r));
            numd = std::max(numd, (double) std::fabs(yo[i] - yd[i]));
            dend = std::max(dend, (double) std::fabs(yd[i]));
        }
        worst_ref = std::max(worst_ref, num / den);
        worst_direct = std::max(worst_direct, numd / dend);
    }
    const bool ok = worst_ref <= 1e-4;
    std::printf("RESULT ggml-graph %s R=%d threads=%d steps=%d: max rel.err vs official float64 trace %.2e, vs direct C++ step %.2e"
                "  %s   time/step: ggml graph %.3f ms, direct %.3f ms\n",
                c.mimo ? "mamba3-mimo" : "mamba3-siso", c.R, nthreads, T, worst_ref, worst_direct, ok ? "PASS" : "FAIL",
                t_graph * 1e3 / T, t_direct * 1e3 / T);
    ggml_free(ctx);
    return ok ? 0 : 1;
}
