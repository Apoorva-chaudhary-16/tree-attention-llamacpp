// Correctness test: run the C++ decode step (scalar and SIMD builds of the same kernel) for every step
// of a reference trace produced by bonus/mamba3/ref/layer_ref.py (official state-spaces/mamba refs, float64)
// and compare outputs and final states.
//
//   test_step <trace_dir> [--tol 1e-4] [--csv errors.csv]
// Tolerance (stated): for every step t,  max_i |y_t[i] - yref_t[i]| / max_i |yref_t[i]|  <= tol,
// and the same relative max error for every final state tensor.
#include "ssm.h"

struct Result {
    double worst_step = 0, mean_step = 0;
    int worst_t = -1;
    std::map<std::string, double> state_err;
    std::vector<double> per_step;
    double ms_per_step = 0;
};

static double rel_err(const float * a, const double * ref, size_t n) {
    double num = 0, den = 0;
    for (size_t i = 0; i < n; i++) {
        num = std::max(num, std::fabs((double) a[i] - ref[i]));
        den = std::max(den, std::fabs(ref[i]));
    }
    return num / std::max(den, 1e-30);
}

static void fill_mat(Mat & m, const Npy & a) {
    m.rows = (int) a.shape[0];
    m.cols = (int) a.shape[1];
    m.f32 = to_f32(a);
}

template <typename V>
static Result run_m3(const std::string & dir, const std::map<std::string, std::string> & cfg) {
    M3Config c = m3_config(std::stoi(cfg.at("d_model")), std::stoi(cfg.at("d_state")), std::stoi(cfg.at("headdim")),
                           cfg.at("mimo") == "true", std::stoi(cfg.at("R")));
    M3Weights w;
    auto L = [&](const std::string & n) { return load_npy(dir + "/" + n + ".npy"); };
    fill_mat(w.in_proj, L("w_in_proj"));
    fill_mat(w.out_proj, L("w_out_proj"));
    w.dt_bias = to_f32(L("w_dt_bias"));
    w.B_bias = to_f32(L("w_B_bias"));
    w.C_bias = to_f32(L("w_C_bias"));
    w.B_norm_w = to_f32(L("w_B_norm_w"));
    w.C_norm_w = to_f32(L("w_C_norm_w"));
    w.D = to_f32(L("w_D"));
    const int H = c.nheads, P = c.headdim, R = c.R;
    if (c.mimo) {  // trace stores (H, R, P); kernel wants (R, H, P)
        for (auto name : {"w_mimo_x", "w_mimo_z", "w_mimo_o"}) {
            Npy a = L(name);
            std::vector<float> t((size_t) R * H * P);
            for (int h = 0; h < H; h++)
                for (int r = 0; r < R; r++)
                    for (int p = 0; p < P; p++) t[((size_t) r * H + h) * P + p] = (float) a.data[((size_t) h * R + r) * P + p];
            (std::string(name) == "w_mimo_x" ? w.mimo_x : std::string(name) == "w_mimo_z" ? w.mimo_z : w.mimo_o) = t;
        }
    }
    M3State st;
    M3Scratch sc;
    m3_alloc(c, st, sc);
    Npy U = L("u"), Y = L("y_ref");
    const int T = (int) U.shape[0], D = c.d_model;
    std::vector<float> u(D), y(D);
    Result res;
    double t0 = now_s();
    for (int t = 0; t < T; t++) {
        for (int i = 0; i < D; i++) u[i] = (float) U.data[(size_t) t * D + i];
        m3_layer_step<V>(c, w, st, sc, u.data(), y.data(), false);
        const double e = rel_err(y.data(), Y.data.data() + (size_t) t * D, D);
        res.per_step.push_back(e);
        res.mean_step += e / T;
        if (e > res.worst_step) { res.worst_step = e; res.worst_t = t; }
    }
    res.ms_per_step = (now_s() - t0) * 1e3 / T;
    Npy s_ssm = L("state_ssm"), s_k = L("state_k"), s_v = L("state_v"), s_a = L("state_angle");
    res.state_err["ssm"] = rel_err(st.ssm.data(), s_ssm.data.data(), st.ssm.size());
    res.state_err["k (prev rotated B)"] = rel_err(st.k.data(), s_k.data.data(), st.k.size());
    res.state_err["v (prev x)"] = rel_err(st.v.data(), s_v.data.data(), st.v.size());
    double ang = 0;  // reference angles are not wrapped: compare modulo 2*pi
    for (size_t i = 0; i < st.angle.size(); i++) {
        double d = std::fmod(std::fabs((double) st.angle[i] - s_a.data[i]), 2 * M_PI);
        ang = std::max(ang, std::min(d, 2 * M_PI - d));
    }
    res.state_err["angle (abs, mod 2pi)"] = ang;
    return res;
}

template <typename V>
static Result run_m2(const std::string & dir, const std::map<std::string, std::string> & cfg) {
    M2Config c = m2_config(std::stoi(cfg.at("d_model")), std::stoi(cfg.at("d_state")), std::stoi(cfg.at("headdim")));
    M2Weights w;
    auto L = [&](const std::string & n) { return load_npy(dir + "/" + n + ".npy"); };
    fill_mat(w.in_proj, L("w_in_proj"));
    fill_mat(w.out_proj, L("w_out_proj"));
    w.conv_w = to_f32(L("w_conv_w"));
    w.conv_b = to_f32(L("w_conv_b"));
    w.dt_bias = to_f32(L("w_dt_bias"));
    w.D = to_f32(L("w_D"));
    w.norm_w = to_f32(L("w_norm_w"));
    for (double a : L("w_A_log").data) w.A.push_back((float) -std::exp(a));
    M2State st;
    M2Scratch sc;
    m2_alloc(c, st, sc);
    Npy U = L("u"), Y = L("y_ref");
    const int T = (int) U.shape[0], D = c.d_model;
    std::vector<float> u(D), y(D);
    Result res;
    double t0 = now_s();
    for (int t = 0; t < T; t++) {
        for (int i = 0; i < D; i++) u[i] = (float) U.data[(size_t) t * D + i];
        m2_layer_step<V>(c, w, st, sc, u.data(), y.data(), false);
        const double e = rel_err(y.data(), Y.data.data() + (size_t) t * D, D);
        res.per_step.push_back(e);
        res.mean_step += e / T;
        if (e > res.worst_step) { res.worst_step = e; res.worst_t = t; }
    }
    res.ms_per_step = (now_s() - t0) * 1e3 / T;
    res.state_err["ssm"] = rel_err(st.ssm.data(), L("state_ssm").data.data(), st.ssm.size());
    res.state_err["conv"] = rel_err(st.conv.data(), L("state_conv").data.data(), st.conv.size());
    return res;
}

int main(int argc, char ** argv) {
    if (argc < 2) {
        std::fprintf(stderr, "usage: %s <trace_dir> [--tol 1e-4] [--csv file]\n", argv[0]);
        return 2;
    }
    std::string dir = argv[1], csv;
    double tol = 1e-4;
    for (int i = 2; i + 1 < argc; i += 2) {
        if (std::string(argv[i]) == "--tol") tol = std::stod(argv[i + 1]);
        if (std::string(argv[i]) == "--csv") csv = argv[i + 1];
    }
    auto cfg = load_json_flat(dir + "/config.json");
    const bool m3 = cfg.at("kind") == "mamba3";
    std::string label = m3 ? (cfg.at("mimo") == "true" ? "mamba3-mimo R=" + cfg.at("R") : "mamba3-siso") : "mamba2";
    Result rs = m3 ? run_m3<ScalarV>(dir, cfg) : run_m2<ScalarV>(dir, cfg);
    Result rv = m3 ? run_m3<NativeV>(dir, cfg) : run_m2<NativeV>(dir, cfg);
    bool ok = true;
    for (auto * pr : {&rs, &rv}) {
        const char * impl = pr == &rs ? "scalar" : NativeV::name;
        bool pass = pr->worst_step <= tol;
        for (auto & kv : pr->state_err) pass = pass && kv.second <= tol;
        ok = ok && pass;
        std::printf("RESULT %-18s impl=%-7s steps=%zu threads=%d  worst step rel.err=%.2e (t=%d)  mean=%.2e  ",
                    label.c_str(), impl, pr->per_step.size(), num_threads(), pr->worst_step, pr->worst_t, pr->mean_step);
        for (auto & kv : pr->state_err) std::printf("state[%s]=%.2e  ", kv.first.c_str(), kv.second);
        std::printf("tol=%.0e  %s  (%.3f ms/step)\n", tol, pass ? "PASS" : "FAIL", pr->ms_per_step);
    }
    if (!csv.empty()) {
        std::ofstream f(csv);
        f << "step,rel_err_scalar,rel_err_" << NativeV::name << "\n";
        for (size_t t = 0; t < rs.per_step.size(); t++) f << t << "," << rs.per_step[t] << "," << rv.per_step[t] << "\n";
    }
    return ok ? 0 : 1;
}
