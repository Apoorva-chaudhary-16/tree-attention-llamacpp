// Option 3 operator study: time ggml's SSM_SCAN (the operator llama.cpp runs for Mamba-1 AND Mamba-2) alone,
// with the real layer shapes, in decode (1 token) and prefill (one 512-token ubatch), for several thread counts.
// Decode cycles through n_layer independent states inside one graph (= one token of the whole model), so the
// states are DRAM-resident exactly as in a real decode step.
// Also checks our hand-written Mamba-2 core step (kernels/src/ssm.h) against ggml's operator.
//
//   ssm_scan_bench [--threads 1,2,4] [--reps 3] [--csv out.csv]
#include "ssm.h"

#include "ggml-cpu.h"
#include "ggml.h"

struct Shape {
    const char * name;
    int d_state, head_dim, n_head, n_layer;
};
// Mamba-1 runs SSM_SCAN with head_dim = 1 and n_head = d_inner (src/models/mamba-base.cpp).
static const Shape SHAPES[] = {
    {"mamba1-1.4b", 16, 1, 4096, 48},
    {"mamba1-2.8b", 16, 1, 5120, 64},
    {"mamba2-1.3b", 128, 64, 64, 48},
    {"mamba2-2.7b", 128, 64, 80, 64},
};

static std::mt19937 rng(7);
static void rnd(ggml_tensor * t, float lo, float hi) {
    std::uniform_real_distribution<float> d(lo, hi);
    float * p = (float *) t->data;
    for (int64_t i = 0; i < ggml_nelements(t); i++) p[i] = d(rng);
}

struct Graph {
    ggml_context * ctx = nullptr;
    ggml_cgraph * gf = nullptr;
    std::vector<ggml_tensor *> s, x, dt, A, B, C, y;
};

static Graph build(const Shape & sh, int n_tok, int layers) {
    Graph g;
    const size_t per = sizeof(float) * ((size_t) sh.d_state * sh.head_dim * sh.n_head * 2 + (size_t) sh.head_dim * sh.n_head * n_tok * 2
                                        + (size_t) sh.n_head * n_tok + 2 * (size_t) sh.d_state * n_tok + (size_t) sh.d_state * sh.n_head);
    ggml_init_params ip = {per * layers + (size_t) layers * 16 * ggml_tensor_overhead() + ggml_graph_overhead() + (4 << 20), nullptr, false};
    g.ctx = ggml_init(ip);
    g.gf = ggml_new_graph(g.ctx);
    const bool m1 = sh.head_dim == 1;
    ggml_tensor * ids = ggml_new_tensor_1d(g.ctx, GGML_TYPE_I32, 1);
    ((int32_t *) ids->data)[0] = 0;
    for (int l = 0; l < layers; l++) {
        auto s = ggml_new_tensor_4d(g.ctx, GGML_TYPE_F32, sh.d_state, sh.head_dim, sh.n_head, 1);
        auto x = ggml_new_tensor_4d(g.ctx, GGML_TYPE_F32, sh.head_dim, sh.n_head, n_tok, 1);
        auto dt = ggml_new_tensor_3d(g.ctx, GGML_TYPE_F32, sh.n_head, n_tok, 1);
        auto A = m1 ? ggml_new_tensor_2d(g.ctx, GGML_TYPE_F32, sh.d_state, sh.n_head) : ggml_new_tensor_2d(g.ctx, GGML_TYPE_F32, 1, sh.n_head);
        auto B = ggml_new_tensor_4d(g.ctx, GGML_TYPE_F32, sh.d_state, 1, n_tok, 1);
        auto C = ggml_new_tensor_4d(g.ctx, GGML_TYPE_F32, sh.d_state, 1, n_tok, 1);
        rnd(s, -1, 1); rnd(x, -1, 1); rnd(dt, -5, -2); rnd(A, -8, -1); rnd(B, -1, 1); rnd(C, -1, 1);
        auto y = ggml_ssm_scan(g.ctx, s, x, dt, A, B, C, ids, 1);
        ggml_build_forward_expand(g.gf, y);
        g.s.push_back(s); g.x.push_back(x); g.dt.push_back(dt); g.A.push_back(A); g.B.push_back(B); g.C.push_back(C); g.y.push_back(y);
    }
    return g;
}

// our Mamba-2 core step (D = 0, ggml's op has no skip term) vs ggml SSM_SCAN, one decode token
static double crosscheck_mamba2(const Shape & sh) {
    Graph g = build(sh, 1, 1);
    ggml_graph_compute_with_ctx(g.ctx, g.gf, 1);
    M2Config c = m2_config(sh.n_head * sh.head_dim / 2, sh.d_state, sh.head_dim);
    M2Weights w;
    w.D.assign(sh.n_head, 0.0f);
    M2State st;
    M2Scratch sc;
    m2_alloc(c, st, sc);
    std::memcpy(st.ssm.data(), g.s[0]->data, ggml_nbytes(g.s[0]));
    const float * x = (const float *) g.x[0]->data;
    std::copy(x, x + c.d_inner, sc.xbc.begin());
    std::memcpy(sc.xbc.data() + c.d_inner, g.B[0]->data, sizeof(float) * sh.d_state);
    std::memcpy(sc.xbc.data() + c.d_inner + sh.d_state, g.C[0]->data, sizeof(float) * sh.d_state);
    for (int h = 0; h < sh.n_head; h++) {
        sc.dt[h] = softplus_f(((const float *) g.dt[0]->data)[h]);
        sc.dA[h] = std::exp(sc.dt[h] * ((const float *) g.A[0]->data)[h]);
    }
    m2_core_step<NativeV>(c, w, st, sc);
    const float * gy = (const float *) g.y[0]->data;            // y followed by the final state
    const float * gs = gy + (size_t) sh.head_dim * sh.n_head;
    double e = 0, den = 0, es = 0, dens = 0;
    for (int i = 0; i < c.d_inner; i++) { e = std::max(e, (double) std::fabs(gy[i] - sc.y[i])); den = std::max(den, (double) std::fabs(gy[i])); }
    for (size_t i = 0; i < st.ssm.size(); i++) { es = std::max(es, (double) std::fabs(gs[i] - st.ssm[i])); dens = std::max(dens, (double) std::fabs(gs[i])); }
    ggml_free(g.ctx);
    return std::max(e / den, es / dens);
}

int main(int argc, char ** argv) {
    std::vector<int> threads;
    int reps = 3;
    std::string csv = "ssm_scan_bench.csv";
    for (int i = 1; i + 1 < argc; i += 2) {
        std::string k = argv[i], v = argv[i + 1];
        if (k == "--threads") { std::stringstream ss(v); std::string t; while (std::getline(ss, t, ',')) threads.push_back(std::stoi(t)); }
        else if (k == "--reps") reps = std::stoi(v);
        else if (k == "--csv") csv = v;
    }
    if (threads.empty()) threads = {1};
    for (const auto & sh : SHAPES) {
        if (sh.head_dim == 1) continue;
        const double e = crosscheck_mamba2(sh);
        std::printf("CHECK our Mamba-2 core step vs ggml SSM_SCAN (%s, decode): max rel.err %.2e  %s\n", sh.name, e,
                    e < 1e-5 ? "PASS" : "FAIL");
    }
    std::ofstream f(csv);
    f << "shape,phase,n_tokens,layers,threads,rep,us_per_layer_call,ns_per_token_per_layer,ms_per_token_all_layers,state_mib_per_layer\n";
    std::printf("%-12s %-8s %4s %6s %4s %12s %16s\n", "shape", "phase", "thr", "layers", "rep", "us/layer-call", "ns/token/layer");
    for (const auto & sh : SHAPES) {
        const double state_mib = 4.0 * sh.d_state * sh.head_dim * sh.n_head / (1 << 20);
        for (int phase = 0; phase < 2; phase++) {
            const int n_tok = phase == 0 ? 1 : 512;
            const int layers = phase == 0 ? sh.n_layer : 2;
            Graph g = build(sh, n_tok, layers);
            for (int T : threads) {
                ggml_graph_compute_with_ctx(g.ctx, g.gf, T);  // warm-up
                for (int r = 1; r <= reps; r++) {
                    int it = 0;
                    double t0 = now_s(), el = 0;
                    while (el < 0.3 || it < 3) { ggml_graph_compute_with_ctx(g.ctx, g.gf, T); it++; el = now_s() - t0; }
                    const double us_call = el / it / layers * 1e6;
                    const double ns_tok = us_call * 1e3 / n_tok;
                    f << sh.name << "," << (phase ? "prefill" : "decode") << "," << n_tok << "," << layers << "," << T << "," << r << ","
                      << us_call << "," << ns_tok << "," << ns_tok * sh.n_layer / 1e6 << "," << state_mib << "\n";
                    std::printf("%-12s %-8s %4d %6d %4d %12.2f %16.1f\n", sh.name, phase ? "prefill" : "decode", T, layers, r, us_call, ns_tok);
                }
            }
            ggml_free(g.ctx);
        }
    }
    std::printf("# wrote %s\n", csv.c_str());
    return 0;
}
