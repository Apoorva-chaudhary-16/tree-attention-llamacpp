#!/usr/bin/env bash
# Get every model in the config + the fixed perplexity text, and record SHA-256 checksums.
#  * models with hf_repo/hf_file : download the GGUF (Llama-3.2-1B contrast/reference model)
#  * models with hf_src          : download the official checkpoint (state-spaces/*), convert it with the
#                                  PINNED llama.cpp converter to an F16 intermediate, then llama-quantize to the
#                                  quant in the config (Q4_K_M, or Q8_0 for <= 1.5B). The F16 file is only an
#                                  intermediate (deleted afterwards unless KEEP_F16=1); it is never benchmarked.
# Needs: pip install -r ../llama.cpp/requirements/requirements-convert_hf_to_gguf.txt huggingface_hub
#   scripts/03_get_models.sh              # all models
#   scripts/03_get_models.sh m2-1.3b-q4km # one model
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"; cd "$REPO"
CFG="${P1_CONFIG:-config/option3.yaml}"
LLAMA="${LLAMA_CPP_DIR:-$REPO/../llama.cpp}"; BIN="${LLAMA_BIN_DIR:-$LLAMA/build/bin}"
mkdir -p models data models/src
python3 - "$CFG" "${1:-}" > /tmp/p1_models.txt <<'PY'
import sys, yaml
c = yaml.safe_load(open(sys.argv[1])); only = sys.argv[2]
for m in c["models"]:
    if only and m["id"] not in only.split(","): continue
    if m.get("synth"): continue
    print(m["id"], m.get("hf_repo", "-"), m.get("hf_file", "-"), m.get("hf_src", "-"), m.get("quant", "-"), m["file"], m.get("params_b", 0))
PY
dl() { if command -v curl >/dev/null; then curl -fL --retry 3 -C - -o "$2" "$1"; else wget -c -O "$2" "$1"; fi; }
while read -r id repo file src quant dest params; do
  [ -s "$dest" ] && { echo "== $id: present ($dest)"; continue; }
  case "$quant" in Q8_0) python3 -c "import sys; sys.exit(0 if float('$params') <= 1.5 else 1)" || { echo "!! Q8_0 only for <= 1.5B ($id)"; exit 1; } ;; esac
  case "$quant" in *F16*|*f16*) echo "!! course rule: no F16 models ($id)"; exit 1 ;; esac
  if [ "$repo" != "-" ]; then
    echo "== $id: downloading GGUF $repo/$file"
    if command -v hf >/dev/null; then hf download "$repo" "$file" --local-dir models; [ "models/$file" = "$dest" ] || mv "models/$file" "$dest"
    else dl "https://huggingface.co/$repo/resolve/main/$file" "$dest"; fi
    continue
  fi
  name="$(basename "$src")"; f16="models/src/${name}-f16.gguf"
  if [ ! -s "$f16" ]; then
    echo "== $id: downloading checkpoint $src"
    command -v hf >/dev/null || { echo "!! needs the Hugging Face CLI: pip install huggingface_hub"; exit 1; }
    hf download "$src" --local-dir "models/src/$name" --include "*.json" "*.bin" "*.safetensors" "*.txt" "*.model"
    echo "== $id: converting with the pinned converter -> $f16"
    python3 "$LLAMA/convert_hf_to_gguf.py" "models/src/$name" --outtype f16 --outfile "$f16"
  fi
  echo "== $id: llama-quantize $quant"
  "$BIN/llama-quantize" "$f16" "$dest" "$quant" > "models/src/${id}.quantize.log" 2>&1
  grep -E "model size|quant size" "models/src/${id}.quantize.log" | tail -2 || true
done < /tmp/p1_models.txt
if [ "${KEEP_F16:-0}" != "1" ]; then
  python3 - "$CFG" <<'PY'
import sys, yaml, pathlib
c = yaml.safe_load(open(sys.argv[1]))
srcs = {m.get("hf_src") for m in c["models"] if m.get("hf_src")}
done = all(pathlib.Path(m["file"]).exists() for m in c["models"] if m.get("hf_src"))
if done:
    for s in srcs:
        p = pathlib.Path("models/src") / (s.split("/")[-1] + "-f16.gguf")
        if p.exists(): p.unlink(); print("removed intermediate", p)
PY
fi
if [ ! -s data/wiki.test.raw ]; then   # fixed text sample (same URL as llama.cpp's scripts/get-wikitext-2.sh)
  dl "https://huggingface.co/datasets/ggml-org/ci/resolve/main/wikitext-2-raw-v1.zip" data/wikitext-2-raw-v1.zip
  (cd data && unzip -o -q wikitext-2-raw-v1.zip && cp wikitext-2-raw/wiki.test.raw . && rm -rf wikitext-2-raw)
fi
MACHINE="$(python3 -c 'import sys; sys.path.insert(0,"scripts/lib"); import common as C; print(C.load_config()["_machine"])')"
mkdir -p "results/$MACHINE"
SUM="sha256sum"; command -v sha256sum >/dev/null || SUM="shasum -a 256"
$SUM models/*.gguf data/wiki.test.raw | tee "results/$MACHINE/checksums.sha256"
