#!/usr/bin/env python3
"""Predict decode speed BEFORE measuring it (course step 4):  tokens/s = bandwidth / bytes per decoded token.

Bytes per decoded token, from the GGUF file itself:
  weights  : every weight matrix is streamed once per token (exact quantized tensor sizes). token_embd is a
             1-row lookup unless the model ties it to the output head (no output.weight) -> whole matrix read.
  Mamba    : + recurrent-state traffic, CONSTANT in context. State per layer (float32):
               Mamba-1: ssm d_inner x d_state, conv (d_conv-1) x d_inner
               Mamba-2: ssm d_inner x d_state, conv (d_conv-1) x (d_inner + 2 x groups x d_state)
             ideal traffic = 2 x state (read + write). llama.cpp's graph (src/models/mamba-base.cpp) reads the
             state into SSM_SCAN, writes the new state into the op output, then CPYs it back to the cache:
             ~4 x state. Both are reported; which one the measurement matches is part of the gap analysis.
  Llama    : + KV cache re-read every step: ctx x n_layer x n_head_kv x (k_dim + v_dim) x bytes(type).
Bandwidth = STREAM Triad / Copy and read-only bandwidth (02_stream.py) at the same thread count.

Writes results/<machine>/predictions.csv and bytes_per_token.md (stamped with time and git commit:
commit them before running the sweep, to show the prediction came first).
"""
import argparse
import csv
import re
import statistics as st
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import common as C  # noqa: E402

KV_BYTES = {"f32": 4.0, "f16": 2.0, "bf16": 2.0, "q8_0": 34 / 32, "q4_0": 18 / 32}


def gguf_reader(cfg):
    sys.path.insert(0, str(cfg["_llama_dir"] / "gguf-py"))
    try:
        from gguf import GGUFReader
    except ImportError:
        sys.exit("gguf-py not importable: run scripts/00_build_llamacpp.sh (clones llama.cpp) and pip install numpy")
    return GGUFReader


def fv(reader, key, default=None):
    f = reader.fields.get(key)
    if f is None:
        return default
    try:
        return f.contents()
    except Exception:
        return default


def group_of(name: str) -> str:
    if name.startswith("token_embd"):
        return "token_embd"
    if name.startswith("output."):
        return "output"
    n = re.sub(r"^blk\.\d+\.", "", name).replace(".weight", "").replace(".bias", " (bias)")
    return "norms" if "norm" in n else n


def model_info(cfg, path: Path) -> dict:
    r = gguf_reader(cfg)(str(path))
    arch = fv(r, "general.architecture")
    g = lambda k, d=None: fv(r, f"{arch}.{k}", d)
    n_layer = int(g("block_count"))
    names = {t.name for t in r.tensors}
    tied = "output.weight" not in names
    n_expert, n_used = int(g("expert_count", 0) or 0), int(g("expert_used_count", 0) or 0)
    groups = defaultdict(lambda: {"bytes": 0.0, "params": 0.0, "types": set()})
    W = matmul_params = 0.0
    for t in r.tensors:
        nb, ne, frac = int(t.n_bytes), int(t.n_elements), 1.0
        if t.name.startswith("token_embd") and not tied:
            frac = 1.0 / int(t.shape[-1])
        if "_exps" in t.name and n_expert and n_used:
            frac = n_used / n_expert
        gr = groups[group_of(t.name)]
        gr["bytes"] += nb * frac
        gr["params"] += ne * frac
        gr["types"].add(t.tensor_type.name)
        W += nb * frac
        if len(t.shape) >= 2 and int(t.shape[0]) > 4 and int(t.shape[1]) > 1 and not (t.name.startswith("token_embd") and not tied):
            matmul_params += ne * frac
    info = {"arch": arch, "n_layer": n_layer, "tied": tied, "groups": dict(groups), "W": W,
            "matmul_params": matmul_params, "file_bytes": path.stat().st_size,
            "state_bytes": 0.0, "kv_heads": [], "k_dim": 0, "v_dim": 0, "scan_flops": 0.0, "scan_exps": 0.0}
    if arch in ("mamba", "mamba2"):
        N, di, dc = int(g("ssm.state_size")), int(g("ssm.inner_size")), int(g("ssm.conv_kernel"))
        G = int(g("ssm.group_count", 1) or 1)
        conv_ch = di if arch == "mamba" else di + 2 * G * N
        ssm, conv = 4.0 * di * N, 4.0 * (dc - 1) * conv_ch
        info.update(d_state=N, d_inner=di, d_conv=dc, ssm_layer=ssm, conv_layer=conv,
                    state_bytes=n_layer * (ssm + conv), scan_flops=n_layer * 5.0 * di * N,
                    scan_exps=n_layer * (di * N if arch == "mamba" else int(g("ssm.time_step_rank", 1))))
    else:
        n_head = int(g("attention.head_count", 0) or 0)
        n_embd = int(g("embedding_length"))
        hkv = g("attention.head_count_kv", n_head)
        hkv = [int(x) for x in hkv] if hasattr(hkv, "__len__") else [int(hkv)] * n_layer
        hd = n_embd // n_head if n_head else 0
        info.update(n_head=n_head, kv_heads=hkv, k_dim=int(g("attention.key_length", hd)), v_dim=int(g("attention.value_length", hd)))
    return info


def kv_per_token(info, kv_type="f16") -> float:
    return sum(h * (info["k_dim"] + info["v_dim"]) * KV_BYTES[kv_type] for h in info["kv_heads"])


def bandwidth_table(cfg) -> dict:
    d = C.machine_dir(cfg)
    srows = [r for r in C.read_csv(d / "stream.csv") if r.get("validates") == "True"]
    brows = C.read_csv(d / "bw_read.csv")
    out = {}
    for t in sorted({int(r["threads"]) for r in srows}):
        s = [r for r in srows if int(r["threads"]) == t]
        b = [r for r in brows if int(r["threads"]) == t]
        out[t] = {"triad": st.mean(float(r["triad_gbs"]) for r in s), "copy": st.mean(float(r["copy_gbs"]) for r in s),
                  "read": st.mean(float(r["best_gbs"]) for r in b) if b else float("nan"), "n": len(s)}
    return out


def points(cfg, m) -> list[int]:
    pts = set()
    for p in list(cfg["sweep"]["decode_ctx"]) + list(cfg["sweep"].get("decode_extra", [])):
        v = m["max_ctx"] if p == "max" else int(p)
        if v <= m["max_ctx"]:
            pts.add(v)
    return sorted(pts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threads", type=int)
    args = ap.parse_args()
    cfg = C.load_config()
    T = args.threads or C.cpu_topology(cfg).perf_cores
    G = int(cfg["sweep"]["n_gen"])
    out = C.machine_dir(cfg)
    bw_all = bandwidth_table(cfg)
    if T not in bw_all:
        sys.exit(f"no validated STREAM result at {T} threads: run scripts/02_stream.py first")
    bw = bw_all[T]
    stamp, commit = C.now_iso(), C.git_rev(C.REPO)[:10]
    md = [f"# Bytes per decoded token (predicted {stamp}, repo commit {commit})\n",
          f"Bandwidth at {T} threads, mean of {bw['n']} STREAM runs: Triad **{bw['triad']:.1f} GB/s**, Copy {bw['copy']:.1f} GB/s, "
          f"read-only {bw['read']:.1f} GB/s.\n"]
    rows = []
    for m in cfg["models"]:
        if not m["_path"].exists():
            C.log(f"skip {m['id']}: {m['_path']} missing")
            continue
        i = model_info(cfg, m["_path"])
        W = i["W"]
        rec = i["arch"] in ("mamba", "mamba2")
        kvt = 0.0 if rec else kv_per_token(i)
        md.append(f"\n## {m['label']}  (`{m['_path'].name}`, arch `{i['arch']}`, {i['n_layer']} layers, "
                  f"tied embeddings: {i['tied']})\n")
        md.append("| tensor group | types | params (M) | MB read per token | share of weights |\n|---|---|---:|---:|---:|")
        for gname, v in sorted(i["groups"].items(), key=lambda kv: -kv[1]["bytes"]):
            if v["bytes"] / W >= 0.001:
                md.append(f"| {gname} | {','.join(sorted(v['types']))} | {v['params'] / 1e6:.1f} | {v['bytes'] / 1e6:.1f} | {100 * v['bytes'] / W:.1f}% |")
        md.append(f"| **all weights** | | | **{W / 1e6:.1f}** | |\n")
        if rec:
            md.append(f"Recurrent state per sequence: **{i['state_bytes'] / 2**20:.1f} MiB** "
                      f"(ssm {i['ssm_layer'] / 2**10:.0f} KiB + conv {i['conv_layer'] / 2**10:.0f} KiB per layer), constant in context. "
                      f"Traffic per token: ideal {2 * i['state_bytes'] / 1e6:.1f} MB, llama.cpp graph ~{4 * i['state_bytes'] / 1e6:.1f} MB. "
                      f"Scan work per token: {i['scan_flops'] / 1e6:.0f} MFLOP and {i['scan_exps'] / 1e3:.0f}k exp() calls.\n")
        else:
            md.append(f"KV cache (f16): {kvt / 1024:.0f} KiB per context token; equals the weight bytes at "
                      f"{W / kvt:,.0f} tokens.\n")
        md.append("| decode context | state or KV MB/token | total MB/token (ideal) | pred. t/s Triad | Triad, llama.cpp traffic | read-only BW |")
        md.append("|---:|---:|---:|---:|---:|---:|")
        for L in points(cfg, m):
            Lavg = L - G / 2
            extra = 2 * i["state_bytes"] if rec else kvt * Lavg
            extra_lc = 4 * i["state_bytes"] if rec else kvt * Lavg
            tot, tot_lc = W + extra, W + extra_lc
            flops = 2 * i["matmul_params"] + (i["scan_flops"] if rec else 4 * len(i["kv_heads"]) * i.get("n_head", 0) * i["k_dim"] * Lavg)
            r = {"model": m["id"], "label": m["label"], "family": i["arch"], "threads": T, "ctx": L, "ctx_avg": Lavg,
                 "weight_bytes": W, "state_bytes": i["state_bytes"], "kv_bytes_per_ctx_token": kvt, "extra_bytes": extra,
                 "total_bytes": tot, "total_bytes_llamacpp": tot_lc, "flops": flops, "intensity_flop_per_byte": flops / tot,
                 "bw_triad": bw["triad"], "bw_copy": bw["copy"], "bw_read": bw["read"],
                 "pred_tps_triad": bw["triad"] * 1e9 / tot, "pred_tps_triad_llamacpp": bw["triad"] * 1e9 / tot_lc,
                 "pred_tps_copy": bw["copy"] * 1e9 / tot, "pred_tps_read": bw["read"] * 1e9 / tot,
                 "predicted_at": stamp, "repo_commit": commit, "scaling": 0}
            rows.append(r)
            md.append(f"| {L:,} | {extra / 1e6:.1f} | {tot / 1e6:.1f} | {r['pred_tps_triad']:.1f} | "
                      f"{r['pred_tps_triad_llamacpp']:.1f} | {r['pred_tps_read']:.1f} |")
        for t, b in bw_all.items():  # thread scaling: tg from an empty cache/state
            extra = 2 * i["state_bytes"] if rec else kvt * G / 2
            tot = W + extra
            tot_lc = W + (4 * i["state_bytes"] if rec else extra)
            rows.append({"model": m["id"], "label": m["label"], "family": i["arch"], "threads": t, "ctx": G, "ctx_avg": G / 2,
                         "weight_bytes": W, "state_bytes": i["state_bytes"], "kv_bytes_per_ctx_token": kvt, "extra_bytes": extra,
                         "total_bytes": tot, "total_bytes_llamacpp": tot_lc, "flops": 2 * i["matmul_params"],
                         "intensity_flop_per_byte": 2 * i["matmul_params"] / tot, "bw_triad": b["triad"],
                         "bw_copy": b["copy"], "bw_read": b["read"], "pred_tps_triad": b["triad"] * 1e9 / tot,
                         "pred_tps_triad_llamacpp": b["triad"] * 1e9 / tot_lc, "pred_tps_copy": b["copy"] * 1e9 / tot,
                         "pred_tps_read": b["read"] * 1e9 / tot, "predicted_at": stamp, "repo_commit": commit, "scaling": 1})
    if not rows:
        sys.exit("no model files found: run scripts/03_get_models.sh")
    with open(out / "predictions.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    (out / "bytes_per_token.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    C.log(f"wrote {out / 'predictions.csv'} and bytes_per_token.md -> git commit them BEFORE the sweep")


if __name__ == "__main__":
    main()
