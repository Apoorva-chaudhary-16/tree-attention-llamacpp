#!/usr/bin/env python3
"""Collect every number the brief asks for into results/<machine>/SUMMARY.md (tables for the report, and a
'numbers for the slides' block at the end so no required number goes missing from the talk)."""
import json
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import common as C  # noqa: E402


def rd(p: Path):
    return pd.read_csv(p) if p.exists() and p.stat().st_size > 0 else pd.DataFrame()


def fmt(mu, sd, n):
    return f"{mu:.2f} ± {sd:.2f} (n={n})"


def main():
    cfg = C.load_config()
    d = C.machine_dir(cfg)
    T = C.cpu_topology(cfg).perf_cores
    lab = {m["id"]: m["label"] for m in cfg["models"]}
    md = [f"# Results summary: {cfg['title']} ({cfg['_machine']})\n",
          f"Generated {C.now_iso()} from the raw CSVs in `results/{cfg['_machine']}/`. Threads = {T} performance cores "
          f"unless stated. Every value: mean ± standard deviation over {cfg['sweep']['reps']} fresh-process runs.\n"]
    if cfg.get("synthetic"):
        md.append("> **SMOKE TEST on random-weight synthetic models: these numbers are not results.**\n")
    slides = []
    # ------------------------------------------------------------- hardware + bandwidth
    hw = d / "hardware.md"
    md += ["## 1. Hardware and setup\n", hw.read_text() if hw.exists() else "_run scripts/01_hwinfo.py_\n"]
    bi = d / "build_info.txt"
    if bi.exists():
        md.append("```\n" + "\n".join(bi.read_text().splitlines()[:6]) + "\n```\n")
    s = rd(d / "stream.csv")
    b = rd(d / "bw_read.csv")
    if not s.empty:
        g = s.groupby("threads").agg(triad=("triad_gbs", "mean"), sd=("triad_gbs", "std"), copy=("copy_gbs", "mean"),
                                     n=("triad_gbs", "count")).reset_index()
        if not b.empty:
            g = g.merge(b.groupby("threads")["best_gbs"].mean().rename("read").reset_index(), on="threads", how="left")
        md.append("**Memory bandwidth (STREAM; read-only kernel for comparison), GB/s**\n\n| threads | Triad | Copy | read-only |\n|---:|---:|---:|---:|")
        md += [f"| {r.threads} | {r.triad:.1f} ± {0 if pd.isna(r.sd) else r.sd:.1f} | {r.copy:.1f} | {getattr(r, 'read', float('nan')):.1f} |" for r in g.itertuples()]
        top = g[g["threads"] == T]
        if len(top):
            slides.append(f"STREAM Triad at {T} threads: {top['triad'].iloc[0]:.1f} GB/s (read-only {top.get('read', pd.Series([float('nan')])).iloc[0]:.1f} GB/s)")
        md.append("")
    # ------------------------------------------------------------- correctness
    corr = d / "correctness" / "correctness.md"
    md += ["## 2. Correctness\n", corr.read_text().split("\n", 1)[1] if corr.exists() else "_run scripts/04_correctness.py_\n"]
    ppl = rd(d / "correctness" / "perplexity.csv")
    for r in ppl.itertuples():
        slides.append(f"PPL {r.label}: {r.ppl:.2f} ± {r.ppl_err:.2f}")
    # ------------------------------------------------------------- sweeps
    sw = rd(d / "raw" / "sweep.csv")
    pred = rd(d / "predictions.csv")
    if not sw.empty:
        bad = sw[~sw["status"].isin(["ok"]) & ~sw["status"].str.startswith("skipped")]
        ok = sw[sw["status"] == "ok"].copy()
        agg = lambda df, k: df.groupby(k).agg(mu=("tps", "mean"), sd=("tps", "std"), n=("tps", "count"),
                                             rss=("peak_rss_gb", "mean"), rss_max=("peak_rss_gb", "max")).reset_index().fillna(0)
        pre = agg(ok[ok["sweep"] == "prefill"], ["model", "n_prompt"])
        md.append("## 3. Prefill speed (tokens/s) and peak RSS (GB)\n\n| model | prompt | tokens/s | peak RSS |\n|---|---:|---:|---:|")
        md += [f"| {lab.get(r.model, r.model)} | {r.n_prompt:,} | {fmt(r.mu, r.sd, r.n)} | {r.rss_max:.2f} |" for r in pre.itertuples()]
        dec = agg(ok[ok["sweep"] == "decode"], ["model", "ctx"])
        if not pred.empty:
            dec = dec.merge(pred[pred["scaling"] == 0][["model", "ctx", "pred_tps_triad", "pred_tps_triad_llamacpp", "pred_tps_read",
                                                         "total_bytes"]], on=["model", "ctx"], how="left")
        md.append("\n## 4. Decode speed (tokens/s), prediction and achieved bandwidth\n\n"
                  "| model | context | tokens/s | peak RSS | predicted (Triad) | measured / predicted | achieved GB/s |\n|---|---:|---:|---:|---:|---:|---:|")
        for r in dec.itertuples():
            p = getattr(r, "pred_tps_triad", float("nan"))
            gbs = r.mu * getattr(r, "total_bytes", float("nan")) / 1e9
            md.append(f"| {lab.get(r.model, r.model)} | {r.ctx:,} | {fmt(r.mu, r.sd, r.n)} | {r.rss_max:.2f} | {p:.1f} | "
                      f"{100 * r.mu / p:.0f}% | {gbs:.1f} |")
        for mid, g in dec.groupby("model"):
            if len(g) >= 2:
                lo, hi = g.iloc[0], g.iloc[-1]
                slides.append(f"Decode {lab.get(mid, mid)}: {lo.mu:.1f} t/s @ {lo.ctx:,} -> {hi.mu:.1f} t/s @ {hi.ctx:,} "
                              f"({100 * (hi.mu / lo.mu - 1):+.0f}%), measured/predicted {100 * lo.mu / getattr(lo, 'pred_tps_triad', float('nan')):.0f}%")
        for mid, g in pre.groupby("model"):
            slides.append(f"Prefill {lab.get(mid, mid)}: " + ", ".join(f"pp{r.n_prompt}={r.mu:.0f}" for r in g.itertuples()) + " t/s")
        sc = ok[ok["sweep"] == "scaling"]
        if not sc.empty:
            md.append("\n## 5. Thread scaling (tokens/s)\n\n| model | test | " + " | ".join(f"t={t}" for t in sorted(sc["threads"].unique())) + " |")
            md.append("|---|---|" + "---:|" * sc["threads"].nunique())
            for (mid, isp), g in sc.groupby(["model", sc["n_prompt"] > 0]):
                a = g.groupby("threads")["tps"].mean()
                md.append(f"| {lab.get(mid, mid)} | {'pp512' if isp else 'tg'} | " + " | ".join(f"{v:.1f}" for v in a.values) + " |")
                slides.append(f"Thread scaling {lab.get(mid, mid)} {'pp512' if isp else 'tg'}: x{a.iloc[-1] / a.iloc[0]:.2f} from 1 to {a.index[-1]} threads")
        md.append(f"\nRuns flagged and rerun or excluded (swap / memory pressure / budget / errors): **{len(bad)}**"
                  + ("" if bad.empty else " -> " + ", ".join(f"{r.model} {r.sweep} p{r.n_prompt} d{r.depth} rep{r.rep}: {r.status}" for r in bad.itertuples())) + "\n")
    # ------------------------------------------------------------- profile, scan op, experiment, bonus, reference
    for title, p in (("6. Per-operator breakdown (top-3 per phase)", d / "profile" / "summary.md"),
                     ("7. Bytes per token (prediction, written before the sweep)", d / "bytes_per_token.md"),
                     ("9. Own experiment", d / "experiment.md")):
        md += [f"## {title}\n", p.read_text().split("\n", 1)[1] if p.exists() else f"_missing: {p.name}_\n"]
    sc = rd(d / "ssm_scan_bench.csv")
    if not sc.empty:
        g = sc.groupby(["shape", "phase", "threads"])["ns_per_token_per_layer"].agg(["mean", "std"]).reset_index()
        md.append("## 8. SSM_SCAN operator alone (kernels/ssm_scan_bench), µs per token per layer\n\n| shape | phase | threads | µs |\n|---|---|---:|---:|")
        md += [f"| {r.shape} | {r.phase} | {r.threads} | {r.mean / 1e3:.1f} ± {0 if pd.isna(r.std) else r.std / 1e3:.1f} |" for r in g.itertuples()]
        md.append("")
    ans = C.REPO / "bonus" / "mamba3" / "results" / cfg["_machine"] / "ANSWER.md"
    md += ["## 10. Bonus: Mamba-3 decode step\n", ans.read_text() if ans.exists() else "_run bonus/mamba3/run_bonus.sh_\n"]
    refs = sorted(C.RESULTS.glob("rudra-*/reference/reference.md"))
    own = d / "reference" / "reference.md"
    md += ["## 11. Shared reference test (PARAM Rudra; same fixed test on this laptop)\n",
           refs[-1].read_text() if refs else "_No PARAM Rudra run yet (attempts: results/rudra-attempts.md)._\n",
           own.read_text() if own.exists() else "_laptop run: make reference_\n"]
    if (C.RESULTS / "COMPARE.md").exists():
        md.append("Cross-machine comparison (both laptops, Rudra): see `results/COMPARE.md` and `plots/compare/`.\n")
    md += ["## Numbers for the slides\n"] + [f"- {x}" for x in slides] + [""]
    (d / "SUMMARY.md").write_text("\n".join(md))
    print(f"wrote {d / 'SUMMARY.md'} ({len(slides)} slide numbers)")


if __name__ == "__main__":
    main()
