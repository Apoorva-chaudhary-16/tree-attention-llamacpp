#!/usr/bin/env python3
"""Per-operator time breakdown (course step 6) for prefill and decode, at several context lengths.

Method 1 (all platforms): the opprof patch in ggml-cpu (patches/0001-ggml-cpu-opprof.patch).
  Thread 0 timestamps every graph node from its start to the end of the barrier after it, so the
  numbers are wall-clock time per operator *including* waiting for the slowest thread. Graphs with
  one token are counted as decode, larger ones as prefill (so the untimed depth prefill of a decode
  run lands in the prefill bucket and does not pollute the decode profile).
Method 2 (Linux / WSL2 with perf): sampling profile of the same runs, by function symbol; shows
  what the kernels spend time in (dot-product kernels, activation quantization, barrier spinning).
  macOS: use Instruments (docs/PLATFORMS.md). Windows: VTune or AMD uProf.

  python3 scripts/07_profile.py            # opprof for all targets in config.profile
  python3 scripts/07_profile.py --perf     # also run perf (Linux)
  python3 scripts/07_profile.py --summarize-only
"""
import argparse
import csv
import re
import shutil
import statistics as st
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import bench as B  # noqa: E402
import common as C  # noqa: E402

# (category, op regex, node-name regex). First match wins. Names come from llama.cpp's graph builder.
CATEGORIES = [
    ("SSM scan",                      r"^SSM_SCAN$", r".*"),
    ("SSM conv (+concat)",            r"^(SSM_CONV|CONCAT)$", r".*"),
    ("state / KV-cache copies",       r"^(CPY|SET_ROWS|DUP)$", r".*"),
    ("output head (lm_head)",         r"^MUL_MAT$", r"^(w:output|w:token_embd|result_output)"),
    ("embedding lookup",              r"^GET_ROWS$", r"^(w:token_embd|inp_embd)"),
    ("SSM projections (in/out/x/dt)", r"^MUL_MAT$", r"^w:ssm_"),
    ("FFN matmuls",                   r"^MUL_MAT(_ID)?$", r"^(w:ffn_|ffn_)"),
    ("attention projections",         r"^MUL_MAT$", r"^(w:attn_|Qcur|Kcur|Vcur)"),
    ("attention core",                r"^(FLASH_ATTN_EXT|SOFT_MAX)$", r".*"),
    ("attention core",                r"^MUL_MAT$", r"^(kq|kqv)$"),
    ("norms",                         r"^(RMS_NORM|NORM|GROUP_NORM|L2_NORM)", r".*"),
    ("RoPE",                          r"^ROPE", r".*"),
    ("activations / gating",          r"^(SILU|SWIGLU|GEGLU|GELU|GLU|SIGMOID|SOFTPLUS|EXP)", r".*"),
    ("other matmuls",                 r"^MUL_MAT(_ID)?$", r".*"),
    ("elementwise / misc",            r".*", r".*"),
]

def categorize(op: str, name: str) -> str:
    for cat, op_re, name_re in CATEGORIES:
        if re.search(op_re, op) and re.search(name_re, name):
            return cat
    return "elementwise / misc"


def load_opprof(path: Path) -> tuple[list[dict], dict]:
    rows, graphs = [], {}
    for r in C.read_csv(path):
        if r["op"] == "__GRAPH__":
            graphs[r["phase"]] = {"graphs": int(r["name"].split("=")[1]), "tokens": int(r["count"]),
                                  "total_us": float(r["total_us"])}
        elif r["op"] != "__OVERFLOW__":
            r["count"], r["total_us"] = int(r["count"]), float(r["total_us"])
            rows.append(r)
    return rows, graphs


def summarize_file(path: Path, phase: str) -> dict | None:
    rows, graphs = load_opprof(path)
    rows = [r for r in rows if r["phase"] == phase]
    if not rows or phase not in graphs:
        return None
    tot = sum(r["total_us"] for r in rows)
    by_op, by_cat, by_mm = defaultdict(float), defaultdict(float), defaultdict(float)
    for r in rows:
        op = r["op"] + ("+fused" if r["fused"] not in ("0", 0) else "")
        by_op[op] += r["total_us"]
        by_cat[categorize(r["op"], r["name"])] += r["total_us"]
        if r["op"].startswith("MUL_MAT"):
            by_mm[r["src0_type"]] += r["total_us"]
    g = graphs[phase]
    return {"total_us": tot, "graph_us": g["total_us"], "tokens": g["tokens"], "graphs": g["graphs"],
            "us_per_token": tot / max(g["tokens"], 1), "by_op": dict(by_op), "by_cat": dict(by_cat),
            "by_matmul_type": dict(by_mm)}


def profile_targets(cfg):
    topo = C.cpu_topology(cfg)
    P = topo.perf_cores
    pr = cfg["profile"]
    G = int(cfg["sweep"]["n_gen"])
    for mid in pr["models"]:
        m = C.model_by_id(cfg, mid)
        if not m["_path"].exists():
            continue
        for p in pr["prefill"]:
            v = m["max_ctx"] if p == "max" else int(p)
            if v <= m["max_ctx"]:
                yield "prefill", B.Spec("profile", m, v, 0, 0, P)
        for L in pr["decode_ctx"]:
            v = m["max_ctx"] if L == "max" else int(L)
            if v <= m["max_ctx"]:
                yield "decode", B.Spec("profile", m, 0, G, max(v - G, 0), P)


def run_opprof(cfg, force=False):
    pdir = C.machine_dir(cfg, "profile")
    raw = C.machine_dir(cfg, "raw") / "profile_runs.csv"
    logs = C.machine_dir(cfg, "logs")
    for phase, s in profile_targets(cfg):
        out = pdir / f"opprof_{s.model['id']}_p{s.n_prompt}_n{s.n_gen}_d{s.depth}.csv"
        if out.exists() and not force:
            C.log(f"have {out.name}")
            continue
        s.env = {"GGML_OPPROF": str(out)}
        row = B.run_one(cfg, s, 1, raw, logs)
        C.log(f"profiled {s.name():40s} {row.get('tps')} t/s -> {out.name}")


def overhead_check(cfg) -> list[dict]:
    """Profiled-run speed vs the median of the normal sweep runs at the same point (instrument check)."""
    sweep = [r for r in C.read_csv(C.machine_dir(cfg, "raw") / "sweep.csv") if r["status"] == "ok"]
    prof = [r for r in C.read_csv(C.machine_dir(cfg, "raw") / "profile_runs.csv") if r["status"] == "ok"]
    out = []
    for p in prof:
        same = [float(r["tps"]) for r in sweep if r["model"] == p["model"] and r["n_prompt"] == p["n_prompt"]
                and r["n_gen"] == p["n_gen"] and r["depth"] == p["depth"] and r["threads"] == p["threads"]]
        if same:
            base = st.median(same)
            out.append({"model": p["model"], "n_prompt": p["n_prompt"], "n_gen": p["n_gen"], "depth": p["depth"],
                        "tps_profiled": float(p["tps"]), "tps_sweep_median": base,
                        "overhead_pct": 100 * (base - float(p["tps"])) / base})
    return out


def summarize(cfg):
    pdir = C.machine_dir(cfg, "profile")
    rows, md = [], ["# Per-operator time breakdown (opprof)\n",
                    "Share of operator wall time; decode profiles exclude the untimed depth prefill.\n"]
    for phase, s in profile_targets(cfg):
        f = pdir / f"opprof_{s.model['id']}_p{s.n_prompt}_n{s.n_gen}_d{s.depth}.csv"
        if not f.exists():
            continue
        sm = summarize_file(f, phase)
        if not sm:
            continue
        point = f"pp{s.n_prompt}" if phase == "prefill" else f"ctx {s.depth + s.n_gen}"
        for kind in ("by_op", "by_cat", "by_matmul_type"):
            for k, v in sm[kind].items():
                rows.append({"model": s.model["id"], "label": s.model["label"], "phase": phase, "point": point,
                             "n_prompt": s.n_prompt, "ctx": s.depth + s.n_gen, "kind": kind, "key": k,
                             "us": round(v, 1), "share": round(v / sm["total_us"], 5),
                             "us_per_token": round(v / max(sm["tokens"], 1), 2), "tokens": sm["tokens"],
                             "graph_us": round(sm["graph_us"], 1), "ops_us": round(sm["total_us"], 1)})
        top = sorted(sm["by_op"].items(), key=lambda kv: -kv[1])[:3]
        cats = sorted(sm["by_cat"].items(), key=lambda kv: -kv[1])
        md.append(f"## {s.model['label']} - {phase} {point}  ({sm['tokens']} tokens, "
                  f"{sm['us_per_token'] / 1e3:.2f} ms/token in ops; ops cover {100 * sm['total_us'] / sm['graph_us']:.1f}% "
                  f"of graph time)\n")
        md.append("Top-3 operators: " + "; ".join(f"**{k}** {100 * v / sm['total_us']:.1f}%" for k, v in top) + "\n")
        md.append("| category | share | ms / token |\n|---|---:|---:|")
        md += [f"| {k} | {100 * v / sm['total_us']:.1f}% | {v / max(sm['tokens'], 1) / 1e3:.3f} |" for k, v in cats]
        mm = sm["by_matmul_type"]
        if mm:
            md.append("\nMUL_MAT time by src0 type: " + ", ".join(
                f"{k} {100 * v / sm['total_us']:.1f}%" for k, v in sorted(mm.items(), key=lambda kv: -kv[1])) + "\n")
    if not rows:
        C.log("no opprof files yet: run without --summarize-only")
        return
    with open(pdir / "summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    ov = overhead_check(cfg)
    if ov:
        md.append("\n## Instrument check: profiled run vs normal sweep runs (same point)\n")
        md.append("| model | point | t/s profiled | t/s sweep (median) | overhead |\n|---|---|---:|---:|---:|")
        for o in ov:
            pt = f"pp{o['n_prompt']}" if int(o["n_prompt"]) else f"ctx {int(o['depth']) + int(o['n_gen'])}"
            md.append(f"| {o['model']} | {pt} | {o['tps_profiled']:.2f} | {o['tps_sweep_median']:.2f} | "
                      f"{o['overhead_pct']:+.1f}% |")
    (pdir / "summary.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    C.log(f"wrote {pdir / 'summary.csv'} and summary.md")


# ----------------------------------------------------------------------------- perf (Linux)
PERF_GROUPS = [
    ("quantized dot-product kernels", r"vec_dot_q|gemv_q|gemm_q|ggml_gemv|ggml_gemm|tinyBLAS|sgemm|vec_dot_iq"),
    ("activation quantization", r"quantize_row_q8|quantize_mat_q8|from_float"),
    ("attention (flash / f16 dot)", r"flash_attn|vec_dot_f16|vec_mad_f16|fp16_to_fp32|softmax|soft_max"),
    ("thread sync (barrier / spin)", r"ggml_barrier|sched_yield|ggml_graph_compute_thread|omp_|gomp|__kmp|futex"),
    ("norm / rope / elementwise", r"rms_norm|norm_f32|rope|vec_swiglu|silu|vec_add|vec_mul|binary_op|add_f32|mul_f32"),
    ("memory copy", r"memcpy|memmove|memset|cpy|set_rows|get_rows"),
    ("kernel / runtime", r"\[k\]|page_fault|clear_page|do_syscall|entry_SYSCALL"),
]


def run_perf(cfg):
    perf = shutil.which("perf")
    if not perf:
        C.log("perf not found. Ubuntu: sudo apt install linux-tools-generic (WSL2: build perf from the "
              "WSL2-Linux-Kernel repo, see docs/PLATFORMS.md). Skipping.")
        return
    pdir = C.machine_dir(cfg, "profile")
    m = C.model_by_id(cfg, cfg["profile"].get("perf_model", cfg["profile"]["models"][0]))
    T = C.cpu_topology(cfg).perf_cores
    # decode with an empty cache: nothing but decode graphs are sampled (perf cannot skip a depth prefill)
    for tag, spec in (("prefill_pp512", B.Spec("perf", m, 512, 0, 0, T)),
                      ("decode_tg256", B.Spec("perf", m, 0, 256, 0, T))):
        data = pdir / f"perf_{m['id']}_{tag}.data"
        cmd = [perf, "record", "-F", "1999", "-g", "-e", "cpu-clock", "-o", str(data), "--",
               *[c for c in B.build_cmd(cfg, spec) if c != "-v"]]
        C.log("perf: " + " ".join(cmd))
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            C.log(f"perf record failed: {r.stderr.strip()[-400:]}\n  try: sudo sysctl kernel.perf_event_paranoid=1")
            return
        rep = subprocess.run([perf, "report", "-i", str(data), "--stdio", "--no-children", "--sort", "symbol",
                              "--percent-limit", "0.3"], capture_output=True, text=True).stdout
        (pdir / f"perf_{m['id']}_{tag}.txt").write_text(rep)
        groups = defaultdict(float)
        for line in rep.splitlines():
            mm = re.match(r"\s+([\d.]+)%\s+\[[.k]\]\s+(\S.*)$", line)
            if not mm:
                continue
            pct, sym = float(mm.group(1)), mm.group(2)
            g = next((name for name, rx in PERF_GROUPS if re.search(rx, sym)), "other")
            groups[g] += pct
        with open(pdir / f"perf_{m['id']}_{tag}_groups.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["group", "percent"])
            for g, p in sorted(groups.items(), key=lambda kv: -kv[1]):
                w.writerow([g, round(p, 2)])
        C.log(f"perf {tag}: " + ", ".join(f"{g} {p:.1f}%" for g, p in sorted(groups.items(), key=lambda kv: -kv[1])[:5]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--perf", action="store_true", help="also run perf sampling (Linux/WSL2)")
    ap.add_argument("--summarize-only", action="store_true")
    ap.add_argument("--force", action="store_true", help="re-profile even if files exist")
    args = ap.parse_args()
    cfg = C.load_config()
    if not args.summarize_only:
        run_opprof(cfg, args.force)
        if args.perf:
            run_perf(cfg)
    summarize(cfg)


if __name__ == "__main__":
    main()
