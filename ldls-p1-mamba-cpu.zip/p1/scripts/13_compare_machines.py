#!/usr/bin/env python3
"""Compare all machines that have results (both laptops, PARAM Rudra): results/COMPARE.md + plots/compare/*.png.

The roofline model predicts decode speed = bandwidth / bytes per token. If the model captures what limits decode,
measured/predicted ("efficiency") should be similar on different machines even when raw speeds differ, and the
measured points of all machines should fall on one line in the predicted-vs-measured plot. A machine that falls off
the line points at a machine-specific cause (thermal limits, hybrid cores, WSL2, single-channel RAM...).

  python3 scripts/13_compare_machines.py                 # real machines only
  python3 scripts/13_compare_machines.py --include-test  # also smoke/sandbox test machines (pipeline test)
"""
import argparse
import json
import re
import statistics as st
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import common as C  # noqa: E402

TEST = re.compile(r"^(smoke|sandbox|test)", re.I)


def rd(p: Path) -> pd.DataFrame:
    return pd.read_csv(p) if p.exists() and p.stat().st_size > 0 else pd.DataFrame()


def machine_rows(d: Path) -> dict:
    hw = json.loads((d / "hardware.json").read_text()) if (d / "hardware.json").exists() else {}
    s = rd(d / "stream.csv")
    tri = None
    if not s.empty:
        s = s[s["validates"] == True]  # noqa: E712
        tri = s.groupby("threads")["triad_gbs"].mean() if not s.empty else None
    return {"name": d.name, "hw": hw, "triad": tri, "sweep": rd(d / "raw" / "sweep.csv"), "pred": rd(d / "predictions.csv"),
            "ref": sorted(d.glob("reference/ref_defaults.jsonl"))}


def ref_numbers(paths) -> dict:
    out = {}
    for p in paths:
        for l in p.read_text().splitlines():
            if l.startswith("{"):
                r = json.loads(l)
                out["pp512" if r["n_prompt"] else "tg128"] = (r["avg_ts"], r["stddev_ts"], r["n_threads"])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--include-test", action="store_true")
    a = ap.parse_args()
    dirs = [d for d in sorted(C.RESULTS.iterdir()) if d.is_dir() and not d.name.startswith("_")
            and (a.include_test or not TEST.match(d.name))]
    M = [machine_rows(d) for d in dirs]
    M = [m for m in M if not m["sweep"].empty or m["ref"]]
    if not M:
        sys.exit("no machines with results yet")
    out = C.PLOTS / "compare"
    out.mkdir(parents=True, exist_ok=True)
    md = [f"# Cross-machine comparison ({C.now_iso()})\n", "## Machines\n",
          "| machine | CPU | perf cores | RAM | STREAM Triad @ max threads (GB/s) |", "|---|---|---:|---|---:|"]
    for m in M:
        hw, tri = m["hw"], m["triad"]
        md.append(f"| {m['name']} | {hw.get('cpu_model', '?')} | {hw.get('perf_cores', '?')} | {hw.get('ram_total_gb', '?')} GB "
                  f"{'' if 'FILL' in str(hw.get('ram_detail', '')) else hw.get('ram_detail', '')} | "
                  f"{tri.iloc[-1]:.1f} |" if tri is not None and len(tri) else f"| {m['name']} | {hw.get('cpu_model', '?')} | | | |")
    # ---------------------------------------------------------------- decode: predicted vs measured, all machines
    allrows = []
    for m in M:
        sw, pr = m["sweep"], m["pred"]
        if sw.empty or pr.empty:
            continue
        ok = sw[(sw["status"] == "ok") & (sw["sweep"] == "decode")]
        g = ok.groupby(["model", "ctx", "threads"]).agg(tps=("tps", "mean"), sd=("tps", "std"), n=("tps", "count")).reset_index()
        g = g.merge(pr[pr["scaling"] == 0][["model", "ctx", "threads", "pred_tps_triad", "pred_tps_read", "total_bytes"]],
                    on=["model", "ctx", "threads"])
        g["machine"] = m["name"]
        allrows.append(g)
    if allrows:
        D = pd.concat(allrows)
        D["eff"] = D["tps"] / D["pred_tps_triad"]
        fig, ax = plt.subplots(figsize=(6.2, 5.2))
        markers = "osD^v<>P*X"
        for i, (mach, g) in enumerate(D.groupby("machine")):
            ax.scatter(g["pred_tps_triad"], g["tps"], marker=markers[i % len(markers)], s=36, label=mach)
        lo, hi = min(D["pred_tps_triad"].min(), D["tps"].min()) * 0.8, max(D["pred_tps_triad"].max(), D["tps"].max()) * 1.25
        ax.plot([lo, hi], [lo, hi], "k--", lw=1, label="measured = predicted")
        e = st.median(D["eff"])
        ax.plot([lo, hi], [lo * e, hi * e], "k:", lw=1, label=f"median efficiency {100 * e:.0f}%")
        ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
        ax.set_xlabel("predicted decode t/s (STREAM Triad / bytes per token)"); ax.set_ylabel("measured decode t/s (mean of 3)")
        ax.set_title("Roofline check across machines (every model and context)"); ax.legend(fontsize=7); ax.grid(alpha=0.3, which="both")
        fig.tight_layout(); fig.savefig(out / "decode_pred_vs_meas_all_machines.png", dpi=130); plt.close(fig)
        md += ["\n## Decode: measured / predicted (efficiency) per machine\n",
               "| machine | points | median efficiency | min | max |", "|---|---:|---:|---:|---:|"]
        for mach, g in D.groupby("machine"):
            md.append(f"| {mach} | {len(g)} | {100 * g['eff'].median():.0f}% | {100 * g['eff'].min():.0f}% | {100 * g['eff'].max():.0f}% |")
        piv = D.pivot_table(index=["model", "ctx"], columns="machine", values="tps")
        if piv.shape[1] > 1:
            md += ["\n## Decode t/s, same model and context on each machine\n", piv.round(2).to_markdown()]
    # ---------------------------------------------------------------- prefill + bandwidth
    pre = []
    for m in M:
        sw = m["sweep"]
        if not sw.empty:
            ok = sw[(sw["status"] == "ok") & (sw["sweep"] == "prefill")]
            if not ok.empty:
                g = ok.groupby(["model", "n_prompt"])["tps"].mean().rename(m["name"])
                pre.append(g)
    if len(pre) > 1:
        md += ["\n## Prefill t/s on each machine\n", pd.concat(pre, axis=1).round(1).to_markdown()]
    tri = [(m["name"], m["triad"]) for m in M if m["triad"] is not None and len(m["triad"])]
    if tri:
        fig, ax = plt.subplots(figsize=(6, 3.8))
        for name, t in tri:
            ax.plot(t.index, t.values, marker="o", label=name)
        ax.set_xlabel("threads"); ax.set_ylabel("STREAM Triad (GB/s)"); ax.set_title("Memory bandwidth vs threads")
        ax.grid(alpha=0.3); ax.legend(fontsize=7)
        fig.tight_layout(); fig.savefig(out / "bandwidth_all_machines.png", dpi=130); plt.close(fig)
    # ---------------------------------------------------------------- shared reference test
    refs = [(m["name"], ref_numbers(m["ref"])) for m in M if m["ref"]]
    if refs:
        md += ["\n## Shared reference test (Llama-3.2-1B Q4_K_M, llama-bench defaults)\n",
               "| machine | pp512 t/s | tg128 t/s | threads |", "|---|---:|---:|---:|"]
        for name, r in refs:
            pp, tg = r.get("pp512"), r.get("tg128")
            md.append(f"| {name} | {pp[0]:.1f} ± {pp[1]:.1f} | {tg[0]:.2f} ± {tg[1]:.2f} | {(pp or tg)[2]} |" if pp and tg else f"| {name} | | | |")
        if not any(n.startswith("rudra") for n, _ in refs):
            md.append("\nNo PARAM Rudra run yet: the laptop rows are the same fixed test (fallback). "
                      "Attempts are logged in results/rudra-attempts.md.")
    (C.RESULTS / "COMPARE.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    C.log(f"wrote {C.RESULTS / 'COMPARE.md'} and plots/compare/")


if __name__ == "__main__":
    main()
