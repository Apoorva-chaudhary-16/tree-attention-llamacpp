#!/usr/bin/env bash
# Run ONCE on the PARAM Rudra LOGIN node (compute nodes usually have no internet).
# Builds llama.cpp at the pinned commit as a PORTABLE build (all x86 CPU variants, chosen at run time on the
# compute node), downloads the reference model and the STREAM source. The job itself then takes ~5 minutes.
#   module load gcc cmake python   (exact names: module avail)
#   scripts/09_rudra_prepare.sh && sbatch scripts/09_rudra_reference.sbatch
set -euo pipefail
cd "$(dirname "$0")/.."
command -v cmake >/dev/null || { echo "!! cmake not found: module load cmake (or pip install --user cmake)"; exit 1; }
python3 -c "import yaml" 2>/dev/null || pip install --user pyyaml
PORTABLE=1 BUILD_DIR=build-rudra scripts/00_build_llamacpp.sh
P1_CONFIG=config/option3.yaml scripts/03_get_models.sh llama-1b-q4km
mkdir -p tools/stream
[ -s tools/stream/stream.c ] || curl -fsSL -o tools/stream/stream.c https://raw.githubusercontent.com/jeffhammond/STREAM/master/stream.c \
  || curl -fsSL -o tools/stream/stream.c https://www.cs.virginia.edu/stream/FTP/Code/stream.c
echo "== ready. Submit:  sbatch scripts/09_rudra_reference.sbatch   (log attempts: scripts/09_rudra_log.sh)"
