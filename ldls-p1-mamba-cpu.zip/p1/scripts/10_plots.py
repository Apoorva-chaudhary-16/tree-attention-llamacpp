#!/usr/bin/env python3
"""All plots from the raw CSVs -> plots/<machine>/.
Required by the brief: decode_vs_context, prefill_vs_prompt, thread_scaling, op_breakdown, predicted_vs_measured.
Extra: memory_vs_context, experiment_ubatch, scan_operator (from kernels/build/ssm_scan_bench).
Error bars = standard deviation over the repetitions (each a fresh process)."""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import common as C  # noqa: E402

plt.rcParams.update({"figure.dpi": 130, "font.size": 9, "axes.grid": True, "grid.alpha": 0.3})


def load(cfg):
    d = C.machine_dir(cfg)
    rd = lambda p: pd.read_csv(p) if p.exists() and p.stat().st_size > 0 else pd.DataFrame()
    return {"sweep": rd(d / "raw" / "sweep.csv"), "pred": rd(d / "predictions.csv"), "stream": rd(d / "stream.csv"),
            "bw": rd(d / "bw_read.csv"), "prof": rd(d / "profile" / "summary.csv"), "exp": rd(d / "raw" / "experiment.csv"),
            "exp_pred": rd(d / "experiment_prediction.csv"), "scan": rd(d / "ssm_scan_bench.csv")}


def agg(df, keys):
    ok = df[df["status"] == "ok"].copy()
    ok["tps"] = ok["tps"].astype(float)
    g = ok.groupby(keys).agg(tps=("tps", "mean"), sd=("tps", "std"), n=("tps", "count"),
                             rss=("peak_rss_gb", "mean")).reset_index()
    g["sd"] = g["sd"].fillna(0)
    return g


def labels(cfg):
    return {m["id"]: m["label"] for m in cfg["models"]}


def save(fig, out, name):
    fig.tight_layout()
    fig.savefig(out / f"{name}.png")
    plt.close(fig)
    C.log(f"plot {name}.png")


def main():
    cfg = C.load_config()
    D = load(cfg)
    out = C.PLOTS / cfg["_machine"]
    out.mkdir(parents=True, exist_ok=True)
    L = labels(cfg)
    T = C.cpu_topology(cfg).perf_cores
    tag = f"{cfg['_machine']}, {T} threads, mean +/- sd over {cfg['sweep']['reps']} runs"
    sw = D["sweep"]
    if not sw.empty:
        # 1. decode speed vs context (+ prediction)
        dec = agg(sw[sw["sweep"] == "decode"], ["model", "ctx"])
        fig, ax = plt.subplots(figsize=(7, 4.2))
        for i, (mid, g) in enumerate(dec.groupby("model")):
            line = ax.errorbar(g["ctx"], g["tps"], yerr=g["sd"], marker="o", capsize=3, label=L.get(mid, mid))
            if not D["pred"].empty:
                p = D["pred"][(D["pred"]["model"] == mid) & (D["pred"]["scaling"] == 0)]
                ax.plot(p["ctx"], p["pred_tps_triad"], "--", color=line[0].get_color(), alpha=0.7)
        ax.set_xscale("log", base=2)
        ax.set_xlabel("context length at end of the 128-token decode window (tokens)")
        ax.set_ylabel("decode speed (tokens/s)")
        ax.set_title(f"Decode speed vs context ({tag})\ndashed = roofline prediction (STREAM Triad / bytes per token)")
        ax.legend(fontsize=7)
        save(fig, out, "decode_vs_context")
        # 2. prefill speed vs prompt length
        pre = agg(sw[sw["sweep"] == "prefill"], ["model", "n_prompt"])
        if not pre.empty:
            fig, ax = plt.subplots(figsize=(7, 4.2))
            for mid, g in pre.groupby("model"):
                ax.errorbar(g["n_prompt"], g["tps"], yerr=g["sd"], marker="s", capsize=3, label=L.get(mid, mid))
            ax.set_xscale("log", base=2)
            ax.set_xlabel("prompt length (tokens)")
            ax.set_ylabel("prefill speed (tokens/s)")
            ax.set_title(f"Prefill speed vs prompt length ({tag})")
            ax.legend(fontsize=7)
            save(fig, out, "prefill_vs_prompt")
        # 3. thread scaling (+ bandwidth)
        sc = sw[sw["sweep"] == "scaling"]
        if not sc.empty:
            fig, axs = plt.subplots(1, 3, figsize=(12, 3.8))
            pp = agg(sc[sc["n_prompt"] > 0], ["model", "threads"])
            tg = agg(sc[sc["n_gen"] > 0], ["model", "threads"])
            for mid, g in pp.groupby("model"):
                l = axs[0].errorbar(g["threads"], g["tps"], yerr=g["sd"], marker="o", capsize=3, label=L.get(mid, mid))
                t1 = g[g["threads"] == g["threads"].min()]["tps"].iloc[0]
                axs[0].plot(g["threads"], t1 * g["threads"] / g["threads"].min(), ":", color=l[0].get_color(), alpha=0.5)
            for mid, g in tg.groupby("model"):
                l = axs[1].errorbar(g["threads"], g["tps"], yerr=g["sd"], marker="o", capsize=3, label=L.get(mid, mid))
                if not D["pred"].empty:
                    p = D["pred"][(D["pred"]["model"] == mid) & (D["pred"]["scaling"] == 1)].sort_values("threads")
                    axs[1].plot(p["threads"], p["pred_tps_triad"], "--", color=l[0].get_color(), alpha=0.6)
            axs[0].set_title("prefill pp512 (dotted = linear scaling)")
            axs[1].set_title("decode tg128 (dashed = Triad BW(t) / bytes)")
            for a in axs[:2]:
                a.set_xlabel("threads"); a.set_ylabel("tokens/s"); a.legend(fontsize=6)
            if not D["stream"].empty:
                s = D["stream"].groupby("threads").agg(triad=("triad_gbs", "mean"), sd=("triad_gbs", "std")).reset_index()
                axs[2].errorbar(s["threads"], s["triad"], yerr=s["sd"].fillna(0), marker="o", capsize=3, label="STREAM Triad")
                if not D["bw"].empty:
                    b = D["bw"].groupby("threads")["best_gbs"].mean().reset_index()
                    axs[2].plot(b["threads"], b["best_gbs"], "s-", label="read-only")
                axs[2].set_xlabel("threads"); axs[2].set_ylabel("GB/s"); axs[2].set_title("memory bandwidth"); axs[2].legend(fontsize=7)
            fig.suptitle(f"Thread scaling, 1 .. {T} performance cores ({cfg['_machine']})")
            save(fig, out, "thread_scaling")
        # 6. memory vs context
        fig, ax = plt.subplots(figsize=(7, 4))
        for mid, g in dec.groupby("model"):
            ax.plot(g["ctx"], g["rss"], marker="o", label=L.get(mid, mid))
        ax.axhline(cfg.get("memory_budget_gb", 4.5), color="red", ls=":", label="course budget")
        ax.set_xscale("log", base=2)
        ax.set_xlabel("context (tokens)"); ax.set_ylabel("peak RSS (GB)")
        ax.set_title("Peak memory vs context: recurrent state is constant, a KV cache grows")
        ax.legend(fontsize=7)
        save(fig, out, "memory_vs_context")
        # 5. predicted vs measured decode
        if not D["pred"].empty:
            p = D["pred"][D["pred"]["scaling"] == 0]
            mm = dec.merge(p, on=["model", "ctx"])
            if not mm.empty:
                mm = mm.sort_values(["model", "ctx"])
                x = range(len(mm))
                fig, ax = plt.subplots(figsize=(max(7, 0.55 * len(mm)), 4.2))
                w = 0.2
                ax.bar([i - 1.5 * w for i in x], mm["pred_tps_read"], w, label="pred. (read-only BW)")
                ax.bar([i - 0.5 * w for i in x], mm["pred_tps_triad"], w, label="pred. (Triad, ideal state traffic)")
                ax.bar([i + 0.5 * w for i in x], mm["pred_tps_triad_llamacpp"], w, label="pred. (Triad, llama.cpp traffic)")
                ax.bar([i + 1.5 * w for i in x], mm["tps"], w, yerr=mm["sd"], capsize=2, label="measured", color="k")
                for i, r in zip(x, mm.itertuples()):
                    ax.text(i + 1.5 * w, r.tps, f"{100 * r.tps / r.pred_tps_triad:.0f}%", ha="center", va="bottom", fontsize=6)
                ax.set_xticks(list(x))
                ax.set_xticklabels([f"{L.get(r.model, r.model)}\n{r.ctx}" for r in mm.itertuples()], rotation=60, fontsize=6, ha="right")
                ax.set_ylabel("decode tokens/s")
                ax.set_title("Predicted vs measured decode speed (label: measured as % of Triad prediction)")
                ax.legend(fontsize=7)
                save(fig, out, "predicted_vs_measured")
    # 4. operator breakdown
    pr = D["prof"]
    if not pr.empty:
        pc = pr[pr["kind"] == "by_cat"]
        groups = list(pc.groupby(["phase", "model", "point"]))
        cats = sorted(pc["key"].unique(), key=lambda c: -pc[pc["key"] == c]["share"].mean())
        fig, ax = plt.subplots(figsize=(9, 0.42 * len(groups) + 1.5))
        names = []
        for i, ((phase, mid, point), g) in enumerate(groups):
            left = 0.0
            for j, cat in enumerate(cats):
                v = g[g["key"] == cat]["share"].sum()
                ax.barh(i, v, left=left, color=plt.cm.tab20(j % 20), label=cat if i == 0 else None)
                left += v
            names.append(f"{L.get(mid, mid)} | {phase} {point}")
        ax.set_yticks(range(len(groups)))
        ax.set_yticklabels(names, fontsize=7)
        ax.set_xlabel("share of operator wall time")
        ax.set_xlim(0, 1)
        ax.set_title("Per-operator time breakdown (opprof patch, thread-0 wall time incl. barrier wait)")
        ax.legend(fontsize=6, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.12))
        save(fig, out, "op_breakdown")
    # 7. own experiment
    ex = D["exp"]
    if not ex.empty and not D["exp_pred"].empty:
        e = agg(ex, ["model", "variant"])
        e["ubatch"] = e["variant"].str.replace("ub", "").astype(int)
        fig, ax = plt.subplots(figsize=(7, 4.2))
        for mid, g in e.groupby("model"):
            g = g.sort_values("ubatch")
            l = ax.errorbar(g["ubatch"], g["tps"], yerr=g["sd"], marker="o", capsize=3, label=f"{L.get(mid, mid)} measured")
            p = D["exp_pred"][D["exp_pred"]["model"] == mid].sort_values("ubatch")
            ax.plot(p["ubatch"], p["pred_tps"], "--", color=l[0].get_color(), label="prediction (written before the runs)")
            if p["crossover_b"].iloc[0] < 1e9:
                ax.axvline(p["crossover_b"].iloc[0], color=l[0].get_color(), ls=":", alpha=0.6)
        ax.set_xscale("log", base=2); ax.set_yscale("log")
        ax.set_xlabel("micro-batch size b (tokens per weight pass)"); ax.set_ylabel("prefill tokens/s")
        ax.set_title("Own experiment: prefill speed vs micro-batch (dotted = predicted crossover b*)")
        ax.legend(fontsize=6)
        save(fig, out, "experiment_ubatch")
    # 8. scan operator study
    s = D["scan"]
    if not s.empty:
        Tm = s["threads"].max()
        g = s[s["threads"] == Tm].groupby(["shape", "phase"])["ns_per_token_per_layer"].agg(["mean", "std"]).reset_index()
        fig, ax = plt.subplots(figsize=(7, 3.8))
        shapes = list(dict.fromkeys(g["shape"]))
        for k, ph in enumerate(["decode", "prefill"]):
            v = [g[(g["shape"] == sh) & (g["phase"] == ph)] for sh in shapes]
            ax.bar([i + (k - 0.5) * 0.38 for i in range(len(shapes))], [x["mean"].iloc[0] / 1e3 if len(x) else 0 for x in v], 0.38,
                   yerr=[x["std"].iloc[0] / 1e3 if len(x) else 0 for x in v], capsize=3, label=ph)
        ax.set_xticks(range(len(shapes))); ax.set_xticklabels(shapes)
        ax.set_ylabel("SSM_SCAN time per token per layer (us)")
        ax.set_title(f"ggml SSM_SCAN alone, real layer shapes, {Tm} threads")
        ax.legend()
        save(fig, out, "scan_operator")


if __name__ == "__main__":
    main()
