#!/usr/bin/env bash
# Option 3 operator study: ggml SSM_SCAN alone with the real Mamba-1 / Mamba-2 layer shapes, decode and
# prefill, threads 1..P, 3 repetitions (+ check of our Mamba-2 step against the ggml op). Needs kernels/build.sh.
set -euo pipefail
cd "$(dirname "$0")/.."
read -r MACHINE P < <(python3 -c 'import sys; sys.path.insert(0,"scripts/lib"); import common as C; c=C.load_config(); print(c["_machine"], C.cpu_topology(c).perf_cores)')
mkdir -p "results/$MACHINE"
kernels/build/ssm_scan_bench --threads "$(seq -s, 1 "$P")" --reps 3 --csv "results/$MACHINE/ssm_scan_bench.csv" | tee "results/$MACHINE/ssm_scan_bench.log"
