#!/usr/bin/env bash
# Shared reference test (course step 9): Llama-3.2-1B Q4_K_M, 512-token prompt, 128-token decode, 3 repetitions.
# IDENTICAL on the PARAM Rudra node and on a laptop, so the numbers can be compared. Needs only bash, llama-bench,
# and python3 (standard library); runs STREAM if gcc + tools/stream/stream.c are available.
#
#   scripts/09_reference.sh                 # laptop (after make build + scripts/03_get_models.sh llama-1b-q4km)
#   sbatch scripts/09_rudra_reference.sbatch    # Rudra (calls this script on the compute node)
# Env: P1_MACHINE (name, default hostname), REF_MODEL (gguf path), LLAMA_BIN_DIR, REF_THREADS (default: perf cores),
#      REF_REPS (default 3), REF_STREAM=0 to skip STREAM.
# Writes results/<machine>/reference/{reference.md, *.jsonl, node.txt, stream.txt}.
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"; cd "$REPO"
MACHINE="${P1_MACHINE:-$(hostname -s 2>/dev/null || hostname)}"
MODEL="${REF_MODEL:-models/Llama-3.2-1B-Instruct-Q4_K_M.gguf}"
BIN="${LLAMA_BIN_DIR:-${LLAMA_CPP_DIR:-$REPO/../llama.cpp}/build/bin}"
REPS="${REF_REPS:-3}"
OUT="results/$MACHINE/reference"; mkdir -p "$OUT"
[ -s "$MODEL" ] || { echo "!! $MODEL missing: scripts/03_get_models.sh llama-1b-q4km (Rudra: on the login node)"; exit 1; }
[ -x "$BIN/llama-bench" ] || { echo "!! $BIN/llama-bench missing: make build"; exit 1; }

# ---------- cores: physical performance cores (Linux: hybrid-aware; macOS: perflevel0)
if [ "$(uname -s)" = "Darwin" ]; then
  PCORES="$(sysctl -n hw.perflevel0.physicalcpu 2>/dev/null || sysctl -n hw.physicalcpu)"; PIN=""
else
  PCORES="$(lscpu -p=CORE,SOCKET | grep -v '^#' | sort -u | wc -l)"; PIN=""
  if [ -r /sys/devices/cpu_core/cpus ]; then          # Intel hybrid, native Linux: one logical cpu per P-core
    LIST="$(python3 - <<'PY'
cpus = []
for part in open("/sys/devices/cpu_core/cpus").read().strip().split(","):
    a, _, b = part.partition("-"); cpus += range(int(a), int(b or a) + 1)
seen, out = set(), []
for c in cpus:
    try: core = open(f"/sys/devices/system/cpu/cpu{c}/topology/core_id").read().strip()
    except OSError: continue
    if core not in seen: seen.add(core); out.append(str(c))
print(",".join(out))
PY
)"
    PCORES="$(echo "$LIST" | tr ',' '\n' | grep -c .)"; command -v taskset >/dev/null && PIN="taskset -c $LIST"
  fi
fi
T="${REF_THREADS:-$PCORES}"
SOCKETS="$( (lscpu -p=SOCKET 2>/dev/null | grep -v '^#' | sort -u | wc -l) || echo 1)"
echo "== reference test on $MACHINE: $T threads (physical perf cores: $PCORES, sockets: $SOCKETS), model $MODEL"

# ---------- record the node / laptop
{
  echo "date: $(date -Iseconds)"; echo "host: $(hostname)"; echo "slurm job: ${SLURM_JOB_ID:-none} nodelist: ${SLURM_JOB_NODELIST:-none}"
  echo "load average before: $(cat /proc/loadavg 2>/dev/null || sysctl -n vm.loadavg)"
  echo "llama.cpp: $("$BIN/llama-bench" --version 2>&1 | head -2 | tr '\n' ' ')"
  echo "model sha256: $( (sha256sum "$MODEL" 2>/dev/null || shasum -a 256 "$MODEL") | cut -d' ' -f1)"
  echo; (lscpu 2>/dev/null || sysctl -a 2>/dev/null | grep -E "machdep.cpu|hw.perflevel|hw.memsize") ; echo
  (numactl -H 2>/dev/null || true); (free -g 2>/dev/null || true)
} > "$OUT/node.txt"

# ---------- the fixed test. Headline = llama-bench defaults (what every team is most likely to run);
#            plus explicit threads/flash-attn, and one-socket binding on multi-socket nodes.
B=("$BIN/llama-bench" -m "$MODEL" -p 512 -n 128 -r "$REPS" -o jsonl)
"${B[@]}"                                            > "$OUT/ref_defaults.jsonl"
$PIN "${B[@]}" -t "$T" -fa on                        > "$OUT/ref_threads${T}_fa.jsonl"
if [ "$SOCKETS" -gt 1 ] && command -v numactl >/dev/null; then
  CPS=$(( PCORES / SOCKETS ))
  numactl --cpunodebind=0 --membind=0 "${B[@]}" -t "$CPS" -fa on > "$OUT/ref_socket0_threads${CPS}_fa.jsonl" || true
  "${B[@]}" -t "$PCORES" -fa on --numa distribute   > "$OUT/ref_allcores_numa_fa.jsonl" || true
fi
echo "load average after: $(cat /proc/loadavg 2>/dev/null || sysctl -n vm.loadavg)" >> "$OUT/node.txt"

# ---------- bandwidth (optional): STREAM Triad with all physical cores, 3 runs
DEF_STREAM=0; [ -n "${SLURM_JOB_ID:-}" ] && DEF_STREAM=1   # laptops: use 02_stream.py results instead
if [ "${REF_STREAM:-$DEF_STREAM}" = "1" ] && [ -s tools/stream/stream.c ] && command -v gcc >/dev/null; then
  ARCH="-march=native"; case "$(uname -m)" in arm64|aarch64) ARCH="-mcpu=native";; esac
  gcc -O3 $ARCH -fopenmp -DSTREAM_ARRAY_SIZE=${REF_STREAM_N:-80000000} -DNTIMES=10 -mcmodel=medium tools/stream/stream.c -o "$OUT/stream" 2>/dev/null \
   || gcc -O3 $ARCH -fopenmp -DSTREAM_ARRAY_SIZE=${REF_STREAM_N:-80000000} -DNTIMES=10 tools/stream/stream.c -o "$OUT/stream" 2>/dev/null || true
  if [ -x "$OUT/stream" ]; then
    : > "$OUT/stream.txt"
    for r in 1 2 3; do OMP_NUM_THREADS="$PCORES" OMP_PROC_BIND=spread OMP_PLACES=cores "$OUT/stream" >> "$OUT/stream.txt"; done
    rm -f "$OUT/stream"
  fi
fi

# ---------- summary (stdlib only)
python3 - "$OUT" "$MACHINE" "$T" "$MODEL" <<'PY'
import json, os, re, statistics as st, sys, pathlib
out, machine, T = pathlib.Path(sys.argv[1]), sys.argv[2], sys.argv[3]
rows = []
for f in sorted(out.glob("ref_*.jsonl")):
    for l in f.read_text().splitlines():
        if l.startswith("{"):
            r = json.loads(l)
            test = f"pp{r['n_prompt']}" if r["n_prompt"] else f"tg{r['n_gen']}"
            fa = {-1: "auto", 0: "off", 1: "on"}.get(r.get("flash_attn"), str(r.get("flash_attn", "?")))
            rows.append((f.stem, test, r["n_threads"], fa, r["avg_ts"], r["stddev_ts"], len(r.get("samples_ts", []))))
lines = [f"# Shared reference test on `{machine}`", "",
         f"Model `{os.path.basename(sys.argv[4])}` (the fixed test: Llama-3.2-1B Q4_K_M), 512-token prompt (pp512) and 128-token decode (tg128), "
         f"repetitions per point as listed (n). Headline row: llama-bench defaults.", "",
         "| run | test | threads | flash-attn | tokens/s (mean ± sd) | n |", "|---|---|---:|---|---:|---:|"]
lines += [f"| {a} | {b} | {c} | {d} | **{e:.2f} ± {f:.2f}** | {g} |" if a == "ref_defaults" else
          f"| {a} | {b} | {c} | {d} | {e:.2f} ± {f:.2f} | {g} |" for a, b, c, d, e, f, g in rows]
s = out / "stream.txt"
if s.exists():
    tri = [float(x) / 1e3 for x in re.findall(r"^Triad:\s+([\d.]+)", s.read_text(), re.M)]
    if tri:
        lines += ["", f"STREAM Triad, all physical cores: **{st.mean(tri):.1f} ± {(st.stdev(tri) if len(tri) > 1 else 0):.1f} GB/s** "
                  f"(n={len(tri)}; validates: {'Solution Validates' in s.read_text()})"]
        tg = [r for r in rows if r[0] == "ref_defaults" and r[1].startswith("tg")]
        if tg:
            per = os.path.getsize(sys.argv[4]) / 1e9 + 0.002  # tied embeddings: every tensor read once per token, + ~2 MB KV
            gb = tg[0][4] * per
            lines += [f"Decode reads ≈ {per:.2f} GB per token (model file + KV), so tg128 moves ≈ {gb:.1f} GB/s, "
                      f"{100 * gb / st.mean(tri):.0f}% of STREAM Triad (exact bytes: scripts/05_predict.py)."]
(out / "reference.md").write_text("\n".join(lines) + "\n")
print("\n".join(lines))
PY
