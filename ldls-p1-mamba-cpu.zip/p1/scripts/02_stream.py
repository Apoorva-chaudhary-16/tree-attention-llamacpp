#!/usr/bin/env python3
"""Memory bandwidth with STREAM (course requirement) plus a read-only kernel (scripts/bw/bw_read.c).

For every thread count 1..P (P = performance cores) and 3 repetitions:
  * STREAM (OpenMP), array size >= 4x last-level cache (STREAM's own rule), "Solution Validates" checked
  * bw_read: read-only streaming bandwidth (what decode actually does)

Writes results/<machine>/stream.csv and bw_read.csv. 05_predict.py uses the value at the thread count
of the sweep; 10_plots.py overlays bandwidth-vs-threads on the thread-scaling plot.

  python3 scripts/02_stream.py [--threads 1,2,4] [--array-size 40000000] [--reps 3]
"""
import argparse
import os
import platform
import re
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import common as C  # noqa: E402

STREAM_URLS = ["https://www.cs.virginia.edu/stream/FTP/Code/stream.c",
               "https://raw.githubusercontent.com/jeffhammond/STREAM/master/stream.c"]
TOOLS = C.REPO / "tools" / "stream"


def fetch_stream() -> Path:
    TOOLS.mkdir(parents=True, exist_ok=True)
    src = TOOLS / "stream.c"
    if src.exists():
        return src
    for url in STREAM_URLS:
        try:
            C.log(f"downloading {url}")
            urllib.request.urlretrieve(url, src)
            if "STREAM" in src.read_text(errors="ignore"):
                return src
        except Exception as e:  # noqa: BLE001
            C.log(f"  failed: {e}")
    sys.exit("could not download stream.c; put it in tools/stream/stream.c by hand")


def arch_flag() -> str:
    return "-mcpu=native" if platform.machine() in ("arm64", "aarch64") else "-march=native"


def openmp_compilers() -> list[list[str]]:
    """Candidate compiler command prefixes that support OpenMP on this platform."""
    cands = []
    if C.is_macos():
        for v in ("15", "14", "13", "12"):
            if shutil.which(f"gcc-{v}"):
                cands.append([f"gcc-{v}", "-fopenmp"])
        brew = C.sh("brew --prefix libomp 2>/dev/null")
        if brew:
            cands.append(["clang", "-Xpreprocessor", "-fopenmp", f"-I{brew}/include", f"-L{brew}/lib", "-lomp"])
    else:
        cands.append([os.environ.get("CC", "gcc"), "-fopenmp"])
    return cands


def build_stream(n: int) -> Path:
    src = fetch_stream()
    exe = TOOLS / f"stream_n{n}"
    if exe.exists():
        return exe
    extra = ["-mcmodel=medium"] if (3 * 8 * n > 2**31 and platform.machine() == "x86_64") else []
    for cc in openmp_compilers():
        cmd = [*cc[:1], "-O3", arch_flag(), *cc[1:], *extra, f"-DSTREAM_ARRAY_SIZE={n}", "-DNTIMES=20",
               str(src), "-o", str(exe)]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode == 0:
            C.log("built STREAM: " + " ".join(cmd))
            (TOOLS / f"stream_n{n}.cmd").write_text(" ".join(cmd) + "\n")
            return exe
        C.log(f"compile failed with {cc[0]}: {r.stderr.strip()[:300]}")
    sys.exit("No OpenMP compiler found. macOS: `brew install gcc` (or libomp). Linux: install gcc.")


def build_bw_read() -> Path:
    src = C.REPO / "scripts" / "bw" / "bw_read.c"
    exe = TOOLS / "bw_read"
    if not exe.exists() or exe.stat().st_mtime < src.stat().st_mtime:
        cc = "clang" if C.is_macos() and not shutil.which("gcc") else os.environ.get("CC", "gcc")
        subprocess.run([cc, "-O3", arch_flag(), "-pthread", str(src), "-o", str(exe)], check=True)
    return exe


def llc_bytes() -> int:
    if C.is_macos():
        return int(C.sysctl("hw.l3cachesize") or 0) or 48 * 2**20  # SLC size is not exposed: assume 48 MiB
    txt = C.sh("lscpu -C --bytes 2>/dev/null")
    best = 0
    for line in txt.splitlines():
        p = line.split()
        if len(p) >= 3 and p[0] in ("L2", "L3"):
            best = max(best, int(p[2]))
    return best or 32 * 2**20


def parse_stream(out: str) -> dict:
    res = {}
    for k in ("Copy", "Scale", "Add", "Triad"):
        m = re.search(rf"^{k}:\s+([\d.]+)", out, re.M)
        res[k.lower() + "_gbs"] = float(m.group(1)) / 1e3 if m else float("nan")  # MB/s (1e6) -> GB/s
    res["validates"] = "Solution Validates" in out
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threads", help="comma list; default 1..perf_cores")
    ap.add_argument("--array-size", type=int, help="STREAM_ARRAY_SIZE (elements per array)")
    ap.add_argument("--reps", type=int, default=None)
    ap.add_argument("--bw-mib", type=int, default=1024, help="bw_read buffer size")
    args = ap.parse_args()

    cfg = C.load_config()
    topo = C.cpu_topology(cfg)
    reps = args.reps or cfg["sweep"]["reps"]
    threads = ([int(t) for t in args.threads.split(",")] if args.threads
               else list(range(1, topo.perf_cores + 1)))
    llc = llc_bytes()
    n = args.array_size or max(40_000_000, (4 * llc // 8) * 5 // 4)   # >= 4x LLC per array, min 320 MB/array
    need_gb = 3 * 8 * n / 1e9
    if need_gb > C.mem_available_gb() - 0.5:
        sys.exit(f"STREAM needs {need_gb:.1f} GB but only {C.mem_available_gb():.1f} GB available; "
                 f"close apps or pass --array-size")
    C.log(f"LLC={llc / 2**20:.0f} MiB -> STREAM_ARRAY_SIZE={n:,} ({8 * n / 1e6:.0f} MB per array, "
          f"{need_gb:.2f} GB total); threads={threads}; reps={reps}")
    stream_exe, bw_exe = build_stream(n), build_bw_read()
    out_dir = C.machine_dir(cfg)
    s_csv, b_csv = out_dir / "stream.csv", out_dir / "bw_read.csv"
    for p in (s_csv, b_csv):
        p.unlink(missing_ok=True)
    pin = C.taskset_prefix(topo)
    for rep in range(1, reps + 1):          # reps outermost: drift spreads over thread counts
        for t in threads:
            env = {"OMP_NUM_THREADS": t, "OMP_PROC_BIND": "spread", "OMP_PLACES": "cores"}
            r = C.run_measured([*pin, str(stream_exe)], env=env)
            row = {"threads": t, "rep": rep, "array_size": n, **parse_stream(r.stdout),
                   "swapped": r.swapped, "time": C.now_iso()}
            C.append_csv(s_csv, row, list(row))
            rb = C.run_measured([*pin, str(bw_exe), str(args.bw_mib), str(t), "10"])
            m = re.search(r"best_gbs=([\d.]+) avg_gbs=([\d.]+)", rb.stdout)
            brow = {"threads": t, "rep": rep, "mib": args.bw_mib,
                    "best_gbs": float(m.group(1)) if m else float("nan"),
                    "avg_gbs": float(m.group(2)) if m else float("nan"), "time": C.now_iso()}
            C.append_csv(b_csv, brow, list(brow))
            C.log(f"rep {rep} t={t:2d}: Triad {row['triad_gbs']:6.1f} GB/s  Copy {row['copy_gbs']:6.1f}  "
                  f"read-only {brow['best_gbs']:6.1f}  validates={row['validates']}")
            if not row["validates"]:
                C.log("!! STREAM did not validate: result unusable (check compiler flags / memory)")
    C.log(f"wrote {s_csv} and {b_csv}")


if __name__ == "__main__":
    main()
