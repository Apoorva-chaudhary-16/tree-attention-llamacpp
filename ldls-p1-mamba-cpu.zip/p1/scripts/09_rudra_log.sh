#!/usr/bin/env bash
# Append the status of every reference-job attempt to results/rudra-attempts.md (run on the login node, any time).
set -uo pipefail
cd "$(dirname "$0")/.."
F=results/rudra-attempts.md; mkdir -p results
[ -s "$F" ] || printf '# PARAM Rudra reference-run attempts\n\nLogged by scripts/09_rudra_log.sh (sacct/squeue on the login node).\n' > "$F"
{
  echo; echo "## $(date -Iseconds)"; echo '```'
  sacct -u "${USER:-$(id -un)}" --name=p1-reference -S now-14days --format=JobID,Submit,Start,End,State,Elapsed,NodeList,Reason%30 2>&1 | grep -v '\.\(batch\|extern\)'
  echo "--- queue now:"; squeue -u "${USER:-$(id -un)}" -o "%.10i %.12P %.12j %.8T %.20S %.20r" 2>&1
  echo "--- partitions:"; sinfo -s 2>&1 | head -8
  echo '```'
} >> "$F"
tail -20 "$F"
