#!/usr/bin/env bash
# Build llama.cpp for CPU only, at the pinned commit, with the opprof patch applied.
#
#   scripts/00_build_llamacpp.sh            # uses LLAMA_CPP_DIR or ../llama.cpp
#   BUILD_DIR=build-rudra scripts/00_build_llamacpp.sh   # separate build dir (e.g. on the cluster)
#
# CPU-only means: no CUDA/Vulkan/SYCL, Metal OFF on Apple Silicon (course rule), and BLAS OFF so
# that prefill matmuls run in ggml's own CPU kernels (on macOS, BLAS = Accelerate, which uses the AMX
# coprocessor and would make prefill numbers incomparable with other teams).
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
CFG="${P1_CONFIG:-$REPO/config/option3.yaml}"

cfg() { python3 - "$CFG" "$1" <<'EOF'
import sys, yaml
c = yaml.safe_load(open(sys.argv[1]))
v = c
for k in sys.argv[2].split("."):
    v = v[k]
print(" ".join(v) if isinstance(v, list) else v)
EOF
}

COMMIT="$(cfg llama_cpp.commit)"
LLAMA_DIR="${LLAMA_CPP_DIR:-$REPO/$(cfg llama_cpp.dir)}"
PATCHES="$(cfg llama_cpp.patches)"
BUILD_DIR="${BUILD_DIR:-build}"
JOBS="${JOBS:-$( (nproc || sysctl -n hw.ncpu) 2>/dev/null )}"

echo "== llama.cpp dir: $LLAMA_DIR   commit: $COMMIT   build dir: $BUILD_DIR"
if [ ! -d "$LLAMA_DIR/.git" ]; then
  git clone https://github.com/ggml-org/llama.cpp "$LLAMA_DIR"
fi
cd "$LLAMA_DIR"
if [ "$(git rev-parse HEAD)" != "$COMMIT" ]; then
  if ! git diff --quiet; then
    echo "!! $LLAMA_DIR has local changes and is not at $COMMIT. Stash or remove them first." >&2
    exit 1
  fi
  git fetch --quiet origin || true
  git checkout --quiet "$COMMIT"
fi

for p in $PATCHES; do
  pp="$REPO/$p"
  if git apply --check -R "$pp" 2>/dev/null; then
    echo "== patch already applied: $p"
  else
    git apply "$pp"
    echo "== applied patch: $p"
  fi
done

FLAGS=(-DCMAKE_BUILD_TYPE=Release -DGGML_NATIVE=ON
       -DGGML_CUDA=OFF -DGGML_VULKAN=OFF -DGGML_SYCL=OFF -DGGML_HIP=OFF -DGGML_OPENCL=OFF
       -DGGML_BLAS=OFF -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_SERVER=OFF -DLLAMA_OPENSSL=OFF)
if [ "$(uname -s)" = "Darwin" ]; then
  FLAGS+=(-DGGML_METAL=OFF)
fi
if [ "${PORTABLE:-0}" = "1" ]; then   # e.g. build on a login node, run on different compute nodes
  FLAGS=("${FLAGS[@]/-DGGML_NATIVE=ON/-DGGML_NATIVE=OFF}")
  FLAGS+=(-DGGML_BACKEND_DL=ON -DGGML_CPU_ALL_VARIANTS=ON -DBUILD_SHARED_LIBS=ON)
fi
# Extra flags for your own experiment, e.g. EXTRA_CMAKE_FLAGS="-DGGML_CPU_REPACK=OFF"
# shellcheck disable=SC2206
FLAGS+=(${EXTRA_CMAKE_FLAGS:-})

cmake -B "$BUILD_DIR" "${FLAGS[@]}"
cmake --build "$BUILD_DIR" --config Release -j "$JOBS" --target \
  llama-bench llama-perplexity llama-completion llama-quantize llama-tokenize llama-simple

# --- build record (goes into the hardware/setup section of the report)
MACHINE="${P1_MACHINE:-$(python3 -c "import yaml,platform;c=yaml.safe_load(open('$CFG'));print(c.get('machine') or platform.node().split('.')[0])" 2>/dev/null || hostname -s)}"
OUT="$REPO/results/$MACHINE"; mkdir -p "$OUT"
{
  echo "date: $(date -Iseconds)"
  echo "llama.cpp commit: $(git rev-parse HEAD)"
  echo "patches: $PATCHES"
  echo "git status (should only show the patched file):"; git status --short | sed 's/^/  /'
  echo "cmake flags: ${FLAGS[*]}"
  echo "compiler: $(grep -E '^CMAKE_C_COMPILER:' "$BUILD_DIR/CMakeCache.txt" | cut -d= -f2) $( ($(grep -E '^CMAKE_C_COMPILER:' "$BUILD_DIR/CMakeCache.txt" | cut -d= -f2) --version | head -1) 2>/dev/null)"
  echo "ggml cpu variant / features (from llama-bench --version):"
  "./$BUILD_DIR/bin/llama-bench" --version 2>&1 | sed 's/^/  /'
} > "$OUT/build_info.txt"
echo "== done. Build record: $OUT/build_info.txt"
