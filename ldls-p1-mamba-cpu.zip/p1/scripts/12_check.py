#!/usr/bin/env python3
"""Check every requirement of the Project 1 brief against the files in the repo and write
results/<machine>/REQUIREMENTS.md (PASS / MISSING / WARN per item, grouped by the grading components).
Run it before submitting. Exit code 1 if any required item is missing."""
import json
import math
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import common as C  # noqa: E402

ROWS = []


def check(component, req, ok, evidence="", warn_only=False):
    ROWS.append((component, req, "PASS" if ok else ("WARN" if warn_only else "MISSING"), evidence))


def resolve(points, max_ctx):
    return sorted({max_ctx if p == "max" else int(p) for p in points if p == "max" or int(p) <= max_ctx})


def main():
    cfg = C.load_config()
    d = C.machine_dir(cfg)
    T = C.cpu_topology(cfg).perf_cores
    reps = int(cfg["sweep"]["reps"])
    S = "Setup & correctness (15%)"
    # ---------------------------------------------------------------- setup + correctness
    bi = d / "build_info.txt"
    check(S, "llama.cpp built CPU-only at the pinned commit", bi.exists() and cfg["llama_cpp"]["commit"] in bi.read_text(),
          "build_info.txt" if bi.exists() else "run scripts/00_build_llamacpp.sh")
    hwp = d / "hardware.json"
    hw = json.loads(hwp.read_text()) if hwp.exists() else {}
    check(S, "hardware record: CPU, core types/count, caches, SIMD, RAM",
          bool(hw.get("cpu_model")) and bool(hw.get("caches")) and any(hw.get("simd", {}).values()) and hw.get("ram_total_gb", 0) > 0,
          "hardware.json")
    check(S, "RAM type/speed and theoretical peak bandwidth filled in",
          bool(hw) and "FILL IN" not in str(hw.get("ram_detail", "FILL IN")) and cfg.get("theoretical_peak_bw_gbs"),
          "set theoretical_peak_bw_gbs in the config; RAM speed from Task Manager / dmidecode", warn_only=True)
    st = C.read_csv(d / "stream.csv")
    check(S, f"memory bandwidth measured with STREAM (validated, >= {reps} runs at {T} threads)",
          sum(1 for r in st if int(r["threads"]) == T and r["validates"] == "True") >= reps, "stream.csv")
    check(S, "model files checksummed", (d / "checksums.sha256").exists(), "checksums.sha256", warn_only=bool(cfg.get("synthetic")))
    ppl = C.read_csv(d / "correctness" / "perplexity.csv")
    want = set(cfg["perplexity"]["models"])
    got = {r["model"] for r in ppl if r["ppl"] not in ("", "nan") and math.isfinite(float(r["ppl"]))}
    check(S, "perplexity on a fixed text sample for every model", want <= got, f"{len(got)}/{len(want)} models")
    cons = C.read_csv(d / "correctness" / "consistency.csv")
    prompts = {r["prompt"] for r in cons}
    check(S, "sample outputs on >= 3 DIFFERENT prompts", len(prompts) >= 3, f"{len(prompts)} distinct prompts")
    check(S, "batch-prefill == token-by-token check (recurrent state)", bool(cons) and all(r["identical"] == "True" for r in cons),
          f"{sum(r['identical'] == 'True' for r in cons)}/{len(cons)} identical", warn_only=True)
    # ---------------------------------------------------------------- sweeps
    W = "Benchmark sweeps (25%)"
    sw = [r for r in C.read_csv(d / "raw" / "sweep.csv")]
    ok = [r for r in sw if r["status"] == "ok"]
    n_ok = lambda **k: sum(1 for r in ok if all(str(r[a]) == str(b) for a, b in k.items()))
    for m in cfg["models"]:
        if m.get("role") != "contrast":
            pts = resolve(cfg["sweep"]["prefill"], m["max_ctx"])
            miss = [p for p in pts if n_ok(sweep="prefill", model=m["id"], n_prompt=p, threads=T) < reps]
            check(W, f"{m['label']}: prefill at {pts} x{reps}", not miss, f"missing {miss}" if miss else "raw/sweep.csv")
        pts = resolve(cfg["sweep"]["decode_ctx"], m["max_ctx"])
        miss = [L for L in pts if n_ok(sweep="decode", model=m["id"], ctx=L, threads=T) < reps]
        check(W, f"{m['label']}: decode at context {pts} x{reps}", not miss, f"missing {miss}" if miss else "raw/sweep.csv")
    check(W, "peak RSS recorded for every run", bool(ok) and all(r["peak_rss_gb"] not in ("", "0", "0.0") for r in ok), f"{len(ok)} runs")
    over = [r for r in ok if float(r["peak_rss_gb"] or 0) > float(cfg["memory_budget_gb"])]
    check(W, f"every run within the {cfg['memory_budget_gb']} GB budget", not over, f"{len(over)} over budget")
    flagged = [r for r in sw if r["status"] in ("swapped", "memory_pressure")]
    check(W, "runs that swapped were flagged and rerun", all(n_ok(sweep=r["sweep"], model=r["model"], n_prompt=r["n_prompt"],
          depth=r["depth"], threads=r["threads"]) >= 1 for r in flagged), f"{len(flagged)} flagged")
    ts = cfg.get("thread_scaling", {})
    for mid in ts.get("models", []):
        if not C.model_by_id(cfg, mid)["_path"].exists() and not cfg.get("synthetic"):
            continue
        miss = [t for t in range(1, T + 1) for kind in ("pp", "tg")
                if sum(1 for r in ok if r["sweep"] == "scaling" and r["model"] == mid and int(r["threads"]) == t
                       and ((int(r["n_prompt"]) > 0) == (kind == "pp"))) < reps]
        check(W, f"thread scaling 1..{T} (pp and tg) for {mid}", not miss, f"missing threads {sorted(set(miss))}" if miss else "")
    q8 = [m for m in cfg["models"] if m.get("quant") == "Q8_0"]
    check(W, "quantization rule: Q8_0 only for models <= 1.5B, no F16", all(float(m["params_b"]) <= 1.5 for m in q8)
          and not any("F16" in str(m.get("quant", "")).upper() for m in cfg["models"]), f"{len(q8)} Q8_0 models")
    check(W, "laptop hygiene recorded (preflight before sweeps)", any((d / "preflight").glob("sweep_*.json")), "preflight/")
    # ---------------------------------------------------------------- profiling + roofline
    P = "Profiling & roofline (25%)"
    prof = C.read_csv(d / "profile" / "summary.csv")
    for mid in cfg["profile"]["models"]:
        phases = {r["phase"] for r in prof if r["model"] == mid}
        if C.model_by_id(cfg, mid)["_path"].exists():
            check(P, f"per-operator breakdown, prefill and decode: {mid}", {"prefill", "decode"} <= phases, "profile/summary.csv")
    check(P, "top-3 operators per phase listed", (d / "profile" / "summary.md").exists() and "Top-3" in (d / "profile" / "summary.md").read_text(),
          "profile/summary.md")
    check(P, "external profiler cross-check (perf / VTune / Instruments)", any((d / "profile").glob("perf_*")) or any((d / "profile").glob("*vtune*")),
          "07_profile.py --perf (Linux) or docs/PLATFORMS.md", warn_only=True)
    pred = C.read_csv(d / "predictions.csv")
    first_run = min((r["time"] for r in sw), default="9999")
    pred_time = min((r["predicted_at"] for r in pred), default="9999")
    check(P, "decode prediction (bandwidth / bytes per token) made BEFORE the sweep", bool(pred) and pred_time <= first_run,
          f"predicted {pred_time[:19]} vs first run {first_run[:19]}")
    joined = {(r["model"], r["ctx"]) for r in pred if r["scaling"] == "0"} & {(r["model"], r["ctx"]) for r in ok if r["sweep"] == "decode"}
    check(P, "predicted vs measured decode compared", len(joined) > 0, f"{len(joined)} points")
    check(P, "SSM_SCAN operator study (Mamba-1 vs Mamba-2, prefill and decode)", (d / "ssm_scan_bench.csv").exists(),
          "make scan", warn_only=True)
    # ---------------------------------------------------------------- experiment
    E = "Own experiment (15%)"
    ep = C.read_csv(d / "experiment_prediction.csv")
    ex = [r for r in C.read_csv(d / "raw" / "experiment.csv") if r["status"] == "ok"]
    check(E, "prediction written before the experiment runs", bool(ep) and bool(ex) and min(r["predicted_at"] for r in ep) <= min(r["time"] for r in ex),
          "experiment_prediction.csv")
    miss = [(r["model"], r["ubatch"]) for r in ep if sum(1 for x in ex if x["model"] == r["model"] and x["variant"] == f"ub{r['ubatch']}") < reps]
    check(E, f"every experiment point measured x{reps}", bool(ep) and not miss, f"missing {miss[:4]}" if miss else "raw/experiment.csv")
    # ---------------------------------------------------------------- report + talk
    R = "Report & talk (20%)"
    pl = C.PLOTS / cfg["_machine"]
    for name in ("decode_vs_context", "prefill_vs_prompt", "thread_scaling", "op_breakdown", "predicted_vs_measured"):
        check(R, f"required plot: {name}", (pl / f"{name}.png").exists(), f"plots/{cfg['_machine']}/{name}.png")
    check(R, "SUMMARY.md with every number (and the slide-number list)", (d / "SUMMARY.md").exists(), "11_summary.py")
    pdf = C.REPO / "report" / "report.pdf"
    pages = None
    if pdf.exists():
        m = re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True).stdout)
        pages = int(m.group(1)) if m else None
    check(R, "4-page report (report/report.pdf)", pdf.exists() and (pages is None or pages <= 4), f"{pages} pages" if pages else "not yet",
          warn_only=True)
    check(R, "10-minute talk slides (report/slides.pdf or .pptx)", any((C.REPO / "report").glob("slides.*")), "report/", warn_only=True)
    check(R, "README lets another team rerun everything", (C.REPO / "README.md").exists(), "README.md")
    rudra = sorted(C.RESULTS.glob("rudra-*/reference/reference.md"))
    laps = [p for p in C.RESULTS.glob("*/reference/reference.md") if not p.parts[-3].startswith("rudra")]
    check("Shared reference", "PARAM Rudra reference run (Llama-3.2-1B Q4_K_M, pp512 + tg128)", bool(rudra),
          "scripts/09_rudra_prepare.sh, then sbatch scripts/09_rudra_reference.sbatch", warn_only=True)
    if not rudra:
        check("Shared reference", "fallback: same fixed test on our laptops + logged Rudra attempts",
              bool(laps) and (C.RESULTS / "rudra-attempts.md").exists(),
              f"{len(laps)} laptop run(s); attempts log {'present' if (C.RESULTS / 'rudra-attempts.md').exists() else 'missing (scripts/09_rudra_log.sh)'}",
              warn_only=True)
    check("Shared reference", "second machine for the cross-machine roofline check (make second, make compare)",
          (C.RESULTS / "COMPARE.md").exists(), "results/COMPARE.md", warn_only=True)
    # ---------------------------------------------------------------- bonus
    bd = C.REPO / "bonus" / "mamba3" / "results" / cfg["_machine"]
    log = (bd / "test_step.log").read_text() if (bd / "test_step.log").exists() else ""
    check("Bonus (up to 50%)", "correct SISO kernel (1000 steps vs official reference, scalar + SIMD)",
          log.count("mamba3-siso") >= 2 and "FAIL" not in log, "test_step.log", warn_only=True)
    om = (bd / "official_module_cpu.log").read_text() if (bd / "official_module_cpu.log").exists() else ""
    check("Bonus (up to 50%)", "official Mamba3.step module code run on CPU (step 2), matches the traces (SISO + MIMO)",
          om.count("PASS") >= 2 and "FAIL" not in om, "official_module_cpu.log", warn_only=True)
    check("Bonus (up to 50%)", "optional: same question on our GPU (official kernels)", any(C.REPO.glob("bonus/mamba3/results/*/gpu/gpu_step.csv")),
          "bonus/mamba3/gpu/run_gpu.sh", warn_only=True)
    check("Bonus (up to 50%)", "correct MIMO kernel, rank 4", "mamba3-mimo R=4" in log and "FAIL" not in log, "test_step.log", warn_only=True)
    check("Bonus (up to 50%)", "MIMO question answered with measurements", (bd / "ANSWER.md").exists(), "ANSWER.md", warn_only=True)
    check("Bonus (up to 50%)", "stretch: kernel as a ggml operator in a ggml graph", "ggml-graph" in ((bd / "ggml_op_test.log").read_text()
          if (bd / "ggml_op_test.log").exists() else ""), "ggml_op_test.log", warn_only=True)
    # ---------------------------------------------------------------- write
    lines = [f"# Requirements check: {cfg['title']} ({cfg['_machine']}, {C.now_iso()})\n",
             "| component | requirement (from the brief) | status | evidence |", "|---|---|---|---|"]
    lines += [f"| {c} | {r} | **{s}** | {e} |" for c, r, s, e in ROWS]
    n_miss = sum(1 for x in ROWS if x[2] == "MISSING")
    lines.append(f"\n{sum(1 for x in ROWS if x[2] == 'PASS')} PASS, {sum(1 for x in ROWS if x[2] == 'WARN')} WARN, {n_miss} MISSING")
    (d / "REQUIREMENTS.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    sys.exit(1 if n_miss else 0)


if __name__ == "__main__":
    main()
