"""Shared helpers for the Project 1 benchmark harness.

Everything that touches the operating system lives here so that the numbered
scripts stay short: config loading, platform detection (Linux / WSL2 / macOS),
performance-core detection, and `run_measured`, which runs one benchmark
process and returns its own peak RSS (via wait4) plus any swap activity that
happened while it ran.
"""
from __future__ import annotations

import csv
import datetime as _dt
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
RESULTS = REPO / "results"
PLOTS = REPO / "plots"


# --------------------------------------------------------------------------- config
def load_config(path: str | os.PathLike | None = None) -> dict:
    import yaml  # PyYAML, listed in requirements.txt

    path = Path(path or os.environ.get("P1_CONFIG", REPO / "config" / "option3.yaml"))
    if not path.is_absolute():
        path = REPO / path
    with open(path) as f:
        cfg = yaml.safe_load(f)
    cfg["_path"] = str(path)
    llama_dir = os.environ.get("LLAMA_CPP_DIR") or cfg["llama_cpp"]["dir"]
    llama_dir = Path(llama_dir)
    if not llama_dir.is_absolute():
        llama_dir = (REPO / llama_dir).resolve()
    cfg["_llama_dir"] = llama_dir
    cfg["_bin"] = Path(os.environ.get("LLAMA_BIN_DIR", llama_dir / "build" / "bin"))
    cfg["_machine"] = os.environ.get("P1_MACHINE") or cfg.get("machine") or platform.node().split(".")[0]
    for m in cfg.get("models", []):
        p = Path(m["file"])
        m["_path"] = p if p.is_absolute() else (REPO / p)
    return cfg


def model_by_id(cfg: dict, mid: str) -> dict:
    for m in cfg["models"]:
        if m["id"] == mid:
            return m
    raise KeyError(f"model id '{mid}' not in config {cfg['_path']}")


def binary(cfg: dict, name: str) -> Path:
    exe = cfg["_bin"] / (name + (".exe" if os.name == "nt" else ""))
    if not exe.exists():
        sys.exit(f"[error] {exe} not found. Run scripts/00_build_llamacpp.sh first (or set LLAMA_BIN_DIR).")
    return exe


def machine_dir(cfg: dict, *parts: str) -> Path:
    """results/<machine>/<parts...> (created)."""
    d = RESULTS / cfg["_machine"]
    for p in parts:
        d = d / p
    d.mkdir(parents=True, exist_ok=True)
    return d


def now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def git_rev(path: Path) -> str:
    try:
        return subprocess.run(["git", "-C", str(path), "rev-parse", "HEAD"], capture_output=True,
                              text=True, check=True).stdout.strip()
    except Exception:
        return "unknown"


# --------------------------------------------------------------------------- platform
def is_macos() -> bool:
    return sys.platform == "darwin"


def is_wsl() -> bool:
    try:
        return "microsoft" in Path("/proc/version").read_text().lower()
    except OSError:
        return False


def sh(cmd: str, timeout: float = 20) -> str:
    """Run a shell command, return stdout ('' on any failure)."""
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip()
    except Exception:
        return ""


def sysctl(name: str) -> str:
    return sh(f"sysctl -n {name} 2>/dev/null")


def _parse_cpu_list(s: str) -> list[int]:
    out: list[int] = []
    for part in s.strip().split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-")
            out.extend(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return out


def linux_core_map() -> dict[int, tuple[int, int]]:
    """logical cpu -> (package id, core id), from sysfs."""
    m: dict[int, tuple[int, int]] = {}
    for d in sorted(Path("/sys/devices/system/cpu").glob("cpu[0-9]*")):
        try:
            cpu = int(d.name[3:])
            core = int((d / "topology" / "core_id").read_text())
            pkg = int((d / "topology" / "physical_package_id").read_text())
            m[cpu] = (pkg, core)
        except (OSError, ValueError):
            continue
    return m


@dataclass
class CpuTopo:
    logical: int
    physical: int
    perf_cores: int                 # physical performance cores
    eff_cores: int                  # physical efficiency cores (0 if not hybrid / unknown)
    hybrid: str                     # "no", "yes", "unknown (WSL2 hides core types)"
    perf_cpu_list: list[int] = field(default_factory=list)  # one logical cpu per P-core (Linux only)
    note: str = ""


def cpu_topology(cfg: dict | None = None) -> CpuTopo:
    """Detect P-cores. Config values `threads.perf_cores` / `threads.cpu_list` override detection."""
    logical = os.cpu_count() or 1
    over = (cfg or {}).get("threads", {}) if cfg else {}
    if is_macos():
        p = int(sysctl("hw.perflevel0.physicalcpu") or sysctl("hw.physicalcpu") or logical)
        e = int(sysctl("hw.perflevel1.physicalcpu") or 0)
        topo = CpuTopo(logical, int(sysctl("hw.physicalcpu") or p), p, e, "yes" if e else "no", [],
                       "macOS has no thread-affinity API; the scheduler keeps busy threads on P-cores")
    else:
        cmap = linux_core_map()
        phys = len(set(cmap.values())) or logical
        first_cpu_of_core: dict[tuple[int, int], int] = {}
        for cpu, key in sorted(cmap.items()):
            first_cpu_of_core.setdefault(key, cpu)
        core_dev = Path("/sys/devices/cpu_core/cpus")
        atom_dev = Path("/sys/devices/cpu_atom/cpus")
        if core_dev.exists():  # Intel hybrid on native Linux
            pcpus = set(_parse_cpu_list(core_dev.read_text()))
            ecpus = set(_parse_cpu_list(atom_dev.read_text())) if atom_dev.exists() else set()
            pcores = {cmap[c] for c in pcpus if c in cmap}
            ecores = {cmap[c] for c in ecpus if c in cmap}
            plist = sorted(first_cpu_of_core[k] for k in pcores)
            topo = CpuTopo(logical, phys, len(pcores), len(ecores), "yes", plist)
        else:
            plist = sorted(first_cpu_of_core.values())
            hyb = "no"
            note = ""
            if is_wsl():
                model = sh("lscpu | sed -n 's/^Model name:[ \\t]*//p'")
                if re.search(r"(1[2-9]th Gen|Core\(TM\) Ultra|Core Ultra)", model):
                    hyb = "unknown (WSL2 hides core types)"
                    note = ("Intel hybrid CPU under WSL2: Linux cannot see which vCPUs are P-cores. "
                            "Set threads.perf_cores in the config to the P-core count and read docs/PLATFORMS.md.")
            topo = CpuTopo(logical, phys, phys, 0, hyb, plist, note)
    if over.get("perf_cores") not in (None, "auto"):
        topo.perf_cores = int(over["perf_cores"])
        topo.perf_cpu_list = topo.perf_cpu_list[: topo.perf_cores]
    if over.get("cpu_list") not in (None, "auto"):
        topo.perf_cpu_list = [] if over["cpu_list"] == "none" else _parse_cpu_list(str(over["cpu_list"]))
    return topo


def taskset_prefix(topo: CpuTopo) -> list[str]:
    """Restrict a run to the P-cores (Linux only, needs util-linux taskset)."""
    if is_macos() or not topo.perf_cpu_list or not shutil.which("taskset"):
        return []
    if len(topo.perf_cpu_list) >= (os.cpu_count() or 1):
        return []
    return ["taskset", "-c", ",".join(map(str, topo.perf_cpu_list))]


# --------------------------------------------------------------------------- memory / swap
def mem_available_gb() -> float:
    if is_macos():
        pagesize = int(sysctl("hw.pagesize") or 16384)
        vm = sh("vm_stat")
        free = 0
        for key in ("Pages free", "Pages inactive", "Pages speculative", "Pages purgeable"):
            m = re.search(rf"{key}:\s+(\d+)", vm)
            if m:
                free += int(m.group(1))
        return free * pagesize / 1e9
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) * 1024 / 1e9
    except OSError:
        pass
    return float("nan")


def swap_counters() -> tuple[int, int]:
    """(pages swapped in, pages swapped out) since boot."""
    if is_macos():
        vm = sh("vm_stat")
        i = re.search(r"Swapins:\s+(\d+)", vm)
        o = re.search(r"Swapouts:\s+(\d+)", vm)
        return (int(i.group(1)) if i else 0, int(o.group(1)) if o else 0)
    try:
        d = dict(l.split() for l in Path("/proc/vmstat").read_text().splitlines() if l.startswith("psw"))
        return int(d.get("pswpin", 0)), int(d.get("pswpout", 0))
    except OSError:
        return 0, 0


def cpu_freq_mhz() -> float:
    """Mean current frequency over all cpus (Linux sysfs). NaN where not exposed (WSL2, macOS)."""
    vals = []
    for f in Path("/sys/devices/system/cpu").glob("cpu[0-9]*/cpufreq/scaling_cur_freq"):
        try:
            vals.append(int(f.read_text()) / 1000)
        except (OSError, ValueError):
            pass
    return sum(vals) / len(vals) if vals else float("nan")


def cpu_temp_c() -> float:
    best = float("nan")
    for z in Path("/sys/class/thermal").glob("thermal_zone*"):
        try:
            kind = (z / "type").read_text().strip().lower()
            if any(k in kind for k in ("x86_pkg", "cpu", "tctl", "k10temp", "coretemp", "acpitz")):
                t = int((z / "temp").read_text()) / 1000
                best = t if best != best else max(best, t)
        except (OSError, ValueError):
            pass
    return best


@dataclass
class RunResult:
    returncode: int
    stdout: str
    stderr: str
    wall_s: float
    peak_rss_gb: float
    major_faults: int
    swap_in: int
    swap_out: int
    freq_before: float
    freq_after: float
    temp_before: float
    temp_after: float

    @property
    def swapped(self) -> bool:
        return (self.swap_in + self.swap_out) > 0


def run_measured(cmd: list[str], env: dict | None = None, log_prefix: Path | None = None,
                 timeout: float | None = None) -> RunResult:
    """Run one benchmark process; return its own peak RSS (wait4) and swap activity.

    stdout/stderr go to files (avoids pipe deadlocks with long verbose logs) and are
    read back afterwards. Peak RSS is ru_maxrss of *this* child only.
    """
    full_env = dict(os.environ)
    if env:
        full_env.update({k: str(v) for k, v in env.items()})
    tmpdir = Path(log_prefix).parent if log_prefix else RESULTS / "_tmp"
    tmpdir.mkdir(parents=True, exist_ok=True)
    stem = Path(log_prefix).name if log_prefix else f"run_{os.getpid()}_{time.time_ns()}"
    out_p, err_p = tmpdir / f"{stem}.stdout", tmpdir / f"{stem}.stderr"
    sw0 = swap_counters()
    f0, t0c = cpu_freq_mhz(), cpu_temp_c()
    t0 = time.perf_counter()
    with open(out_p, "w") as fo, open(err_p, "w") as fe:
        p = subprocess.Popen(cmd, stdout=fo, stderr=fe, env=full_env)
        deadline = None if timeout is None else time.time() + timeout
        while True:
            pid, status, ru = os.wait4(p.pid, os.WNOHANG)
            if pid != 0:
                break
            if deadline and time.time() > deadline:
                p.kill()
                pid, status, ru = os.wait4(p.pid, 0)
                break
            time.sleep(0.05)
    wall = time.perf_counter() - t0
    sw1 = swap_counters()
    rc = os.waitstatus_to_exitcode(status)
    p.returncode = rc
    # ru_maxrss: kilobytes on Linux, bytes on macOS
    rss_bytes = ru.ru_maxrss if is_macos() else ru.ru_maxrss * 1024
    stdout, stderr = out_p.read_text(errors="replace"), err_p.read_text(errors="replace")
    if not log_prefix:
        out_p.unlink(missing_ok=True)
        err_p.unlink(missing_ok=True)
    return RunResult(rc, stdout, stderr, wall, rss_bytes / 1e9, ru.ru_majflt,
                     sw1[0] - sw0[0], sw1[1] - sw0[1], f0, cpu_freq_mhz(), t0c, cpu_temp_c())


# --------------------------------------------------------------------------- llama-bench helpers
_BUF_PATTERNS = {   # llama.cpp -v log lines (llama-model.cpp, llama-kv-cache.cpp, llama-memory-recurrent.cpp, llama-context.cpp)
    "model_buf_mib": re.compile(r"\S+ model buffer size\s*=\s*([\d.]+) MiB"),
    "kv_buf_mib": re.compile(r"KV buffer size\s*=\s*([\d.]+) MiB"),
    "rs_buf_mib": re.compile(r"RS buffer size\s*=\s*([\d.]+) MiB"),
    "compute_buf_mib": re.compile(r"\S+ compute buffer size\s*=\s*([\d.]+) MiB"),
}


def parse_buffers(stderr: str) -> dict[str, float]:
    """Memory breakdown llama.cpp logs with -v: model weights, KV cache, recurrent state, compute buffers (MiB)."""
    out = {}
    for key, pat in _BUF_PATTERNS.items():
        vals = [float(x) for x in pat.findall(stderr)]
        out[key] = round(sum(vals), 2) if vals else 0.0
    return out


def parse_bench_jsonl(stdout: str) -> list[dict]:
    rows = []
    for line in stdout.splitlines():
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return rows


# --------------------------------------------------------------------------- csv
def append_csv(path: Path, row: dict, fields: list[str]) -> None:
    new = not path.exists()
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        if new:
            w.writeheader()
        w.writerow(row)


def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def log(msg: str) -> None:
    print(f"[{_dt.datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)
