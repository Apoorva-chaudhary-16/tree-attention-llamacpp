"""Laptop-hygiene checks from the course rules, recorded as evidence with every sweep.

  * charger plugged in, performance power mode
  * browser and IDE closed (checks Linux/macOS processes, and Windows processes when under WSL2)
  * enough free memory for the largest planned run (+0.5 GB margin)
  * Intel hybrid: run on performance cores only (taskset on native Linux; see docs/PLATFORMS.md)
"""
from __future__ import annotations

import json
import re

import common as C

HEAVY = ["chrome", "chromium", "firefox", "msedge", "brave", "opera", "safari", "code", "code-oss", "cursor",
         "idea", "pycharm", "clion", "webstorm", "slack", "teams", "ms-teams", "zoom", "discord", "spotify",
         "steam", "obs", "onedrive", "dropbox", "googledrivesync"]

# Windows 11 power-mode overlay GUIDs (Settings > System > Power > Power mode)
WIN_OVERLAY = {"ded574b5-45a0-4f42-8737-46345c09c238": "Best performance",
               "00000000-0000-0000-0000-000000000000": "Balanced",
               "961cc777-2547-4f9d-8174-7d86181b8a7a": "Best power efficiency"}


def _proc_names() -> list[str]:
    names = C.sh("ps -Ao comm=").lower().splitlines()
    if C.is_wsl():
        win = C.sh("tasklist.exe /FO CSV /NH 2>/dev/null", timeout=30).lower()
        names += [l.split(",")[0].strip('"').removesuffix(".exe") for l in win.splitlines() if l]
    return [n.strip().split("/")[-1] for n in names if n.strip()]


def power_mode() -> tuple[str, bool]:
    """(description, ok)"""
    if C.is_macos():
        pm = C.sh("pmset -g")
        low = re.search(r"lowpowermode\s+(\d)", pm)
        mode = re.search(r"powermode\s+(\d)", pm)
        desc = f"lowpowermode={low.group(1) if low else '?'} powermode={mode.group(1) if mode else 'n/a'}"
        return desc, not (low and low.group(1) == "1")
    if C.is_wsl():
        q = C.sh('reg.exe query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\User\\PowerSchemes" '
                 '/v ActiveOverlayAcPowerScheme 2>/dev/null', timeout=30)
        m = re.search(r"([0-9a-f]{8}-[0-9a-f-]{27})", q.lower())
        overlay = WIN_OVERLAY.get(m.group(1), m.group(1)) if m else "unknown"
        scheme = C.sh("powercfg.exe /getactivescheme 2>/dev/null", timeout=30).strip()
        return f"Windows power mode (on AC): {overlay}; plan: {scheme}", overlay == "Best performance"
    prof = C.sh("cat /sys/firmware/acpi/platform_profile 2>/dev/null") or C.sh("powerprofilesctl get 2>/dev/null")
    gov = C.sh("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null")
    desc = f"platform_profile={prof or 'n/a'} governor={gov or 'n/a'}"
    ok = not prof or prof in ("performance", "balanced-performance")
    if gov and gov in ("powersave",) and not prof:
        ok = False
    return desc, ok


def on_ac() -> bool | None:
    if C.is_macos():
        return "AC Power" in C.sh("pmset -g batt")
    if C.is_wsl():
        st = C.sh('powershell.exe -NoProfile -Command "(Get-CimInstance Win32_Battery).BatteryStatus" 2>/dev/null',
                  timeout=30).strip()
        return None if not st else st == "2"
    from pathlib import Path
    for d in Path("/sys/class/power_supply").glob("*"):
        try:
            if (d / "type").read_text().strip() == "Mains":
                return (d / "online").read_text().strip() == "1"
        except OSError:
            pass
    return None


def run(cfg: dict, need_gb: float, out_name: str) -> dict:
    topo = C.cpu_topology(cfg)
    procs = _proc_names()
    heavy = sorted({h for h in HEAVY for p in procs if p == h or p.startswith(h + " ") or p.startswith(h + "-")
                    or p == h + ".exe" or (len(h) > 4 and h in p)})
    pm_desc, pm_ok = power_mode()
    ac = on_ac()
    free = C.mem_available_gb()
    gpu_apps = [l.strip() for l in C.sh("nvidia-smi --query-compute-apps=process_name --format=csv,noheader 2>/dev/null").splitlines()
                if l.strip() and "No running" not in l and "Not Supported" not in l]
    checks = {
        "on_ac_power": {"value": ac, "ok": ac is not False,
                        "fix": "plug in the charger" if ac is False else ""},
        "power_mode": {"value": pm_desc, "ok": pm_ok,
                       "fix": "" if pm_ok else "set performance / 'Best performance' power mode"},
        "free_memory_gb": {"value": round(free, 2), "need": round(need_gb, 2), "ok": free >= need_gb,
                           "fix": "" if free >= need_gb else "close applications (see background_apps)"},
        "background_apps": {"value": heavy, "ok": not heavy,
                            "fix": "" if not heavy else "close: " + ", ".join(heavy)},
        "perf_cores": {"value": topo.perf_cores, "hybrid": topo.hybrid, "cpu_list": topo.perf_cpu_list,
                       "ok": topo.hybrid in ("no", "yes"), "fix": topo.note},
        "gpu_idle": {"value": gpu_apps, "ok": not gpu_apps,
                     "fix": "" if not gpu_apps else "stop GPU jobs during CPU sweeps (CPU and GPU share the power limit)"},
        "cpu_temp_c": {"value": C.cpu_temp_c(), "ok": True},
        "cpu_freq_mhz": {"value": C.cpu_freq_mhz(), "ok": True},
    }
    rec = {"time": C.now_iso(), "machine": cfg["_machine"], "checks": checks,
           "all_ok": all(v["ok"] for v in checks.values())}
    d = C.machine_dir(cfg, "preflight")
    (d / f"{out_name}.json").write_text(json.dumps(rec, indent=2, default=str))
    for k, v in checks.items():
        flag = "ok " if v["ok"] else "!! "
        extra = f"  -> {v['fix']}" if v.get("fix") else ""
        C.log(f"preflight {flag}{k}: {v['value']}{extra}")
    return rec
