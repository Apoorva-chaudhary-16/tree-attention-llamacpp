"""Run llama-bench one repetition at a time and record everything about each run.

A *spec* is one benchmark configuration; a *run* is one repetition of a spec in a fresh process.
Fresh processes make the 3 repetitions independent and give each run its own peak RSS. Runs are
interleaved by repetition (rep 1 of every spec, then rep 2, ...) so slow drift such as heat build-up
spreads over all configurations instead of biasing whichever ran last.
"""
from __future__ import annotations

import random
import time
from dataclasses import dataclass, field
from pathlib import Path

import common as C

RAW_FIELDS = ["time", "machine", "sweep", "variant", "model", "label", "n_prompt", "n_gen", "depth", "ctx",
              "threads", "rep", "status", "tps", "time_s", "peak_rss_gb", "model_buf_mib", "kv_buf_mib",
              "rs_buf_mib", "compute_buf_mib", "swapped", "swap_in", "swap_out", "major_faults", "wall_s",
              "freq_mhz_before", "freq_mhz_after", "temp_c_before", "temp_c_after", "warmup", "flash_attn",
              "type_k", "type_v", "n_ubatch", "model_size_bytes", "build_commit", "cmd"]


@dataclass
class Spec:
    sweep: str            # prefill | decode | scaling | experiment | reference | profile
    model: dict
    n_prompt: int
    n_gen: int
    depth: int
    threads: int
    variant: str = "base"
    extra_args: list = field(default_factory=list)
    env: dict = field(default_factory=dict)

    @property
    def ctx(self) -> int:
        return self.n_prompt + self.n_gen + self.depth

    def key(self, rep: int) -> str:
        return (f"{self.sweep}|{self.variant}|{self.model['id']}|{self.n_prompt}|{self.n_gen}|{self.depth}|"
                f"{self.threads}|{rep}")

    def name(self) -> str:
        what = f"pp{self.n_prompt}" if self.n_prompt else f"tg{self.n_gen}@d{self.depth}"
        return f"{self.model['id']} {what} t={self.threads} [{self.variant}]"


def _pred_row(cfg: dict, model: dict) -> dict | None:
    for r in C.read_csv(C.machine_dir(cfg) / "predictions.csv"):
        if r["model"] == model["id"]:
            return r
    return None


def predicted_mem_gb(cfg: dict, spec: "Spec") -> float:
    """Model file + KV cache at this context (transformer) or the constant recurrent state (Mamba) + buffers."""
    model_gb = spec.model["_path"].stat().st_size / 1e9 if spec.model["_path"].exists() else 0
    r = _pred_row(cfg, spec.model)
    if spec.model.get("family", "llama") in ("mamba", "mamba2"):
        state = float(r["state_bytes"]) / 1e9 if r else 0.12
        return model_gb + state + 0.45
    kv_tok = float(r["kv_bytes_per_ctx_token"]) if r else 0.12e6
    kv = kv_tok * spec.ctx / 1e9
    if any(a in ("q8_0", "q4_0") for a in spec.extra_args):
        kv *= 0.55
    return model_gb + kv + 0.45


def warmup_needed(spec: Spec) -> bool:
    """llama-bench's warmup repeats the whole prompt. Skip it where the untimed depth prefill already
    warms caches/threads (decode at depth), or the timed prompt is long enough that first-touch costs
    are < 1% (pp >= 2048)."""
    if spec.depth > 0:
        return False
    if "-ub" in spec.extra_args and int(spec.extra_args[spec.extra_args.index("-ub") + 1]) <= 16:
        return False   # tiny micro-batches: the run itself is long, a full-prompt warmup would double it
    if spec.n_prompt >= 2048:
        return False
    return True


def build_cmd(cfg: dict, spec: Spec) -> list[str]:
    topo = C.cpu_topology(cfg)
    s = cfg["sweep"]
    cmd = [*C.taskset_prefix(topo), str(C.binary(cfg, "llama-bench")), "-m", str(spec.model["_path"]),
           "-t", str(spec.threads), "-fa", str(s.get("flash_attn", "on")), "-r", "1", "-o", "jsonl", "-v",
           "-p", str(spec.n_prompt), "-n", str(spec.n_gen), "-d", str(spec.depth)]
    if not warmup_needed(spec):
        cmd.append("--no-warmup")
    cmd += [str(a) for a in s.get("common_args", [])] + [str(a) for a in spec.extra_args]
    return cmd


def run_one(cfg: dict, spec: Spec, rep: int, raw_csv: Path, logs_dir: Path) -> dict:
    budget = float(cfg.get("memory_budget_gb", 4.5))
    pred = predicted_mem_gb(cfg, spec)
    base = {"time": C.now_iso(), "machine": cfg["_machine"], "sweep": spec.sweep, "variant": spec.variant,
            "model": spec.model["id"], "label": spec.model["label"], "n_prompt": spec.n_prompt,
            "n_gen": spec.n_gen, "depth": spec.depth, "ctx": spec.ctx, "threads": spec.threads, "rep": rep,
            "warmup": warmup_needed(spec)}
    if pred > budget:
        row = {**base, "status": f"skipped_budget(pred {pred:.2f} GB)"}
        C.append_csv(raw_csv, row, RAW_FIELDS)
        return row
    for wait in range(6):  # wait for memory if something else is holding it
        if C.mem_available_gb() >= pred + 0.3:
            break
        C.log(f"   waiting for free memory ({C.mem_available_gb():.2f} GB free, need {pred + 0.3:.2f})")
        time.sleep(10)
    cmd = build_cmd(cfg, spec)
    retries = int(cfg["sweep"].get("swap_retries", 2))
    for attempt in range(retries + 1):
        tag = f"{spec.sweep}_{spec.variant}_{spec.model['id']}_p{spec.n_prompt}_n{spec.n_gen}_d{spec.depth}_t{spec.threads}_r{rep}"
        r = C.run_measured(cmd, env=spec.env, log_prefix=logs_dir / tag)
        bench = C.parse_bench_jsonl(r.stdout)
        bufs = C.parse_buffers(r.stderr)
        status = "ok"
        if r.returncode != 0 or not bench:
            status = f"error(rc={r.returncode})"
        elif r.swapped:
            status = "swapped"
        elif r.peak_rss_gb > budget:
            status = "over_budget"
        elif r.major_faults > 5000:
            status = "memory_pressure"   # file-backed weight pages were evicted and re-read from disk
        b = bench[0] if bench else {}
        row = {**base, "status": status, "tps": b.get("avg_ts", ""), "time_s": (b.get("avg_ns", 0) or 0) / 1e9,
               "peak_rss_gb": round(r.peak_rss_gb, 4), **{k: v for k, v in bufs.items()},
               "swapped": r.swapped, "swap_in": r.swap_in, "swap_out": r.swap_out, "major_faults": r.major_faults,
               "wall_s": round(r.wall_s, 3), "freq_mhz_before": r.freq_before, "freq_mhz_after": r.freq_after,
               "temp_c_before": r.temp_before, "temp_c_after": r.temp_after,
               "flash_attn": b.get("flash_attn", ""), "type_k": b.get("type_k", ""), "type_v": b.get("type_v", ""),
               "n_ubatch": b.get("n_ubatch", ""), "model_size_bytes": b.get("model_size", ""),
               "build_commit": b.get("build_commit", ""), "cmd": " ".join(cmd)}
        C.append_csv(raw_csv, row, RAW_FIELDS)
        if status in ("swapped", "memory_pressure") and attempt < retries:
            C.log(f"   !! {status}: flagged and rerunning ({attempt + 1}/{retries})")
            time.sleep(5)
            continue
        return row
    return row


def done_keys(raw_csv: Path) -> set[str]:
    keys = set()
    for r in C.read_csv(raw_csv):
        if r["status"] == "ok" or r["status"].startswith("skipped_budget"):
            keys.add(f"{r['sweep']}|{r['variant']}|{r['model']}|{r['n_prompt']}|{r['n_gen']}|{r['depth']}|"
                     f"{r['threads']}|{r['rep']}")
    return keys


def warm_page_cache(models: list[dict]) -> None:
    """Read each model file once so that run 1 does not pay disk reads that later runs do not."""
    for m in models:
        p = m["_path"]
        if p.exists():
            t0 = time.time()
            with open(p, "rb") as f:
                while f.read(16 << 20):
                    pass
            C.log(f"page cache warmed: {p.name} ({p.stat().st_size / 1e9:.2f} GB in {time.time() - t0:.1f} s)")


def run_specs(cfg: dict, specs: list[Spec], raw_csv: Path, reps: int, cooldown: float = 0.0,
              dry_run: bool = False) -> None:
    logs = C.machine_dir(cfg, "logs")
    done = done_keys(raw_csv)
    todo = [(rep, s) for rep in range(1, reps + 1) for s in specs if s.key(rep) not in done]
    C.log(f"{len(specs)} configurations x {reps} reps = {len(specs) * reps} runs; {len(todo)} to do "
          f"(resuming from {raw_csv.name})" if done else f"{len(todo)} runs to do -> {raw_csv}")
    if dry_run:
        for rep, s in todo:
            print(f"  rep {rep}: {s.name()}  ->  {' '.join(build_cmd(cfg, s))}")
        return
    warm_page_cache(list({id(s.model): s.model for _, s in todo}.values()))
    # order: all of rep 1, then rep 2, ...; inside a rep a seeded shuffle (reproducible) so that no
    # configuration always runs right after the heaviest one
    ordered = []
    for rep in range(1, reps + 1):
        group = [x for x in todo if x[0] == rep]
        random.Random(1000 + rep).shuffle(group)
        ordered += group
    t_start = time.time()
    for i, (rep, s) in enumerate(ordered):
        row = run_one(cfg, s, rep, raw_csv, logs)
        el = time.time() - t_start
        eta = el / (i + 1) * (len(todo) - i - 1)
        tps = row.get("tps")
        tps_s = f"{float(tps):8.2f} t/s" if tps not in (None, "") else "      --"
        rss = row.get("peak_rss_gb")
        C.log(f"[{i + 1}/{len(todo)}] rep {rep} {s.name():40s} {tps_s}  RSS {rss if rss not in (None, '') else '-'} GB"
              f"  {row['status']}  (ETA {eta / 60:.0f} min)")
        if cooldown:
            time.sleep(cooldown)
