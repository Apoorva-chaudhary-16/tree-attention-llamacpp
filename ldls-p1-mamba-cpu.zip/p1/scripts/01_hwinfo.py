#!/usr/bin/env python3
"""Record the hardware exactly as the course asks: CPU model, core types and count, cache sizes,
SIMD support (AVX2 / AVX-512 / NEON ...), RAM. Memory bandwidth comes from 02_stream.py and is merged
into the same table by 11_summary.py.

Writes results/<machine>/hardware.json and hardware.md. Fields that cannot be detected on this OS
(e.g. RAM speed inside WSL2) are written as "FILL IN" with the command that tells you the value.
"""
import json
import platform
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import common as C  # noqa: E402

X86_SIMD = ["sse4_2", "avx", "avx2", "fma", "f16c", "avx_vnni", "avx512f", "avx512bw", "avx512vl",
            "avx512_vnni", "avx512_bf16", "avx512_fp16", "amx_tile", "amx_int8"]
ARM_SIMD = ["asimd", "asimddp", "i8mm", "bf16", "sve", "sve2"]
MAC_ARM_FEATS = {"FEAT_DotProd": "dotprod", "FEAT_I8MM": "i8mm", "FEAT_BF16": "bf16",
                 "AdvSIMD": "neon", "FEAT_FP16": "fp16", "FEAT_SME": "sme"}


def linux_caches() -> dict:
    out = {}
    txt = C.sh("lscpu -C --bytes 2>/dev/null")
    for line in txt.splitlines()[1:]:
        parts = line.split()
        if len(parts) >= 3 and parts[0] in ("L1d", "L1i", "L2", "L3"):
            out[parts[0]] = {"per_instance_bytes": int(parts[1]), "total_bytes": int(parts[2])}
    if not out:  # older util-linux
        for k in ("L1d", "L1i", "L2", "L3"):
            m = re.search(rf"^{k} cache:\s+(.+)$", C.sh("lscpu"), re.M)
            if m:
                out[k] = {"text": m.group(1).strip()}
    return out


def linux_info() -> dict:
    lscpu = C.sh("lscpu")
    get = lambda k: (re.search(rf"^{k}:\s+(.+)$", lscpu, re.M) or [None, ""])[1].strip()
    flags = set()
    try:
        cpuinfo = Path("/proc/cpuinfo").read_text()
        m = re.search(r"^(flags|Features)\s*:\s*(.+)$", cpuinfo, re.M)
        flags = set(m.group(2).split()) if m else set()
    except OSError:
        pass
    arch = platform.machine()
    simd = {f: (f in flags) for f in (X86_SIMD if arch in ("x86_64", "AMD64") else ARM_SIMD)}
    mem_total = 0
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemTotal:"):
            mem_total = int(line.split()[1]) * 1024
    swap_total = 0
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("SwapTotal:"):
            swap_total = int(line.split()[1]) * 1024
    ram_detail = "FILL IN"
    dmi = C.sh("sudo -n dmidecode -t memory 2>/dev/null")
    if dmi:
        speeds = sorted(set(re.findall(r"Configured Memory Speed:\s*(\d+ MT/s)", dmi)))
        types = sorted(set(t for t in re.findall(r"^\s*Type:\s*(\S+)", dmi, re.M) if t != "Unknown"))
        nslots = len(re.findall(r"^\s*Size:\s*\d+", dmi, re.M))
        ram_detail = f"{'/'.join(types)} {'/'.join(speeds)}, {nslots} populated module(s)"
    elif C.is_wsl():
        ps = C.sh("powershell.exe -NoProfile -Command \"Get-CimInstance Win32_PhysicalMemory | "
                  "ForEach-Object { \\\"$($_.SMBIOSMemoryType) $($_.ConfiguredClockSpeed) $($_.Capacity)\\\" }\" "
                  "2>/dev/null", timeout=30)
        if ps:
            mods = [l.split() for l in ps.splitlines() if l.strip()]
            tmap = {"26": "DDR4", "34": "DDR5", "35": "LPDDR5", "30": "LPDDR4", "29": "LPDDR3", "24": "DDR3"}
            ram_detail = "; ".join(f"{tmap.get(m[0], 'type ' + m[0])} {m[1]} MT/s {int(m[2]) / 2**30:.0f} GiB"
                                   for m in mods if len(m) == 3)
    return {
        "cpu_model": get("Model name"),
        "arch": arch,
        "sockets": get("Socket\\(s\\)"),
        "threads_per_core": get("Thread\\(s\\) per core"),
        "max_mhz": get("CPU max MHz") or "n/a (not exposed)",
        "caches": linux_caches(),
        "simd": simd,
        "ram_total_gb": round(mem_total / 1e9, 2),
        "swap_total_gb": round(swap_total / 1e9, 2),
        "ram_detail": ram_detail,
        "governor": C.sh("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null") or "n/a",
        "platform_profile": (C.sh("cat /sys/firmware/acpi/platform_profile 2>/dev/null")
                             or C.sh("powerprofilesctl get 2>/dev/null") or "n/a"),
        "no_turbo": C.sh("cat /sys/devices/system/cpu/intel_pstate/no_turbo 2>/dev/null") or "n/a",
    }


def mac_info() -> dict:
    feats = {v: C.sysctl(f"hw.optional.arm.{k}") == "1" for k, v in MAC_ARM_FEATS.items()}
    if platform.machine() == "x86_64":
        flags = (C.sysctl("machdep.cpu.features") + " " + C.sysctl("machdep.cpu.leaf7_features")).lower()
        feats = {f: f.replace("_", "") in flags for f in X86_SIMD}
    caches = {
        "L1d": {"per_instance_bytes": int(C.sysctl("hw.perflevel0.l1dcachesize") or C.sysctl("hw.l1dcachesize") or 0)},
        "L2": {"per_instance_bytes": int(C.sysctl("hw.perflevel0.l2cachesize") or C.sysctl("hw.l2cachesize") or 0),
               "shared_by_cpus": C.sysctl("hw.perflevel0.cpusperl2")},
    }
    if C.sysctl("hw.l3cachesize"):
        caches["L3"] = {"total_bytes": int(C.sysctl("hw.l3cachesize"))}
    mem = C.sh("system_profiler SPMemoryDataType 2>/dev/null")
    mtype = re.search(r"Type:\s*(\S+)", mem)
    return {
        "cpu_model": C.sysctl("machdep.cpu.brand_string"),
        "arch": platform.machine(),
        "sockets": "1",
        "threads_per_core": "1",
        "max_mhz": "n/a (not exposed on macOS)",
        "caches": caches,
        "simd": feats,
        "ram_total_gb": round(int(C.sysctl("hw.memsize") or 0) / 1e9, 2),
        "swap_total_gb": C.sh("sysctl -n vm.swapusage"),
        "ram_detail": (mtype.group(1) if mtype else "FILL IN") + " (unified memory)",
        "governor": "n/a",
        "platform_profile": "lowpowermode=" + (re.search(r"lowpowermode\s+(\d)", C.sh("pmset -g")) or [None, "?"])[1],
        "no_turbo": "n/a",
    }


def power_state() -> dict:
    if C.is_macos():
        b = C.sh("pmset -g batt")
        return {"on_ac": "AC Power" in b, "source": b.splitlines()[0] if b else "?"}
    if C.is_wsl():
        st = C.sh("powershell.exe -NoProfile -Command \"(Get-CimInstance Win32_Battery).BatteryStatus\" 2>/dev/null",
                  timeout=30)
        scheme = C.sh("powercfg.exe /getactivescheme 2>/dev/null", timeout=30)
        return {"on_ac": (st.strip() == "2") if st.strip() else None,
                "source": f"Win32_Battery.BatteryStatus={st.strip() or 'n/a'} (2 = on AC)",
                "windows_power_scheme": scheme}
    for d in Path("/sys/class/power_supply").glob("*"):
        try:
            if (d / "type").read_text().strip() == "Mains":
                return {"on_ac": (d / "online").read_text().strip() == "1", "source": str(d)}
        except OSError:
            pass
    return {"on_ac": None, "source": "no power_supply info (desktop/VM?)"}


def wsl_limits() -> dict:
    if not C.is_wsl():
        return {}
    cfg = C.sh("cat \"$(wslpath \"$(cmd.exe /c 'echo %USERPROFILE%' 2>/dev/null | tr -d '\\r')\")/.wslconfig\" 2>/dev/null")
    return {"wslconfig": cfg or "(none: WSL2 defaults = 50% of host RAM, swap = 25% of that)",
            "kernel": platform.release()}


def main():
    cfg = C.load_config()
    topo = C.cpu_topology(cfg)
    info = mac_info() if C.is_macos() else linux_info()
    info.update({
        "machine": cfg["_machine"],
        "os": platform.platform(),
        "wsl2": C.is_wsl(),
        "logical_cpus": topo.logical,
        "physical_cores": topo.physical,
        "perf_cores": topo.perf_cores,
        "eff_cores": topo.eff_cores,
        "hybrid": topo.hybrid,
        "perf_cpu_list": topo.perf_cpu_list,
        "topology_note": topo.note,
        "power": power_state(),
        "wsl": wsl_limits(),
        "python": platform.python_version(),
        "recorded_at": C.now_iso(),
        "theoretical_peak_bw_gbs": cfg.get("theoretical_peak_bw_gbs", "FILL IN: channels x bus bytes x MT/s"),
    })
    out = C.machine_dir(cfg)
    (out / "hardware.json").write_text(json.dumps(info, indent=2))

    def cache_txt(k):
        c = info["caches"].get(k)
        if not c:
            return "n/a"
        if "text" in c:
            return c["text"]
        per = c.get("per_instance_bytes")
        tot = c.get("total_bytes")
        f = lambda b: f"{b / 2**20:.1f} MiB" if b >= 2**20 else f"{b / 2**10:.0f} KiB"
        s = f(per) if per else ""
        if tot and per and tot != per:
            s += f" x {tot // per} = {f(tot)}"
        elif tot and not per:
            s = f(tot)
        return s
    simd = ", ".join(k for k, v in info["simd"].items() if v) or "none detected"
    rows = [
        ("Machine", info["machine"]), ("CPU", info["cpu_model"]), ("Architecture", info["arch"]),
        ("OS", info["os"] + (" (WSL2)" if info["wsl2"] else "")),
        ("Cores", f"{info['physical_cores']} physical / {info['logical_cpus']} logical; "
                  f"P-cores {info['perf_cores']}, E-cores {info['eff_cores']} (hybrid: {info['hybrid']})"),
        ("Max clock", info["max_mhz"]),
        ("L1d / L1i", f"{cache_txt('L1d')} / {cache_txt('L1i')}"), ("L2", cache_txt("L2")), ("L3", cache_txt("L3")),
        ("SIMD", simd), ("RAM", f"{info['ram_total_gb']} GB, {info['ram_detail']}"),
        ("Swap", str(info["swap_total_gb"])),
        ("Theoretical peak BW", str(info["theoretical_peak_bw_gbs"])),
        ("Power", f"on AC: {info['power'].get('on_ac')}; profile: {info['platform_profile']}; "
                  f"governor: {info['governor']}"),
    ]
    md = "| item | value |\n|---|---|\n" + "\n".join(f"| {a} | {b} |" for a, b in rows) + "\n"
    if topo.note:
        md += f"\n> {topo.note}\n"
    (out / "hardware.md").write_text(md)
    print(md)
    print(f"wrote {out / 'hardware.json'}")
    missing = [k for k, v in (("RAM type/speed", info["ram_detail"]),
                              ("theoretical peak bandwidth", str(info["theoretical_peak_bw_gbs"])))
               if "FILL IN" in str(v)]
    if missing:
        print("\n[todo] fill in by hand in config (theoretical_peak_bw_gbs) or the report:", ", ".join(missing))
        print("       Windows: Task Manager > Performance > Memory (speed, slots); Linux: sudo dmidecode -t memory;"
              " macOS: system_profiler SPMemoryDataType")


if __name__ == "__main__":
    main()
