#!/usr/bin/env python3
"""Own experiment (course step 8): change ONE thing - the prefill micro-batch size b (llama-bench -ub) - and
compare the measured effect with a prediction written down BEFORE the runs.

Model: a micro-batch of b tokens reads every weight once (W bytes) and reads/writes the recurrent state once
per layer (~4 x S bytes in llama.cpp's graph), and costs a fixed compute time t_c per token:
      t(b) = (W + 4 S) / (b * BW)  +  t_c          prefill speed = 1 / t(b)
BW = STREAM Triad at the sweep's thread count; t_c is backed out of the already-measured pp512 at b = 512.
So the whole curve is predicted from two numbers measured elsewhere. Crossover (memory term = compute term):
b* = (W + 4 S) / (BW * t_c). Writes experiment_prediction.csv (timestamped) first, then runs the sweep
(3 fresh processes per point) into raw/experiment.csv, then experiment.md.
"""
import csv
import statistics as st
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import bench as B  # noqa: E402
import common as C  # noqa: E402


def main():
    cfg = C.load_config()
    ex = cfg["experiment"]
    T = C.cpu_topology(cfg).perf_cores
    out = C.machine_dir(cfg)
    preds = [r for r in C.read_csv(out / "predictions.csv") if r.get("scaling") in ("0", 0)]
    sweep = [r for r in C.read_csv(out / "raw" / "sweep.csv") if r["status"] == "ok" and r["sweep"] == "prefill"]
    stream = [r for r in C.read_csv(out / "stream.csv") if int(r["threads"]) == T and r["validates"] == "True"]
    if not preds or not stream:
        sys.exit("run 02_stream.py and 05_predict.py first")
    BW = st.mean(float(r["triad_gbs"]) for r in stream) * 1e9
    n_prompt = int(ex["n_prompt"])
    prows, specs = [], []
    for mid in ex["models"]:
        m = C.model_by_id(cfg, mid)
        p = next((r for r in preds if r["model"] == mid), None)
        if p is None or not m["_path"].exists():
            C.log(f"skip {mid}: no prediction or model file")
            continue
        W, S = float(p["weight_bytes"]), float(p["state_bytes"])
        mem = W + 4 * S
        base = [float(r["tps"]) for r in sweep if r["model"] == mid and int(r["n_prompt"]) == 512 and int(r["threads"]) == T]
        t512 = 1 / st.median(base) if base else None
        t_c = max(t512 - mem / (512 * BW), 0.0) if t512 else 0.0
        b_star = mem / (BW * t_c) if t_c > 0 else float("inf")
        for b in ex["ubatch"]:
            t = mem / (b * BW) + t_c
            prows.append({"model": mid, "label": m["label"], "ubatch": b, "bytes_per_ubatch": mem, "bw_gbs": BW / 1e9,
                          "t_compute_ms_per_token": t_c * 1e3, "pred_tps": 1 / t, "pred_memory_bound_tps": b * BW / mem,
                          "crossover_b": b_star, "anchor": "pp512 sweep median" if t512 else "none (memory bound only)",
                          "predicted_at": C.now_iso()})
            specs.append(B.Spec("experiment", m, n_prompt, 0, 0, T, variant=f"ub{b}",
                                extra_args=["-ub", str(b), "-b", str(max(b, n_prompt))]))
        C.log(f"{mid}: predicted crossover b* = {b_star:.1f} tokens (t_c = {t_c * 1e3:.3f} ms/token, "
              f"memory per ubatch {mem / 1e6:.0f} MB)")
    if not specs:
        sys.exit("nothing to run")
    with open(out / "experiment_prediction.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(prows[0]))
        w.writeheader()
        w.writerows(prows)
    raw = C.machine_dir(cfg, "raw") / "experiment.csv"
    B.run_specs(cfg, specs, raw, int(cfg["sweep"]["reps"]), float(cfg["sweep"].get("cooldown_s", 0)))
    meas = [r for r in C.read_csv(raw) if r["status"] == "ok"]
    md = [f"# Own experiment: prefill speed vs micro-batch size ({C.now_iso()})\n", f"{ex['question'].strip()}\n",
          "| model | ubatch | predicted t/s | measured t/s (mean +/- sd, n) | measured / predicted |", "|---|---:|---:|---:|---:|"]
    for pr in prows:
        v = [float(r["tps"]) for r in meas if r["model"] == pr["model"] and r["variant"] == f"ub{pr['ubatch']}"]
        if v:
            mu, sd = st.mean(v), (st.stdev(v) if len(v) > 1 else 0.0)
            md.append(f"| {pr['label']} | {pr['ubatch']} | {pr['pred_tps']:.1f} | {mu:.1f} +/- {sd:.1f} ({len(v)}) | "
                      f"{mu / pr['pred_tps']:.2f} |")
    (out / "experiment.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
