// Read-only memory bandwidth microbenchmark (companion to STREAM).
//
// Decode in llama.cpp is almost pure streaming *reads* of weights and KV cache. STREAM's
// kernels also write (Copy/Scale: 1 read + 1 write, Add/Triad: 2 reads + 1 write), and with
// ordinary stores every written line is first read (write-allocate), traffic STREAM does not
// count. So read-only bandwidth is usually higher than STREAM Triad; this program measures it.
//
//   cc -O3 -march=native -pthread bw_read.c -o bw_read      (Apple Silicon: -mcpu=native)
//   ./bw_read <MiB per run> <threads> <repeats>
// Prints: threads=T bytes=B best_gbs=X avg_gbs=Y
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    const uint64_t *a;
    size_t lo, hi;
    uint64_t sum;
} work_t;

static volatile uint64_t g_sink;

static double now_s(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

static void *reader(void *p) {
    work_t *w = (work_t *)p;
    const uint64_t *a = w->a;
    uint64_t s0 = 0, s1 = 0, s2 = 0, s3 = 0, s4 = 0, s5 = 0, s6 = 0, s7 = 0;
    size_t i = w->lo;
    for (; i + 8 <= w->hi; i += 8) {  // 8 independent chains -> vectorised, no fp reassociation issues
        s0 += a[i + 0]; s1 += a[i + 1]; s2 += a[i + 2]; s3 += a[i + 3];
        s4 += a[i + 4]; s5 += a[i + 5]; s6 += a[i + 6]; s7 += a[i + 7];
    }
    for (; i < w->hi; i++) s0 += a[i];
    w->sum = s0 + s1 + s2 + s3 + s4 + s5 + s6 + s7;
    return NULL;
}

static void *toucher(void *p) {  // first touch by the same thread layout (NUMA-friendly)
    work_t *w = (work_t *)p;
    uint64_t *a = (uint64_t *)w->a;
    for (size_t i = w->lo; i < w->hi; i++) a[i] = i * 2654435761u;
    return NULL;
}

static void run(int T, work_t *w, void *(*fn)(void *)) {
    pthread_t th[256];
    for (int t = 1; t < T; t++) pthread_create(&th[t], NULL, fn, &w[t]);
    fn(&w[0]);
    for (int t = 1; t < T; t++) pthread_join(th[t], NULL);
}

int main(int argc, char **argv) {
    size_t mib = argc > 1 ? strtoull(argv[1], NULL, 10) : 1024;
    int T = argc > 2 ? atoi(argv[2]) : 1;
    int reps = argc > 3 ? atoi(argv[3]) : 10;
    if (T < 1 || T > 256) { fprintf(stderr, "threads must be 1..256\n"); return 1; }
    size_t n = mib * 1024 * 1024 / sizeof(uint64_t);
    uint64_t *a = NULL;
    if (posix_memalign((void **)&a, 4096, n * sizeof(uint64_t)) != 0) { perror("alloc"); return 1; }
    work_t w[256];
    for (int t = 0; t < T; t++) {
        w[t].a = a;
        w[t].lo = n * (size_t)t / (size_t)T;
        w[t].hi = n * (size_t)(t + 1) / (size_t)T;
        w[t].sum = 0;
    }
    run(T, w, toucher);
    run(T, w, reader);  // warm-up
    double best = 0, total = 0;
    for (int r = 0; r < reps; r++) {
        double t0 = now_s();
        run(T, w, reader);
        double dt = now_s() - t0;
        uint64_t s = 0;
        for (int t = 0; t < T; t++) s += w[t].sum;
        g_sink += s;
        double gbs = (double)(n * sizeof(uint64_t)) / dt / 1e9;
        total += gbs;
        if (gbs > best) best = gbs;
    }
    printf("threads=%d bytes=%zu best_gbs=%.3f avg_gbs=%.3f\n", T, n * sizeof(uint64_t), best, total / reps);
    free(a);
    return 0;
}
