#!/usr/bin/env python3
"""Benchmark sweeps (course step 5). Every point is repeated `sweep.reps` times in fresh processes.

  prefill  : prompt lengths 512, 4k, max (+ optional extra points)      at P threads
  decode   : context lengths 1k, 8k, max (+ extra); 128 tokens decoded   at P threads
             (the decode window ends at the stated context: depth = ctx - n_gen, so it never exceeds the limit)
  scaling  : pp512 and tg128 for threads = 1..P
  P = number of performance cores (config threads.perf_cores, auto-detected where possible)

Raw rows (one per run, with peak RSS, memory breakdown, swap flags...) go to
results/<machine>/raw/sweep.csv. Interrupted? Just rerun: finished runs are skipped.

  python3 scripts/06_sweep.py                    # everything
  python3 scripts/06_sweep.py --only decode --models 1b-q4km
  python3 scripts/06_sweep.py --required-only    # just the points the course requires
  python3 scripts/06_sweep.py --dry-run          # print the plan and commands
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import bench as B  # noqa: E402
import common as C  # noqa: E402
import preflight  # noqa: E402


def resolve(points, max_ctx):
    out = []
    for p in points:
        v = max_ctx if p == "max" else int(p)
        if v <= max_ctx:
            out.append(v)
    return sorted(set(out))


def build_specs(cfg, only, model_ids, required_only):
    topo = C.cpu_topology(cfg)
    P = topo.perf_cores
    s = cfg["sweep"]
    G = int(s["n_gen"])
    specs = []
    models = [m for m in cfg["models"] if not model_ids or m["id"] in model_ids]
    for m in models:
        if not m["_path"].exists():
            C.log(f"!! {m['id']}: {m['_path']} missing (scripts/03_get_models.sh) - skipped")
            continue
        pp = s["prefill"] + ([] if required_only else s.get("prefill_extra", []))
        tg = s["decode_ctx"] + ([] if required_only else s.get("decode_extra", []))
        contrast = m.get("role") == "contrast"
        if only in (None, "prefill") and (not contrast or s.get("contrast_prefill", False)):
            specs += [B.Spec("prefill", m, p, 0, 0, P) for p in resolve(pp, m["max_ctx"])]
        if only in (None, "decode"):
            specs += [B.Spec("decode", m, 0, G, max(L - G, 0), P) for L in resolve(tg, m["max_ctx"])]
    ts = cfg.get("thread_scaling", {})
    if only in (None, "scaling") and ts:
        tlist = list(range(1, P + 1)) if ts.get("threads", "auto") == "auto" else [int(t) for t in ts["threads"]]
        for mid in ts.get("models", []):
            if model_ids and mid not in model_ids:
                continue
            m = C.model_by_id(cfg, mid)
            if not m["_path"].exists():
                continue
            for t in tlist:
                specs.append(B.Spec("scaling", m, int(ts.get("prefill", 512)), 0, 0, t))
                specs.append(B.Spec("scaling", m, 0, int(ts.get("n_gen", 128)), 0, t))
    return specs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=["prefill", "decode", "scaling"])
    ap.add_argument("--models", help="comma-separated model ids")
    ap.add_argument("--required-only", action="store_true")
    ap.add_argument("--reps", type=int)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--force", action="store_true", help="run even if preflight fails")
    args = ap.parse_args()
    cfg = C.load_config()
    model_ids = set(args.models.split(",")) if args.models else None
    specs = build_specs(cfg, args.only, model_ids, args.required_only)
    if not specs:
        sys.exit("nothing to run (models missing?)")
    reps = args.reps or int(cfg["sweep"]["reps"])
    raw = C.machine_dir(cfg, "raw") / "sweep.csv"
    if not args.dry_run:
        need = max(B.predicted_mem_gb(cfg, s) for s in specs if B.predicted_mem_gb(cfg, s) <= cfg["memory_budget_gb"]) + 0.5
        pf = preflight.run(cfg, need, f"sweep_{C.now_iso().replace(':', '')}")
        if not pf["all_ok"] and not args.force:
            sys.exit("preflight failed (see above). Fix it, or rerun with --force and say so in the report.")
    B.run_specs(cfg, specs, raw, reps, float(cfg["sweep"].get("cooldown_s", 0)), args.dry_run)
    if not args.dry_run:
        C.log(f"done -> {raw}. Next: scripts/07_profile.py, then scripts/10_plots.py")


if __name__ == "__main__":
    main()
