#!/usr/bin/env python3
"""Correctness checks (course step 3), each with an explicit PASS/FAIL criterion:

1. Perplexity on a FIXED text sample (WikiText-2 test, first `chunks` x `ctx` tokens; SHA-256 recorded).
   PASS if every PPL is finite and, for each model available as Q4_K_M and Q8_0,
   PPL(Q4_K_M) <= (1 + max_rel_increase_vs_q8) * PPL(Q8_0)   [Q8_0 is the near-lossless reference].
2. Sample outputs: three DIFFERENT prompts, greedy decoding, saved verbatim -> read them.
3. Recurrent consistency: the same prompt processed in one batch (parallel scan over the prompt, the prefill
   path) and token by token (-ub 1, the decode path) must give the same greedy continuation. This checks that
   SSM_SCAN over many tokens equals repeated one-token steps.
Writes results/<machine>/correctness/{perplexity.csv, consistency.csv, samples/*.txt, correctness.md}.
"""
import csv
import hashlib
import math
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import common as C  # noqa: E402


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def completion_flags(cfg) -> list[str]:
    helptxt = subprocess.run([str(C.binary(cfg, "llama-completion")), "--help"], capture_output=True, text=True).stdout
    flags = ["--temp", "0", "-s", "1", "--simple-io"]
    if "-no-cnv" in helptxt:
        flags.append("-no-cnv")
    if "--no-display-prompt" in helptxt:
        flags.append("--no-display-prompt")
    return flags


def generate(cfg, m, prompt, n, extra, T) -> str:
    cmd = [str(C.binary(cfg, "llama-completion")), "-m", str(m["_path"]), "-p", prompt, "-n", str(n), "-t", str(T),
           "-c", "1024", *completion_flags(cfg), *extra]
    r = subprocess.run(cmd, capture_output=True, text=True, stdin=subprocess.DEVNULL, timeout=900)
    if r.returncode != 0:
        return f"<<error rc={r.returncode}: {r.stderr.strip()[-300:]}>>"
    return r.stdout.strip()


def main():
    cfg = C.load_config()
    T = C.cpu_topology(cfg).perf_cores
    out = C.machine_dir(cfg, "correctness")
    (out / "samples").mkdir(exist_ok=True)
    synthetic = bool(cfg.get("synthetic"))
    pc = cfg["perplexity"]
    text = C.REPO / pc["text"]
    if not text.exists():
        sys.exit(f"{text} missing: run scripts/03_get_models.sh")
    digest = sha256(text)
    md = [f"# Correctness checks ({C.now_iso()})\n",
          f"Text sample: `{pc['text']}` sha256 `{digest[:16]}...`, ctx {pc['ctx']}, {pc['chunks']} chunks "
          f"({pc['ctx'] * pc['chunks']:,} tokens), {T} threads.\n"]
    # ---------------------------------------------------------------- 1. perplexity
    rows = []
    for mid in pc["models"]:
        m = C.model_by_id(cfg, mid)
        if not m["_path"].exists():
            continue
        # -b = ctx: one sequence per batch. At the pinned commit llama-perplexity's default (several sequences per
        # batch, n_seq = 2048/ctx) silently produces no estimate for Mamba-1 models; batching does not change PPL.
        cmd = [str(C.binary(cfg, "llama-perplexity")), "-m", str(m["_path"]), "-f", str(text), "-c", str(pc["ctx"]),
               "-b", str(pc["ctx"]), "--chunks", str(pc["chunks"]), "-t", str(T)]
        r = C.run_measured(cmd, log_prefix=out / f"ppl_{mid}")
        mm = re.search(r"Final estimate: PPL = ([\d.]+) \+/- ([\d.]+)", r.stdout + r.stderr)
        ppl, err = (float(mm.group(1)), float(mm.group(2))) if mm else (float("nan"), float("nan"))
        rows.append({"model": mid, "label": m["label"], "base": m.get("base", mid), "quant": m.get("quant", "?"),
                     "ppl": ppl, "ppl_err": err, "ctx": pc["ctx"], "chunks": pc["chunks"], "text_sha256": digest,
                     "peak_rss_gb": round(r.peak_rss_gb, 3), "time_s": round(r.wall_s, 1)})
        C.log(f"PPL {m['label']:32s} {ppl:10.3f} +/- {err:.3f}")
    with open(out / "perplexity.csv", "w", newline="") as f:
        if rows:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
    md.append("## 1. Perplexity\n\n| model | PPL | +/- |\n|---|---:|---:|")
    md += [f"| {r['label']} | {r['ppl']:.3f} | {r['ppl_err']:.3f} |" for r in rows]
    ok_ppl = all(math.isfinite(r["ppl"]) for r in rows) and bool(rows)
    tol = float(pc.get("max_rel_increase_vs_q8", 0.05))
    for base in sorted({r["base"] for r in rows}):
        q4 = [r for r in rows if r["base"] == base and r["quant"] == "Q4_K_M"]
        q8 = [r for r in rows if r["base"] == base and r["quant"] == "Q8_0"]
        if q4 and q8:
            rel = q4[0]["ppl"] / q8[0]["ppl"] - 1
            verdict = "n/a (synthetic weights)" if synthetic else ("PASS" if rel <= tol else "FAIL")
            ok_ppl = ok_ppl and (synthetic or rel <= tol)
            md.append(f"\n{base}: PPL(Q4_K_M) / PPL(Q8_0) - 1 = {100 * rel:+.2f}% (criterion <= {100 * tol:.0f}%): **{verdict}**")
    md.append(f"\nAll perplexities finite: {'PASS' if ok_ppl else 'FAIL'}\n")
    # ---------------------------------------------------------------- 2. samples + 3. consistency
    sp = cfg["samples"]
    cons, ok_cons = [], True
    md.append("## 2. Sample outputs (greedy, three different prompts) and 3. batch vs token-by-token\n")
    md.append("| model | prompt | output (start) | batch == token-by-token |\n|---|---|---|---|")
    for mid in sp["models"]:
        m = C.model_by_id(cfg, mid)
        if not m["_path"].exists():
            continue
        for k, prompt in enumerate(sp["prompts"]):
            a = generate(cfg, m, prompt, sp["n_predict"], [], T)
            b = generate(cfg, m, prompt, sp["n_predict"], ["-b", "1", "-ub", "1"], T)
            (out / "samples" / f"{mid}_prompt{k + 1}.txt").write_text(f"PROMPT: {prompt}\n---- batch prefill ----\n{a}\n"
                                                                       f"---- token-by-token (-ub 1) ----\n{b}\n")
            common = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
            same = a == b
            ok_cons = ok_cons and same
            cons.append({"model": mid, "prompt": prompt, "identical": same, "common_prefix_chars": common,
                         "len_batch": len(a), "len_tbt": len(b)})
            short = a.replace("\n", " ").replace("|", "/")[:60]
            md.append(f"| {m['label']} | `{prompt}` | {short} | {'yes' if same else f'no (diverges at char {common})'} |")
    with open(out / "consistency.csv", "w", newline="") as f:
        if cons:
            w = csv.DictWriter(f, fieldnames=list(cons[0]))
            w.writeheader()
            w.writerows(cons)
    md.append(f"\nBatch-vs-token-by-token consistency: **{'PASS' if ok_cons else 'CHECK'}** "
              "(a late divergence can come from a near-tie between two tokens: GEMM and GEMV kernels round differently)\n")
    (out / "correctness.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    C.log(f"wrote {out}/correctness.md")


if __name__ == "__main__":
    main()
